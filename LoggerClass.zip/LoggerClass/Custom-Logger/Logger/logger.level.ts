export enum LogLevel {
    Verbose = "[Verbose]::",
    Info = "   [Info]::",
    Warning = "[Warning]::",
    Error = "  [Error]::",
}
