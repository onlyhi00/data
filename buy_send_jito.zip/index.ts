
import {
  Liquidity,
  LIQUIDITY_STATE_LAYOUT_V4,
  LiquidityPoolKeys,
  jsonInfo2PoolKeys,
  MARKET_STATE_LAYOUT_V3,
  Percent,
  InnerSimpleV0Transaction,
  Token,
  TokenAmount,
  TxVersion,
  TokenAccount,
  Currency,
  CurrencyAmount,
  SPL_ACCOUNT_LAYOUT,
  SPL_MINT_LAYOUT,
  ApiPoolInfoV4,
  Market,
  LOOKUP_TABLE_CACHE,
  buildSimpleTransaction
} from '@raydium-io/raydium-sdk'
import {
  createAssociatedTokenAccountInstruction,
  createTransferInstruction,
  getAssociatedTokenAddress,
  getMint,
  NATIVE_MINT,
  TOKEN_PROGRAM_ID,
} from '@solana/spl-token'
import {
  Keypair,
  Connection,
  PublicKey,
  TransactionMessage,
  VersionedTransaction,
  TransactionInstruction,
} from '@solana/web3.js'
import BN from 'bn.js'
import { RPC, outputTokenMint, privateKey, solBuyAmount, toWallet, } from "./config"
import { bundle } from './jito';
import { PoolKeys } from './pool';
import base58 from 'bs58';

const connection = new Connection(RPC)
const mainKp = Keypair.fromSecretKey(base58.decode(privateKey))
const makeTxVersion = TxVersion.V0

const DEFAULT_TOKEN = {
  'SOL': new Currency(9, 'USDC', 'USDC'),
  'WSOL': new Token(TOKEN_PROGRAM_ID, new PublicKey('So11111111111111111111111111111111111111112'), 9, 'WSOL', 'WSOL'),
  'USDC': new Token(TOKEN_PROGRAM_ID, new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'), 6, 'USDC', 'USDC'),
  'RAY': new Token(TOKEN_PROGRAM_ID, new PublicKey('4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R'), 6, 'RAY', 'RAY'),
  'RAY_USDC-LP': new Token(TOKEN_PROGRAM_ID, new PublicKey('FGYXP4vBkMEtKhxrmEBcWN8VNmXX8qNgEJpENKDETZ4Y'), 6, 'RAY-USDC', 'RAY-USDC'),
  'my-token': new Token(TOKEN_PROGRAM_ID, new PublicKey('9yekwttKZmYjkZ3tJJZA5dnEAky6adzNrT8YAgQ1JMYC'), 9),
}

async function getWalletTokenAccount(connection: Connection, wallet: PublicKey): Promise<TokenAccount[]> {
  const walletTokenAccount = await connection.getTokenAccountsByOwner(wallet, {
    programId: TOKEN_PROGRAM_ID,
  });
  return walletTokenAccount.value.map((i) => ({
    pubkey: i.pubkey,
    programId: i.account.owner,
    accountInfo: SPL_ACCOUNT_LAYOUT.decode(i.account.data),
  }));
}


async function formatAmmKeysById(id: string): Promise<ApiPoolInfoV4> {
  const account = await connection.getAccountInfo(new PublicKey(id))
  if (account === null) throw Error(' get id info error ')
  const info = LIQUIDITY_STATE_LAYOUT_V4.decode(account.data)

  const marketId = info.marketId
  const marketAccount = await connection.getAccountInfo(marketId)
  if (marketAccount === null) throw Error(' get market info error')
  const marketInfo = MARKET_STATE_LAYOUT_V3.decode(marketAccount.data)

  const lpMint = info.lpMint
  const lpMintAccount = await connection.getAccountInfo(lpMint)
  if (lpMintAccount === null) throw Error(' get lp mint info error')
  const lpMintInfo = SPL_MINT_LAYOUT.decode(lpMintAccount.data)

  return {
    id,
    baseMint: info.baseMint.toString(),
    quoteMint: info.quoteMint.toString(),
    lpMint: info.lpMint.toString(),
    baseDecimals: info.baseDecimal.toNumber(),
    quoteDecimals: info.quoteDecimal.toNumber(),
    lpDecimals: lpMintInfo.decimals,
    version: 4,
    programId: account.owner.toString(),
    authority: Liquidity.getAssociatedAuthority({ programId: account.owner }).publicKey.toString(),
    openOrders: info.openOrders.toString(),
    targetOrders: info.targetOrders.toString(),
    baseVault: info.baseVault.toString(),
    quoteVault: info.quoteVault.toString(),
    withdrawQueue: info.withdrawQueue.toString(),
    lpVault: info.lpVault.toString(),
    marketVersion: 3,
    marketProgramId: info.marketProgramId.toString(),
    marketId: info.marketId.toString(),
    marketAuthority: Market.getAssociatedAuthority({ programId: info.marketProgramId, marketId: info.marketId }).publicKey.toString(),
    marketBaseVault: marketInfo.baseVault.toString(),
    marketQuoteVault: marketInfo.quoteVault.toString(),
    marketBids: marketInfo.bids.toString(),
    marketAsks: marketInfo.asks.toString(),
    marketEventQueue: marketInfo.eventQueue.toString(),
    lookupTableAccount: PublicKey.default.toString()
  }
}


type WalletTokenAccounts = Awaited<ReturnType<typeof getWalletTokenAccount>>

type TestTxInputInfo = {
  outputToken: Token
  targetPool: string
  inputTokenAmount: CurrencyAmount
  slippage: Percent
  walletTokenAccounts: WalletTokenAccounts
  wallet: Keypair
}

async function swapOnlyAmm(input: TestTxInputInfo, wallet: Keypair) {
  // -------- pre-action: get pool info --------
  const targetPoolInfo = await formatAmmKeysById(input.targetPool)
  const poolKeys = jsonInfo2PoolKeys(targetPoolInfo) as LiquidityPoolKeys

  // -------- step 1: coumpute amount out --------
  const { amountOut, minAmountOut } = Liquidity.computeAmountOut({
    poolKeys: poolKeys,
    poolInfo: await Liquidity.fetchInfo({ connection, poolKeys }),
    amountIn: input.inputTokenAmount,
    currencyOut: input.outputToken,
    slippage: input.slippage,
  })

  // -------- step 2: create instructions by SDK function --------
  const { innerTransactions } = await Liquidity.makeSwapInstructionSimple({
    connection,
    poolKeys,
    userKeys: {
      tokenAccounts: input.walletTokenAccounts,
      owner: input.wallet.publicKey,
    },
    amountIn: input.inputTokenAmount,
    amountOut: minAmountOut,
    fixedSide: 'in',
    makeTxVersion,
  })
  console.log('amountOut:', amountOut.toFixed(), '  minAmountOut: ', minAmountOut.raw.toString())

  return { txids: await buildAndSendTx(innerTransactions, wallet, minAmountOut) }
}


async function buildAndSendTx(
  innerSimpleV0Transaction: InnerSimpleV0Transaction[], wallet: Keypair, minAmountOut: TokenAmount | CurrencyAmount
) {
  const willSendTx = await buildSimpleTransaction({
    connection,
    makeTxVersion,
    payer: wallet.publicKey,
    innerTransactions: innerSimpleV0Transaction,
    addLookupTableInfo: LOOKUP_TABLE_CACHE,
  })

  for (const iTx of willSendTx) {
    if (iTx instanceof VersionedTransaction) {
      iTx.sign([wallet]);
      const tokenTx = await getTokenTransferTx(outputTokenMint, wallet, new PublicKey(toWallet), minAmountOut.raw.toString())
      if (tokenTx == null) {
        console.log("Error getting token transfer transaction")
        return
      }
      bundle([iTx, tokenTx], wallet)
      console.log("Bundling done and bought token")
    } else {
      console.log("Trnasaction build error")
    }
  }
}
const getTokenTransferTx = async (outputTokenMint: string, senderKp: Keypair, to: PublicKey, amount: string) => {
  try {
    const mint = new PublicKey(outputTokenMint)
    const srcAta = await getAssociatedTokenAddress(mint, senderKp.publicKey)
    const toAta = await getAssociatedTokenAddress(mint, to)
    const ixs: TransactionInstruction[] = []
    if (await connection.getAccountInfo(toAta) == null) {
      ixs.push(
        createAssociatedTokenAccountInstruction(
          senderKp.publicKey,
          toAta,
          to,
          mint
        )
      )
    }
    ixs.push(
      createTransferInstruction(
        srcAta,
        toAta,
        senderKp.publicKey,
        BigInt(amount)
      )
    )
    const blockhash = (await connection.getLatestBlockhash()).blockhash
    const messageV0 = new TransactionMessage({
      payerKey: senderKp.publicKey,
      recentBlockhash: blockhash,
      instructions: ixs,
    }).compileToV0Message();
    const transaction = new VersionedTransaction(messageV0);
    transaction.sign([senderKp]);
    return transaction
  } catch (error) {
    return null
  }
}

async function buyToken(outputTokenMint: string, amount: number, slippagePercent: number, wallet: Keypair) {
  const token = new PublicKey(outputTokenMint)
  const decimal = (await getMint(connection, token)).decimals
  const ammId = (await PoolKeys.fetchPoolKeyInfo(new PublicKey(outputTokenMint), NATIVE_MINT)).id.toBase58()
  const inputToken = DEFAULT_TOKEN.SOL // USDC

  const outputToken = new Token(TOKEN_PROGRAM_ID, new PublicKey(outputTokenMint), decimal)
  const targetPool = ammId // USDC-RAY pool
  const inputTokenAmount = new CurrencyAmount(inputToken, new BN(amount * 10 ** 9))
  const slippage = new Percent(slippagePercent, 20)
  const walletTokenAccounts = await getWalletTokenAccount(connection, wallet.publicKey)

  swapOnlyAmm({
    outputToken,
    targetPool,
    inputTokenAmount,
    slippage,
    walletTokenAccounts,
    wallet: wallet,
  }, wallet
  ).then(({ txids }) => {
    /** continue with txids */
  })
}

buyToken(outputTokenMint, solBuyAmount, 5, mainKp)
.then(() => console.log("Transaction sent"))
.catch(e => console.log("Error in bundling"))


