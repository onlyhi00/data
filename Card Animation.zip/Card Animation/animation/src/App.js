import Page from './pages/Page';

function App() {
  return (
    <div>
      <Page />
    </div>
  );
}

export default App;
