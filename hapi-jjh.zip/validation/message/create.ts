import Joi from "joi";

export const createMessageSchema = Joi.object({
  type: Joi.string().required().messages({
    "any.required": "Please provide type.",
  }),
  text: Joi.string().required().messages({
    "any.required": "Please provide text.",
  }),
  to: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  referralCode: Joi.string().optional(),
});

export const deleteMessageSchema = Joi.object({
  _id: Joi.string().required().messages({
    "any.required": "Please provide _id.",
  }),
  referralCode: Joi.string().optional(),
});

export const getChatHistorySchema = Joi.object({
  to: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  referralCode: Joi.string().optional(),
});
