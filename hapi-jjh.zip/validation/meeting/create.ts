import Joi from "joi";

export const createMeetingSchema = Joi.object({
  to: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  type: Joi.string().required().messages({
    "any.required": "Please provide meeting type.",
  }),
  title: Joi.string().required().messages({
    "any.required": "Please provide title.",
  }),
  description: Joi.string().required().messages({
    "any.required": "Please provide description.",
  }),
  start: Joi.date().required().messages({
    "any.required": "Please provide start.",
  }),
  end: Joi.date().required().messages({
    "any.required": "Please provide end.",
  }),
  allDay: Joi.bool().required().messages({
    "any.required": "Please provide allDay.",
  }),
  color: Joi.string().required().messages({
    "any.required": "Please provide color.",
  }),
  textColor: Joi.string().required().messages({
    "any.required": "Please provide textColor.",
  }),
  referralCode: Joi.string().optional(),
});
export const getMeetingDetailSchema = Joi.object({
  to: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  _id: Joi.string().required().messages({
    "any.required": "Please provide meeting _id.",
  }),
  referralCode: Joi.string().optional(),
});
