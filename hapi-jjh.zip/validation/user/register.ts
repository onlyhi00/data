import Joi from "joi";

export const createUserSchema = Joi.object({
  email: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  password: Joi.string().required().min(6).messages({
    "any.required": "Please provide password.",
    "string.min": "Password must be at least 6 characters.",
  }),
  type: Joi.string().required().messages({
    "any.required": "Please provide user type.",
  }),
  fullName: Joi.string().required().messages({
    "any.required": "Please provide First Name.",
  }),
  referralCode: Joi.string().optional(),
});

export const clientRegisterSchema = Joi.object({
  phoneNumber: Joi.string().required().messages({
    "any.required": "Please provide phoneNumber.",
  }),
  birthday: Joi.string().required().messages({
    "any.required": "Please provide birthday.",
  }),
  country: Joi.string().required().messages({
    "any.required": "Please provide country.",
  }),
  languages: Joi.array().required().messages({
    "any.required": "Please provide languages.",
  }),
  socialMedia: Joi.array().required().messages({
    "any.required": "Please provide socialMedia.",
  }),
  referralCode: Joi.string().optional(),
});

export const expertRegisterSchema = Joi.object({
  titleName: Joi.string().required().messages({
    "any.required": "Please provide titleName.",
  }),
  summary: Joi.string().required().messages({
    "any.required": "Please provide summary.",
  }),
  phoneNumber: Joi.string().required().messages({
    "any.required": "Please provide phoneNumber.",
  }),
  birthday: Joi.string().required().messages({
    "any.required": "Please provide birthday.",
  }),
  country: Joi.string().required().messages({
    "any.required": "Please provide country.",
  }),
  languages: Joi.array().required().messages({
    "any.required": "Please provide languages.",
  }),
  socialMedia: Joi.array().required().messages({
    "any.required": "Please provide socialMedia.",
  }),
  address: Joi.string().required().messages({
    "any.required": "Please provide address.",
  }),
  zipCode: Joi.string().required().messages({
    "any.required": "Please provide zipCode.",
  }),
  industry: Joi.array().required().messages({
    "any.required": "Please provide industry.",
  }),
  weeklyCommitment: Joi.number().required().messages({
    "any.required": "Please provide weeklyCommitment.",
  }),
  hourlyRate: Joi.number().required().messages({
    "any.required": "Please provide hourlyRate.",
  }),
  projectPreference: Joi.string().required().messages({
    "any.required": "Please provide projectPreference.",
  }),
  tools: Joi.array().required().messages({
    "any.required": "Please provide tools.",
  }),
  skills: Joi.array().required().messages({
    "any.required": "Please provide skills.",
  }),
  education: Joi.array().required().messages({
    "any.required": "Please provide education.",
  }),
  experience: Joi.array().required().messages({
    "any.required": "Please provide experience.",
  }),
  profileCompleteness: Joi.number().required().messages({
    "any.required": "Please provide profileCompleteness.",
  }),
  referralCode: Joi.string().optional(),
});

export const orgRegisterSchema = Joi.object({
  organization: Joi.object().required().messages({
    "any.required": "Please provide organization.",
  }),
  referralCode: Joi.string().optional(),
});