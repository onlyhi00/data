import Joi from "joi";

export const userLoginSchema = Joi.object({
  email: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  password: Joi.string().required().min(6).messages({
    "any.required": "Please provide password.",
    "string.min": "Password must be at least 6 characters.",
  }),
  type: Joi.string().required().messages({
    "any.required": "Please provide user type.",
  }),
  referralCode: Joi.string().optional(),
});

export const userUpdateSchema = Joi.object({
  phoneNumber: Joi.string().required().messages({
    "any.required": "Please provide phoneNumber.",
  }),
  firstName: Joi.string().required().messages({
    "any.required": "Please provide firstName.",
  }),
  lastName: Joi.string().required().messages({
    "any.required": "Please provide lastName.",
  }),
  referralCode: Joi.string().optional(),
});

export const resetPasswordSchema = Joi.object({
  email: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  password: Joi.string().required().min(6).messages({
    "any.required": "Please provide password.",
    "string.min": "Password must be at least 6 characters.",
  }),
  referralCode: Joi.string().optional(),
});

export const currentUserSchema = Joi.object({
  referralCode: Joi.string().optional(),
});

export const recommendedExpertSchema = Joi.object({
  _id: Joi.string().required().messages({
    "any.required": "Please provide _id.",
  }),
  referralCode: Joi.string().optional(),
});
export const clientHistorySchema = Joi.object({
  email: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  referralCode: Joi.string().optional(),
});
