import Joi from "joi";

export const createJobSchema = Joi.object({
  type: Joi.string().required().messages({
    "any.required": "Please provide type.",
  }),
  title: Joi.string().required().messages({
    "any.required": "Please provide content.",
  }),
  description: Joi.string().required().messages({
    "any.required": "Please provide description.",
  }),
  questions: Joi.array().optional().messages({
    "any.optional": "Please provide questions.",
  }),
  duration: Joi.string().required().messages({
    "any.required": "Please provide duration.",
  }),
  skills: Joi.array().required().messages({
    "any.required": "Please provide skills.",
  }),
  industry: Joi.array().required().messages({
    "any.required": "Please provide industry.",
  }),
  tools: Joi.array().required().messages({
    "any.required": "Please provide tools.",
  }),
  visibility: Joi.string().required().messages({
    "any.required": "Please provide visibility.",
  }),
  budgetRange: Joi.array().required().messages({
    "any.required": "Please provide budgetRange.",
  }),
  weeklyCommitment: Joi.string().required().messages({
    "any.required": "Please provide weeklyCommitment.",
  }),
  referralCode: Joi.string().optional(),
});
