import Joi from "joi";

export const invitationSchema = Joi.object({
  _id: Joi.string().required().messages({
    "any.required": "Please provide a database _id.",
  }),
  type: Joi.string().required().messages({
    "any.required": "Please provide invitation type.",
  }),
  message: Joi.string().required().messages({
    "any.required": "Please provide invitation message.",
  }),
  expertEmail: Joi.string().required().messages({
    "any.required": "Please provide expertEmail.",
  }),
  referralCode: Joi.string().optional(),
});

export const proposalSchema = Joi.object({
  _id: Joi.string().required().messages({
    "any.required": "Please provide a job _id.",
  }),
  type: Joi.string().required().messages({
    "any.required": "Please provide type (milestone or job).",
  }),
  milestone: Joi.array().required().messages({
    "any.required": "Please provide milestones.",
  }),
  coverLetter: Joi.string().required().messages({
    "any.required": "Please provide coverLetter.",
  }),
  
  referralCode: Joi.string().optional(),
});
export const milestoneSchema = Joi.object({
  _id: Joi.string().required().messages({
    "any.required": "Please provide a database _id.",
  }),
  milestoneNumber: Joi.number().required().messages({
    "any.required": "Please provide milestoneNumber.",
  }),
  price: Joi.string().required().messages({
    "any.required": "Please provide price.",
  }),
  startDate: Joi.date().required().messages({
    "any.required": "Please provide startDate.",
  }),
  endDate: Joi.date().required().messages({
    "any.required": "Please provide endDate.",
  }),
  description: Joi.string().required().messages({
    "any.required": "Please provide description.",
  }),
  referralCode: Joi.string().optional(),
});
