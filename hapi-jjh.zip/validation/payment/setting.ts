import Joi from "joi";

export const addPaymentMethodSchema = Joi.object({
  method: Joi.string().required().messages({
    "any.required": "Please provide payment method.",
  }),
  billingEmail: Joi.string().email().required().messages({
    "any.required": "Please provide email",
    "string.email": "Please provide a valid email.",
  }),
  billingFullname: Joi.string().required().messages({
    "any.required": "Please provide billingFullname.",
  }),
  billingCountry: Joi.string().required().messages({
    "any.required": "Please provide billingCountry.",
  }),
  billingState: Joi.string().required().messages({
    "any.required": "Please provide billingState.",
  }),
  billingZipCode: Joi.string().required().messages({
    "any.required": "Please provide billingZipCode.",
  }),
  cardNumber: Joi.string().optional().messages({
    "any.optional": "Please provide cardNumber.",
  }),
  cardExpirationDate: Joi.string().optional().messages({
    "any.optional": "Please provide cardExpirationDate.",
  }),
  cardSecurityCode: Joi.string().optional().messages({
    "any.optional": "Please provide cardSecurityCode.",
  }),
  paypal: Joi.string().optional().messages({
    "any.optional": "Please provide paypal.",
  }),
  referralCode: Joi.string().optional(),
});
export const getPaymentMethodSchema = Joi.object({
  referralCode: Joi.string().optional(),
});
