import Joi from "joi";

export const getDataSchema = Joi.object({
  target: Joi.string().required().messages({
    "any.required": "Please provide target.",
  }),
});
