export const addPaymentMethodSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "Payment method added.",
      },
      404: {
        description: "User not found.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const getPaymentMethodSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got payment methods info.",
      },
      404: {
        description: "User not found.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
