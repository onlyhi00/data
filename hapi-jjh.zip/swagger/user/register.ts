export const userRegisterSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "User created successfully.",
      },
      400: {
        description: "Input Fields Required.",
      },
      409: {
        description: "User already exists.",
      },
    },
  },
};

export const expertRegisterSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Expert updated.",
      },
      201: {
        description: "Expert inserted.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};

export const clientRegisterSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Client updated.",
      },
      201: {
        description: "Client inserted.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
