export const userLoginSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "User logined successfully.",
      },
      401: {
        description: "Password is incorrect.",
      },
      403: {
        description: "Email verification has sent to your email.",
      },
      404: {
        description: "User not found.",
      },
    },
  },
};

export const currentUserSwagger = {
  "hapi-swagger": {
    responses: {
      401: {
        description: "Not signed.",
      },
      200: {
        description: "Success",
      }
    },
  },
};

export const resetPasswordSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Your password has been successfully changed.",
      },
      400: {
        description: "Input value failed",
      },
      401: {
        description: "Changing password is not allowed.",
      },
      404: {
        description: "Email is not found.",
      }
    },
  },
};

export const userUpdateSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Successfully updated.",
      },
      401: {
        description: "User not found.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};

export const recommendedExpertSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Successfully got.",
      },
      401: {
        description: "Job not found.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
