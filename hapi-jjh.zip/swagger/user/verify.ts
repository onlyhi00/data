export const verifyEmailSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "Email is verified",
      },
      400: {
        description: "Email is not verified",
      }
    },
  },
};

export const verifyEmailResendSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Email verification has sent to your email",
      },
      404: {
        description: "User not found",
      }
    },
  },
};

export const resendOTPVerifySwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "OTP has sent to your email",
      },
      400: {
        description: "You need to verify email first",
      },
      404: {
        description: "User not found",
      }
    },
  },
};

export const OTPSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "OTP is verified",
      },
      400: {
        description: "OTP Verification Failed",
      }
    },
  },
};
