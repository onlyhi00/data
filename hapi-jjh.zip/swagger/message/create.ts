export const createMessageSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "Message created.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const deleteMessageSwagger = {
  "hapi-swagger": {
    responses: {
      204: {
        description: "Message deleted.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const getChatHistorySwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got chat history.",
      },
      400: {
        description: "failed.",
      },
    },
  },
};
