export const getSwagger = {
    "hapi-swagger": {
      responses: {
        200: {
          description: "Data got.",
        },
        500: {
          description: "failed.",
        },
      },
    },
  };
  