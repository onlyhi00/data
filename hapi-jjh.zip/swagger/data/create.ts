export const createSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "Data created.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
