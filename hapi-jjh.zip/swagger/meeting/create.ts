export const createMeetingSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "Meeting created.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const deleteMeetingSwagger = {
  "hapi-swagger": {
    responses: {
      204: {
        description: "Meeting deleted.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const upcomingMeetingSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got meetings.",
      },
      400: {
        description: "failed.",
      },
    },
  },
};
