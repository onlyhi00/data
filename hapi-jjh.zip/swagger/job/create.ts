export const createJobSwagger = {
  "hapi-swagger": {
    responses: {
      201: {
        description: "Job created.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
