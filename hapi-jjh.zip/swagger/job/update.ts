export const invitationSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Invitation has been sent.",
      },
      404: {
        description: "Job not found.",
      },
      409: {
        description: "Already invited.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const proposalSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Proposal has been sent.",
      },
      404: {
        description: "Job not found.",
      },
      409: {
        description: "Already sent a proposal.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const milestoneSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Milestone has been set.",
      },
      404: {
        description: "Job not found.",
      },
      409: {
        description: "Already set a milestone.",
      },
      500: {
        description: "failed.",
      },
    },
  },
};
export const activeJobsSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got active jobs.",
      },
      404: {
        description: "Active jobs not found.",
      },
      500: {
        description: "Server error.",
      },
    },
  },
};
export const getMilestoneSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got milestones.",
      },
      400: {
        description: "Provide id.",
      },
      500: {
        description: "Server error.",
      },
    },
  },
};
export const getJobOverviewSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got Overview.",
      },
      400: {
        description: "Provide id.",
      },
      500: {
        description: "Server error.",
      },
    },
  },
};
export const searchJobSwagger = {
  "hapi-swagger": {
    responses: {
      200: {
        description: "Got Overview.",
      },
      400: {
        description: "Provide id.",
      },
      500: {
        description: "Server error.",
      },
    },
  },
};
