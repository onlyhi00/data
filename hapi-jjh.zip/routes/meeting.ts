import { Request, ResponseToolkit } from "@hapi/hapi";
import Jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import fs from "fs";

import { createMeetingSchema, getMeetingDetailSchema } from "../validation/meeting/create";

import { createMeetingSwagger, deleteMeetingSwagger, upcomingMeetingSwagger } from '../swagger/meeting/create';

import Meeting from "../models/meetings";
import Account from "../models/accounts";

const options = { abortEarly: false, stripUnknown: true };
export let meetingRoute = [
  {
    method: "POST",
    path: "/",
    options: {
      auth: "jwt",
      description: "Create a new meeting",
      plugins: createMeetingSwagger,
      tags: ["api", "user"],
      validate: {
        payload: createMeetingSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const from = request.auth.credentials.email;
        const newData = {
          type: request.payload['type'],
          from: from,  
          to: request.payload['to'],
          title: request.payload['title'],
          description: request.payload['description'],
          start: request.payload['start'],
          end: request.payload['end'],
          allDay: request.payload['allDay'],
          color: request.payload['color'],
          textColor: request.payload['textColor'],
          status: "pending"
        }
        const newContent: any = new Meeting(newData);
        const newResult = await newContent.save();
        return response.response([{ newResult, message: "Meeting created", code: 201 }]).code(201);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "DELETE",
    path: "/{id}",
    options: {
      auth: "jwt",
      description: "Delete a meeting",
      plugins: deleteMeetingSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const from = request.auth.credentials.email;
        const id = request.params.id;
        
        await Meeting.deleteOne({ _id: id, from: from });

        return response.response([{  message: "Meeting deleted", code: 204 }]).code(204);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/upcoming",
    options: {
      auth: "jwt",
      description: "Get upcoming meetings",
      plugins: upcomingMeetingSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        // const result = await Meeting.find({ from: email, status: 'pending' });
        const result = await Meeting.aggregate([
          {
            $match: {
              from: email,
              status: 'pending'
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'from',
              foreignField: 'email',
              as: 'fromAccount'
            }
          },
          {
            $unwind: {
              path: '$fromAccount',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'to',
              foreignField: 'email',
              as: 'toAccount'
            }
          },
          {
            $unwind: {
              path: '$toAccount',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $addFields: {
              diff: {
                $divide: [
                  { $subtract: ['$end', '$start'] },
                  1000 * 60 // Convert milliseconds to minutes
                ]
              },
              fromName: '$fromAccount.fullName',
              toName: '$toAccount.fullName'
            }
          },
          {
            $project: {
              fromAccount: 0,
              toAccount: 0
            }
          }
        ]).exec();
        return { result, message: 'Got upcoming meetings', code: 200 };
      } catch (error) {
        console.error(error);
        return response.response({ message: 'Failed', code: 400 }).code(400);
      }
    },
  },
  {
    method: "GET",
    path: "/history",
    options: {
      auth: "jwt",
      description: "Get meeting history",
      plugins: upcomingMeetingSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const result = await Meeting.aggregate([
          {
            $match: {
              from: email,
              status: 'finished'
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'from',
              foreignField: 'email',
              as: 'fromAccount'
            }
          },
          {
            $unwind: {
              path: '$fromAccount',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'to',
              foreignField: 'email',
              as: 'toAccount'
            }
          },
          {
            $unwind: {
              path: '$toAccount',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $addFields: {
              diff: {
                $divide: [
                  { $subtract: ['$end', '$start'] },
                  1000 * 60 // Convert milliseconds to minutes
                ]
              },
              fromName: '$fromAccount.fullName',
              toName: '$toAccount.fullName'
            }
          },
          {
            $project: {
              fromAccount: 0,
              toAccount: 0
            }
          }
        ]).exec();
        return { result, message: 'Got meeting history', code: 200 };
      } catch (error) {
        console.error(error);
        return response.response({ message: 'Failed', code: 400 }).code(400);
      }
    },
  },
  {
    method: "GET",
    path: "/{id}",
    options: {
      description: "Get a meeting",
      plugins: upcomingMeetingSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const result = await Meeting.findOne({ _id: request.params.id });
        return { result, message: 'Got a meeting', code: 200 };
      } catch (error) {
        console.error(error);
        return response.response({ message: 'Failed', code: 400 }).code(400);
      }
    },
  },
  {
    method: "POST",
    path: "/detail",
    options: {
      auth: "jwt",
      description: "Get meeting detail",
      plugins: upcomingMeetingSwagger,
      tags: ["api", "user"],
      validate: {
        payload: getMeetingDetailSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const clientEmail = request.auth.credentials.email;
        const _id = request.payload['_id'];
        const expertEmail = request.payload['to'];
        const meeting = await Meeting.findOne({ _id: _id });
        const meetingHistory = await Meeting.find({ from: clientEmail, to: expertEmail, status:"finished" });
        const expertAccount = await Account.findOne({ email: expertEmail });
        const result = {
          title: meeting.title,
          description: meeting.description,
          fullName: expertAccount.fullName,
          photo: expertAccount.photo,
          meetingHistory: meetingHistory
        }

        return response.response([{ result, message: "Meeting detail", code: 200 }]).code(200);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
];
