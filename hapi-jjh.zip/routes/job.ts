import { Request, ResponseToolkit } from "@hapi/hapi";
import Jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import fs from "fs";
import { ObjectId } from 'mongodb';

import { createJobSchema } from "../validation/job/create";
import { invitationSchema, proposalSchema, milestoneSchema } from "../validation/job/update";

import { createJobSwagger } from '../swagger/job/create';
import { invitationSwagger, proposalSwagger, activeJobsSwagger, milestoneSwagger, getMilestoneSwagger, getJobOverviewSwagger, searchJobSwagger } from '../swagger/job/update';
import Job from "../models/jobs";
import Client from "../models/clients";

const options = { abortEarly: false, stripUnknown: true };
export let jobRoute = [
  {
    method: "POST",
    path: "/",
    options: {
      auth: "jwt",
      description: "Create a job",
      plugins: createJobSwagger,
      tags: ["api", "user"],
      validate: {
        payload: createJobSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const newData = {
          type: request.payload['type'],
          title: request.payload['title'],
          description: request.payload['description'],
          questions: request.payload['questions'],
          duration: request.payload['duration'],
          client: email,
          skills: request.payload['skills'],
          industry: request.payload['industry'],
          tools: request.payload['tools'],
          visibility: request.payload['visibility'],
          budgetRange: request.payload['budgetRange'],
          weeklyCommitment: request.payload['weeklyCommitment'],
          status: "active",
        }
        const newContent: any = new Job(newData);
        const newResult = await newContent.save();
        return response.response([{ newResult, message: "Job created", code: 201 }]).code(201);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "PUT",
    path: "/invite",
    options: {
      description: "Invite an expert",
      plugins: invitationSwagger,
      tags: ["api", "user"],
      validate: {
        payload: invitationSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const job = await Job.findOne({ _id: request.payload['_id'] });
        if (!job) {
          return response.response([{ message: "Job not found", code: 404 }]).code(404);
        }
        const result = job.invitations.map((item) => item.expertEmail === request.payload['expertEmail']);
        if (result.includes(true)) {
          return response.response([{ message: "Already invited", code: 409 }]).code(409);
        }
        const invitation = {
          type: request.payload['type'],
          message: request.payload['message'],
          expertEmail: request.payload['expertEmail'],
          status: 'pending',
          createdAt: new Date()
        }
        job.invitations.push(invitation);
        const updateResult = await job.save();
        return response.response([{ message: "Invitation has been sent", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "PUT",
    path: "/proposal",
    options: {
      auth: "jwt",
      description: "Send a proposal",
      plugins: proposalSwagger,
      tags: ["api", "user"],
      validate: {
        payload: proposalSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const job = await Job.findOne({ _id: request.payload['_id'] });
        if (!job) {
          return response.response([{ message: "Job not found", code: 404 }]).code(404);
        }
        const result = job.proposals.map((item) => item.expertEmail === email);
        if (result.includes(true)) {
          return response.response([{ message: "Already sent a proposal", code: 409 }]).code(409);
        }
        const proposal = {
          type: request.payload['type'],
          milestones: request.payload['milestone'],
          coverLetter: request.payload['coverLetter'],
          expertEmail: email,
          status: 'pending',
          createdAt: new Date()
        }
        job.proposals.push(proposal);
        const updateResult = await job.save();
        return response.response([{ updateResult, message: "Proposal has been sent", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  // {
  //   method: "PUT",
  //   path: "/milestone",
  //   options: {
  //     auth: "jwt",
  //     description: "Set milestones",
  //     plugins: milestoneSwagger,
  //     tags: ["api", "user"],
  //     validate: {
  //       payload: milestoneSchema,
  //       options,
  //       failAction: (request, h, error) => {
  //         const details = error.details.map((d) => {
  //           return {
  //             message: d.message,
  //             path: d.path,
  //           };
  //         });
  //         return h.response(details).code(400).takeover();
  //       },
  //     },
  //   },
  //   handler: async (request: Request, response: ResponseToolkit) => {
  //     try {
  //       const email = request.auth.credentials.email;
  //       const job = await Job.findOne({ _id: request.payload['_id'] });
  //       if (!job) {
  //         return response.response([{ message: "Job not found", code: 404 }]).code(404);
  //       }
  //       const result = job.milestones.map((item) => item.expertEmail === email && item.milestoneNumber === request.payload['milestoneNumber']);
  //       if (result.includes(true)) {
  //         return response.response([{ message: "Already set a milestone", code: 409 }]).code(409);
  //       }
  //       const milestone = {
  //         milestoneNumber: request.payload['milestoneNumber'],
  //         price: request.payload['price'],
  //         startDate: request.payload['startDate'],
  //         endDate: request.payload['endDate'],
  //         description: request.payload['description'],
  //         expertEmail: email,
  //         status: "pending",
  //         createdAt: new Date(),
  //         updatedAt: new Date()
  //       }
  //       job.milestones.push(milestone);
  //       const updateResult = await job.save();
  //       return response.response([{ updateResult, message: "Proposal has been sent", code: 200 }]).code(200);
  //     } catch (error) {
  //       return response.response(error).code(500);
  //     }
  //   },
  // },
  {
    method: "GET",
    path: "/milestone/{id}",
    options: {
      auth: "jwt",
      description: "Get milestones",
      plugins: getMilestoneSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const _id = request.params.id;
        const milestones = await Job.find({ _id: _id, selectedExpert: email, }).select("milestones");
        if (!_id) {
          return response.response([{ message: "Provide id", code: 400 }]).code(400);
        }
        //const data = activeJobs.map((item) => item.activeJobs);
        return response.response([{ milestones, message: "Got milestones", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/active",
    options: {
      auth: "jwt",
      description: "Get active jobs for client",
      plugins: activeJobsSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const activeJobs = await Job.find({ status: "active", client: email });
        // if (!activeJobs) {
        //   return response.response([{ message: "Active Jobs not found", code: 404 }]).code(404);
        // }
        //const data = activeJobs.map((item) => item.activeJobs);
        return response.response([{ activeJobs, message: "Got active jobs", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/history",
    options: {
      auth: "jwt",
      description: "Get history jobs for client",
      plugins: activeJobsSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const historyJobs = await Job.find({ status: "completed", client: email });
        // if (!activeJobs) {
        //   return response.response([{ message: "Active Jobs not found", code: 404 }]).code(404);
        // }
        //const data = activeJobs.map((item) => item.activeJobs);
        return response.response([{ historyJobs, message: "Got history jobs", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/expert/{type}",
    options: {
      auth: "jwt",
      description: "Get active jobs for expert",
      plugins: activeJobsSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        // const activeJobs = await Job.find({ status: "active", selectedExpert: email });
        const activeJobs = await Job.aggregate([
          {
            $match: {
              status: request.params.type,
              selectedExpert: email
            }
          },
          {
            $lookup: {
              from: 'clients',
              localField: 'client',
              foreignField: 'email',
              as: 'clients'
            }
          },
          {
            $unwind: {
              path: '$clients',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'client',
              foreignField: 'email',
              as: 'accounts'
            }
          },
          {
            $unwind: {
              path: '$accounts',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $project: {
              // ...Object.keys(Job.schema.obj).reduce((acc, key) => {
              //   acc[`${key}`] = 1;
              //   return acc;
              // }, {}),
              _id: 1,
              fullName: '$accounts.fullName',
              organization: '$clients.organization.organizationName',
              engagement: '$type',
              description: '$description',
              startDate: '$createdAt',
              country: '$clients.country',
              cost: '$contractCost',
              numberOfMeetings: "0",
              nextMeeting: "Not Scheduled",
              // Include other fields from the job document if needed
            }
          }
        ]).exec();
        // if (activeJobs.length == 0) {
        //   return response.response([{ message: request.params.type + " Jobs not found", code: 404 }]).code(404);
        // }
        //const data = activeJobs.map((item) => item.activeJobs);
        return response.response([{ activeJobs, message: "Got jobs", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/overview/{id}",
    options: {
      auth: "jwt",
      description: "Get job overview",
      plugins: getJobOverviewSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const _id = request.params.id;
        if (!_id) {
          return response.response([{ message: "Provide id", code: 400 }]).code(400);
        }
        const jobOverview = await Job.findOne({ _id: new ObjectId(_id) });
        const proposalReceived = await Job.aggregate([
          {
            $match: {
              _id: new ObjectId(_id)
              //status: "active" 
            }
          },
          {
            $unwind: {
              path: '$proposals',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'experts',
              localField: 'proposals.expertEmail',
              foreignField: 'email',
              as: 'job-expert'
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'proposals.expertEmail',
              foreignField: 'email',
              as: 'job-account'
            }
          },
          {
            $project: {
              _id: 1,
              name: '$job-account.fullName',
              expertEmail: '$job-expert.email',
              hourlyRate: '$job-expert.hourlyRate',
              relevance: '$job-expert.hourlyRate',
              companyName: '$job-expert.hourlyRate',
              position: '$job-expert.titleName',
              experience: '5 Years',
              location: '$job-expert.country',
              availability: '$job-expert.weeklyCommitment',
              status: { $ifNull: ["$proposals.status", ""] },
              milestone: { $ifNull: ["$proposals.milestones", []] },
              coverLetter: { $ifNull: ["$proposals.coverLetter", ""] },
              projectTerms: { $ifNull: ["$proposals.type", ""] },
            }
          }
        ]).exec();
        const invites = await Job.aggregate([
          {
            $match: {
              _id: new ObjectId(_id)
              //status: "active" 
            }
          },
          {
            $unwind: {
              path: '$invitations',
              preserveNullAndEmptyArrays: true
            }
          },
          {
            $lookup: {
              from: 'experts',
              localField: 'invitations.expertEmail',
              foreignField: 'email',
              as: 'job-expert'
            }
          },
          {
            $lookup: {
              from: 'accounts',
              localField: 'invitations.expertEmail',
              foreignField: 'email',
              as: 'job-account'
            }
          },
          {
            $project: {
              _id: 1,
              name: '$job-account.fullName',
              hourlyRate: '$job-expert.hourlyRate',
              relevance: '$job-expert.hourlyRate',
              companyName: '$job-expert.hourlyRate',
              position: '$job-expert.titleName',
              experience: '5 Years',
              location: '$job-expert.country',
              availability: '$job-expert.weeklyCommitment',
              status: '',
            }
          }
        ]).exec();
        const myHires = await Job.aggregate([
          {
            $match: {
              _id: new ObjectId(_id),
              //status: "active" 
            }
          },
          {
            $unwind: {
              path: '$proposals',
              preserveNullAndEmptyArrays: true,
            }
          },
          {
            $lookup: {
              from: 'experts',
              localField: 'proposals.expertEmail',
              foreignField: 'email',
              as: 'job-expert'
            }
          },
          { $match: { 'proposals.status': 'accepted' } },
          {
            $lookup: {
              from: 'accounts',
              localField: 'proposals.expertEmail',
              foreignField: 'email',
              as: 'job-account'
            }
          },
          {
            $project: {
              _id: 1,
              expertName: '$job-account.fullName',
              rate: '$job-expert.hourlyRate',
              contractType: '$type',
              noOfMeeting: '',
              nextMeeting: '',
              location: '$job-expert.country',
            }
          }
        ]).exec();
        return response.response([{ invites, myHires, proposalReceived, jobOverview, message: "Got proposals", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "POST",
    path: "/search",
    options: {
      auth: "jwt",
      description: "Job search",
      plugins: searchJobSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const searchQuery = request.payload["query"];
        // const result = await Job.find({
        //   $or: [
        //     { title: { $regex: searchQuery, $options: 'i' } },
        //     { description: { $regex: searchQuery, $options: 'i' } }
        //   ]
        // });
        const result = await Job.aggregate([
          {
            $match: {
              $or: [
                { title: { $regex: searchQuery, $options: 'i' } },
                { description: { $regex: searchQuery, $options: 'i' } }
              ]
            }
          },
          {
            $lookup: {
              from: 'clients',
              localField: 'client',
              foreignField: 'email',
              as: 'client'
            }
          },
          {
            $unwind: '$client'
          },
          {
            $project: {
              _id: 1,
              ...Object.keys(Job.schema.obj).reduce((acc, key) => {
                acc[`${key}`] = 1;
                return acc;
              }, {}),
              country: '$client.country',
              verifiyStatus: 'Verified',
            }
          }
        ]).exec();
        return response.response([{ result, message: "Got overview", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "PUT",
    path: "/hire",
    options: {
      auth: "jwt",
      description: "Hire an expert",
      plugins: searchJobSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const expertEmail = request.payload["expertEmail"];
        const _id = request.payload["_id"];
        if (!expertEmail) {
          return response.response([{ message: "Please provide a expertEmail", code: 400 }]).code(400);
        }

        // const result = await Job.find({
        //   $or: [
        //     { title: { $regex: searchQuery, $options: 'i' } },
        //     { description: { $regex: searchQuery, $options: 'i' } }
        //   ]
        // });
        const result = await Job.updateOne(
          { "_id": new ObjectId(_id) },
          { $set: { "proposals.$[m].status": "accepted" } },
          {
            arrayFilters: [{ "m.expertEmail": expertEmail }]
          });
        if(result.modifiedCount == 1){
          return response.response([{ result, message: "Hired", code: 200 }]).code(200);
        }
        else{
          return response.response([{ message: "failed", code: 400 }]).code(400);
        }
        
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
];
