import { Request, ResponseToolkit } from "@hapi/hapi";
import Jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import fs from "fs";

import { createMessageSchema, getChatHistorySchema } from "../validation/message/create";

import { createMessageSwagger, deleteMessageSwagger, getChatHistorySwagger } from '../swagger/message/create';

import Message from "../models/messages";

const options = { abortEarly: false, stripUnknown: true };
export let messageRoute = [
  {
    method: "POST",
    path: "/",
    options: {
      auth: "jwt",
      description: "Create a new message",
      plugins: createMessageSwagger,
      tags: ["api", "user"],
      validate: {
        payload: createMessageSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const newData = {
          type: request.payload['type'],
          from: email,
          to: request.payload['to'],
          text: request.payload['text'],
        }
        const newContent: any = new Message(newData);
        const newResult = await newContent.save();
        return response.response([{ newResult, message: "Message created", code: 201 }]).code(201);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "DELETE",
    path: "/{id}",
    options: {
      auth: "jwt",
      description: "Delete a message",
      plugins: deleteMessageSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const id = request.params.id;

        await Message.deleteOne({ _id: id, from: email });

        return response.response([{ message: "Message deleted", code: 204 }]).code(204);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/users",
    options: {
      auth: "jwt",
      description: "Get user list",
      plugins: createMessageSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;

        const result_1 = await Message.aggregate([
          {
            $match: {
              from: email
            }
          },
          { $group: { _id: '$to' } },
          { $lookup: { from: 'accounts', localField: '_id', foreignField: 'email', as: 'account' } },
          // { $unwind: '$account' },
          { $project: { email: '$_id', name: '$account.fullName', photo: '$account.photo' } }]).exec();

        const result_2 = await Message.aggregate([
          {
            $match: {
              to: email
            }
          },
          { $group: { _id: '$from' } },
          { $lookup: { from: 'accounts', localField: '_id', foreignField: 'email', as: 'account' } },
          // { $unwind: '$account' },
          { $project: { email: '$_id', name: '$account.fullName', photo: '$account.photo' } }]).exec();

        const result = result_1.concat(result_2);
        // const result = Object.values(
        //   data.reduce((carry, item) => {
        //     const key = item.key;
        //     if (carry[key]) {
        //       carry[key].value += `, ${item.value}`;
        //     } else {
        //       carry[key] = item;
        //     }
        //     return carry;
        //   }, {})
        // );
        //const data = result.map((item) => item._id);
        return { result, message: 'Got users', code: 200 };
      } catch (error) {
        console.error(error);
        return response.response({ message: 'Failed', code: 400 }).code(400);
      }
    },
  },
  {
    method: "GET",
    path: "/history/{to}",
    options: {
      auth: "jwt",
      description: "Get chat history",
      plugins: getChatHistorySwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const to = request.params.to;
        const result = await Message.find({
          $or: [
            { from: email, to: to },
            { from: to, to: email }
          ]
        }).sort({ createdAt: 1 }).exec();

        return response.response({ result, message: 'Got chat history', code: 200 }).code(200);
      } catch (error) {
        return response.response({ message: 'Error', code: 500 }).code(500);
      }
    }
  }

];
