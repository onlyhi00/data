import { Server } from "@hapi/hapi";

import config from "../config";

import { userRoute } from "./user";
import { dataRoute } from "./data";
import { jobRoute } from "./job";
import { paymentRoute } from "./payment";
import { messageRoute } from "./message";
import { meetingRoute } from "./meeting";

const prefix = `/api/${config.apiVersion}`;

const setRoutes = async (server: Server) => {
  server.realm.modifiers.route.prefix = `/api/${config.apiVersion}/user`;
  server.route(userRoute);
  
  server.realm.modifiers.route.prefix = `/api/${config.apiVersion}/data`;
  server.route(dataRoute);

  server.realm.modifiers.route.prefix = `/api/${config.apiVersion}/payment`;
  server.route(paymentRoute);

  server.realm.modifiers.route.prefix = `/api/${config.apiVersion}/job`;
  server.route(jobRoute);

  server.realm.modifiers.route.prefix = `/api/${config.apiVersion}/message`;
  server.route(messageRoute);

  server.realm.modifiers.route.prefix = `/api/${config.apiVersion}/meeting`;
  server.route(meetingRoute);

};
export default setRoutes;
