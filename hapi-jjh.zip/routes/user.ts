import { Request, ResponseToolkit } from "@hapi/hapi";
import Jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import fs from "fs";

import Account from "../models/accounts";
import Client from "../models/clients";
import Expert from "../models/experts";
import config from "../config";
import sendMail from "../utils/sendmail";
import GenerateOTP from "../utils/otp";

import { createUserSchema, expertRegisterSchema, clientRegisterSchema, orgRegisterSchema } from "../validation/user/register";
import { verifyEmailSchema, verifyOTPSchema, verifyOTPResendSchema } from "../validation/user/verify";
import { userLoginSchema, userUpdateSchema, currentUserSchema, resetPasswordSchema, recommendedExpertSchema,clientHistorySchema } from "../validation/user/account";

import { userRegisterSwagger, expertRegisterSwagger, clientRegisterSwagger } from '../swagger/user/register';
import { verifyEmailSwagger, verifyEmailResendSwagger, resendOTPVerifySwagger, OTPSwagger } from '../swagger/user/verify';
import { userLoginSwagger, resetPasswordSwagger, currentUserSwagger, userUpdateSwagger, recommendedExpertSwagger } from '../swagger/user/account';

const options = { abortEarly: false, stripUnknown: true };
export let userRoute = [
  {
    method: "POST",
    path: "/register",
    options: {
      description: "Register User",
      plugins: userRegisterSwagger,
      tags: ["api", "user"],
      validate: {
        payload: createUserSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.payload["email"];
        const user = await Account.findOne({ email });
        if (user) {
          return response.response([{ message: "User already exists.", code: 409 }]).code(409);
        }

        // get account data from request data
        const newAccountData = {
          email: request.payload['email'],
          password: request.payload['password'],
          type: request.payload['type'],
          fullName: request.payload['fullName'],
          emailVerifyStatus: "unverified",
          passwordResetAllow: "no",
          status: "allowed"
        }
        const newAccount: any = new Account(newAccountData);

        // save account in db after hashing password
        const { password } = newAccount;
        const hash = await bcrypt.hash(password, 10);
        newAccount.password = hash;
        const accountResult = await newAccount.save();
        const token = Jwt.sign(
          { userId: accountResult._id, email: accountResult.email },
          config.jwtSecret,
          {
            expiresIn: "3m",
          }
        );
        const baseUrl = `${request.server.info.protocol}://${request.info.host}`;
        const content = `<div style="background-color: #f2f2f2; padding: 20px; border-radius: 10px;"><h1 style="font-size: 36px; color: #333; margin-bottom: 20px;">Hello</h1><p style="font-size: 18px; color: #666; margin-bottom: 20px;">Welcome!</p><p style="font-size: 18px; color: #666; margin-bottom: 40px;">This is your email verification link. Please click the button below to verify your email:</p><a href="${baseUrl}/api/v1/user/verify-email/${token}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 10px; font-size: 18px;">Verify Email</a></div>`;
        sendMail(accountResult.email, content);
        return response.response([{ accountResult, code: 201 }]).code(201);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "PUT",
    path: "/update-account",
    options: {
      auth: "jwt",
      description: "Update account",
      plugins: userUpdateSwagger,
      tags: ["api", "user"],
      validate: {
        payload: userUpdateSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const firstName = request.payload["firstName"];
        const lastName = request.payload["lastName"];
        const phoneNumber = request.payload["phoneNumber"];
        const password = request.payload["password"];
        const hash = await bcrypt.hash(password, 10);
        // const fullName = firstName + " " + lastName;
        const account = await Account.findOne({ email });
        if (!account) return response.response([{ message: "User not found", code: 404 }]).code(404);
        account.fullName = firstName;
        account.password = hash;
        account.phoneNumber = phoneNumber;
        await account.save();
        return response.response([{  message: "Successfully updated", code: 200 }]).code(200);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "POST",
    path: "/expert",
    options: {
      auth: "jwt",
      description: "Register Expert",
      plugins: expertRegisterSwagger,
      tags: ["api", "user"],
      validate: {
        payload: expertRegisterSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const expert = await Expert.findOne({ email });
        if (expert) {
          expert.titleName = request.payload['titleName'];
          expert.summary = request.payload['summary'];
          expert.birthday = request.payload['birthday'];
          expert.country = request.payload['country'];
          expert.languages = request.payload['languages'];
          expert.socialMedia = request.payload['socialMedia'];
          expert.address = request.payload['address'];
          expert.zipCode = request.payload['zipCode'];
          expert.weeklyCommitment = request.payload['weeklyCommitment'];
          expert.hourlyRate = request.payload['hourlyRate'];
          expert.projectPreference = request.payload['projectPreference'];
          expert.tools = request.payload['tools'];
          expert.skills = request.payload['skills'];
          expert.education = request.payload['education'];
          expert.experience = request.payload['experience'];
          expert.profileCompleteness = 0;
          await expert.save();
          return response.response([{ message: "Expert updated", code: 200 }]).code(200);
        }
        const newExpertData = {
          email: email,
          titleName: request.payload['titleName'],
          summary: request.payload['summary'],
          birthday: request.payload['birthday'],
          country: request.payload['country'],
          languages: request.payload['languages'],
          socialMedia: request.payload['socialMedia'],
          address: request.payload['address'],
          zipCode: request.payload['zipCode'],
          industry: request.payload['industry'],
          weeklyCommitment: request.payload['weeklyCommitment'],
          hourlyRate: request.payload['hourlyRate'],
          projectPreference: request.payload['projectPreference'],
          tools: request.payload['tools'],
          skills: request.payload['skills'],
          education: request.payload['education'],
          experience: request.payload['experience'],
          profileCompleteness: 0,
        }
        const newExpert: any = new Expert(newExpertData);
        await newExpert.save();
        return response.response([{ message: "Expert inserted", code: 201 }]).code(201);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "POST",
    path: "/client",
    options: {
      auth: "jwt",
      description: "Register Client",
      plugins: clientRegisterSwagger,
      tags: ["api", "user"],
      validate: {
        payload: clientRegisterSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const client = await Client.findOne({ email });
        if (client) {
            client.birthday = request.payload['birthday'],
            client.country = request.payload['country'],
            client.languages = request.payload['languages'],
            client.socialMedia = request.payload['socialMedia'],
            await client.save();
          return response.response([{ message: "Client updated", code: 200 }]).code(200);
        }
        const newClientData = {
          email: email,
          birthday: request.payload['birthday'],
          country: request.payload['country'],
          languages: request.payload['languages'],
          socialMedia: request.payload['socialMedia'],
        }
        const newClient: any = new Client(newClientData);
        await newClient.save();
        return response.response([{ message: "Client inserted", code: 201 }]).code(201);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "POST",
    path: "/client-organization",
    options: {
      auth: "jwt",
      description: "Register Client Organization",
      plugins: clientRegisterSwagger,
      tags: ["api", "user"],
      validate: {
        payload: orgRegisterSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const client = await Client.findOne({ email });
        if (client) {
          client.organization = request.payload['organization'],
            await client.save();
          return response.response([{ message: "Client updated", code: 200 }]).code(200);
        }
        const newClientData = {
          email: email,
          organization: request.payload['organization'],
        }
        const newClient: any = new Client(newClientData);
        await newClient.save();
        return response.response([{ message: "Client inserted", code: 201 }]).code(201);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/verify-email/{token}",
    options: {
      description: "Verify Email",
      plugins: verifyEmailSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      const success = fs.readFileSync("./utils/emailVeriffSucess.txt");
      const failed = fs.readFileSync("./utils/emailVeriffFail.txt");
      const decoded = Jwt.decode(request.params.token);
      if (decoded === null) {
        return failed.toLocaleString();
      }
      const currentTime = Date.now() / 1000;
      if (decoded.exp < currentTime) {
        return failed.toLocaleString();
      }
      const user = await Account.findById(decoded.userId);
      if (user) {
        user.emailVerifyStatus = "verified";
        await user.save();
        return success.toLocaleString();
      }
      return failed.toLocaleString();
    },
  },
  {
    method: "POST",
    path: "/verify-email-resend",
    options: {
      description: "Resend Email Verification",
      plugins: verifyEmailResendSwagger,
      tags: ["api", "user"],
      validate: {
        payload: verifyEmailSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      const user = await Account.findOne({ email: request.payload["email"] });
      if (user) {
        const token = Jwt.sign(
          { userId: user._id, email: user.email },
          config.jwtSecret,
          {
            expiresIn: "3m",
          }
        );
        const baseUrl = `${request.server.info.protocol}://${request.info.host}`;
        const content = `<div style="background-color: #f2f2f2; padding: 20px; border-radius: 10px;"><h1 style="font-size: 36px; color: #333; margin-bottom: 20px;">Hello</h1><p style="font-size: 18px; color: #666; margin-bottom: 20px;">Welcome To DVS!</p><p style="font-size: 18px; color: #666; margin-bottom: 40px;">This is your email verification link. Please click the button below to verify your email:</p><a href="${baseUrl}/api/v1/user/verify-email/${token}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 10px; font-size: 18px;">Verify Email</a></div>`;
        sendMail(user.email, content);
        return response.response([{
          message: "Email verification has sent to your email",
          code: 200
        }]).code(200);
      }
      return response.response([{ message: "User not found", path: ["email"], code: 404 }]).code(404);
    },
  },
  {
    method: "POST",
    path: "/login",
    options: {
      description: "User Login",
      plugins: userLoginSwagger,
      tags: ["api", "user"],
      validate: {
        payload: userLoginSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      const user = await Account.findOne({ email: request.payload["email"] });
      if (user) {
        const hpass = await bcrypt.compare(
          request.payload["password"],
          user.password
        );
        try {
          if (hpass) {
            if (user.emailVerifyStatus === 'verified') {
              const token = Jwt.sign(
                { userId: user._id, email: user.email, userType:request.payload["type"]   },
                config.jwtSecret,
                {
                  expiresIn: "1h",
                }
              );
              const info = {
                email: user.email,
                type: request.payload["type"],
                fullName: user.fullName,
                photo: user.photo,
                status: user.status,
                emailVerifyStatus: user.emailVerifyStatus,
              }
              return response
                .response([{
                  token,
                  info: info,
                  code: 200
                }])
                .code(200);
            } else {
              const token = Jwt.sign(
                { userId: user._id, email: user.email },
                config.jwtSecret,
                {
                  expiresIn: "3m",
                }
              );
              const baseUrl = `${request.server.info.protocol}://${request.info.host}`;
              const content = `<div style="background-color: #f2f2f2; padding: 20px; border-radius: 10px;"><h1 style="font-size: 36px; color: #333; margin-bottom: 20px;">Hello</h1><p style="font-size: 18px; color: #666; margin-bottom: 20px;">Welcome!</p><p style="font-size: 18px; color: #666; margin-bottom: 40px;">This is your email verification link. Please click the button below to verify your email:</p><a href="${baseUrl}/api/v1/user/verify-email/${token}" style="background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 10px; font-size: 18px;">Verify Email</a></div>`;
              sendMail(user.email, content);
              return response.response([{
                message: "Email verification has sent to your email",
                code: 403
              }]).code(403);
            }
          } else {
            return response
              .response([
                { message: "Password is incorrect", path: ["password"], code: 401 },
              ])
              .code(401);
          }
        } catch (error) {
          console.log(error);
        }
      }
      return response
        .response([{ message: "User not found", path: ["email"], code: 404 }])
        .code(404);
    },
  },
  {
    method: "POST",
    path: "/otp-verify-send",
    options: {
      description: "Resend OTP Verification Code",
      plugins: resendOTPVerifySwagger,
      tags: ["api", "user"],
      validate: {
        payload: verifyOTPResendSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      const user = await Account.findOne({ email: request.payload["email"] });
      if (user) {
        const token = Jwt.sign(
          { userId: user._id, email: user.email },
          config.jwtSecret,
          {
            expiresIn: "3m",
          }
        );
        if (user.emailVerifyStatus === "verified") {
          const otp = GenerateOTP();
          user.otp = otp;
          const result = await user.save();
          const content = `<div style="background-color: #f2f2f2; padding: 20px; border-radius: 10px;"><h1 style="font-size: 36px; color: #333; margin-bottom: 20px;">Hello</h1><p style="font-size: 18px; color: #666; margin-bottom: 20px;">Welcome To DVS!</p><p style="font-size: 18px; color: #666; margin-bottom: 40px;">This is your OTP code : <b>${result.otp}</b></p></div>`;
          sendMail(result.email, content);
          return response.response([{
            message: "OTP Code has just sent to your email.",
            code: 200
          }]);
        } else {
          return response.response([{ message: "You need to verify email first", code: 400 }]).code(400);
        }
      }
      return response.response([{ message: "User not found", path: ["email"], code: 404 }]).code(404);
    },
  },
  {
    method: "POST",
    path: "/verify-otp",
    options: {
      description: "Verify OTP",
      plugins: OTPSwagger,
      tags: ["api", "user"],
      validate: {
        payload: verifyOTPSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request, response: ResponseToolkit) => {
      const user = await Account.findOne({ email: request.payload["email"] });
      if (user) {
        if (user.otp === request.payload["otp"]) {
          user.passwordResetAllow = 'yes';
          await user.save();
          const token = Jwt.sign(
            { userId: user._id, email: user.email },
            config.jwtSecret,
            {
              expiresIn: "3h",
            }
          );
          return response
            .response([{
              token,
              info: user,
              code: 200
            }])
            .code(200);
        }
      }
      return response.response([{ message: "OTP Verification Failed.", code: 400 }]).code(400);
    },
  },
  {
    method: "POST",
    path: "/reset-password",
    options: {
      description: "Reset Password",
      plugins: resetPasswordSwagger,
      tags: ["api", "user"],
      validate: {
        payload: resetPasswordSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request, response: ResponseToolkit) => {
      const user = await Account.findOne({ email: request.payload["email"] });
      if (user) {
        if (user.passwordResetAllow === "yes") {
          const hash = await bcrypt.hash(request.payload["password"], 10);
          user.password = hash;
          user.passwordResetAllow = 'no';
          await user.save();
          return response.response([{ message: "Your password has been successfully changed.", code: 200 }]).code(200);
        }
        else return response.response([{ message: "Changing password is not allowed.", code: 401 }]).code(401);
      }
      return response.response([{ message: "Email is not found.", code: 404 }]).code(404);
    },
  },
  {
    method: "GET",
    path: "/current",
    options: {
      auth: "jwt",
      description: "Get current user by token",
      plugins: currentUserSwagger,
      tags: ["api", "user"],
      validate: {
        query: currentUserSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
      handler: async (request: Request, response: ResponseToolkit) => {
        const userId = request.auth.credentials.userId;
        if (userId) {
          const email = request.auth.credentials.email;
          const userType = request.auth.credentials.userType;
          const account = await Account.findOne({ email });
          const expert = await Expert.findOne({ email });
          const client = await Client.findOne({ email });
          const userData = {
            _id: userId,
            email: account.email,
            fullName: account.fullName,
            status: account.status,
            emailVerifyStatus: account.emailVerifyStatus,
            type: userType,
            expert: expert,
            client: client,
          };
          return response.response([{ currentUser: userData, code: 200 }]).code(200);
        }
        return response.response([{ message: "Not Signed", code: 401 }]).code(401);
      },
    },
  },
  {
    method: "POST",
    path: "/recommended-expert",
    options: {
      description: "Get recommended experts",
      plugins: recommendedExpertSwagger,
      tags: ["api", "user"],
      validate: {
        payload: recommendedExpertSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
      handler: async (request: Request, response: ResponseToolkit) => {
        const expert = await Expert.aggregate([
          {
            $lookup: {
              from: 'accounts',
              localField: 'email',
              foreignField: 'email',
              as: 'account'
            }
          },
          {
            $unwind: '$account'
          },
          {
            $project: {
              _id: 0,
              ...Object.keys(Expert.schema.obj).reduce((acc, key) => {
                acc[`${key}`] = 1;
                return acc;
              }, {}),
              name: '$account.fullName'
            }
          }
        ]).exec();
        return response.response([{ expert: expert, message: "Got recommended experts", code: 200 }]).code(200);
      },
    },
  },
  {
    method: "POST",
    path: "/client-history",
    options: {
      description: "Get client history",
      plugins: recommendedExpertSwagger,
      tags: ["api", "user"],
      validate: {
        payload: clientHistorySchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
      handler: async (request: Request, response: ResponseToolkit) => {
        const result = await Client.aggregate([
          {
            $match: { email: request.payload['email'] }
          },
          {
            $lookup: {
              from: 'jobs',
              localField: 'email',
              foreignField: 'client',
              as: 'posted'
            }
          },
          {
            $unwind: '$posted'
          },
          {
            $group: {
              _id: '$email',
              cpd: { $sum: 1 }
            }
          },
          {
            $lookup: {
              from: 'jobs',
              localField: 'email',
              foreignField: 'client',
              as: 'hired'
            }
          },
          {
            $unwind: '$hired'
          },
          {
            $match: { 'hired.status': 'completed' }
          },
          {
            $group: {
              _id: '$email',
              cpd: { $first: '$cpd' },
              hired: { $sum: 1 }
            }
          },
          {
            $project: {
              _id: 0,
              posted: '$cpd',
              hired: 1
            }
          }
        ]).exec();
        return response.response([{ result, message: "Got  client history", code: 200 }]).code(200);
      },
    },
  }

];
