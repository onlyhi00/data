import { Request, ResponseToolkit } from "@hapi/hapi";
import { createSchema } from "../validation/data/create";
import { getDataSchema } from "../validation/data/get";

import { createSwagger } from '../swagger/data/create';
import { getSwagger } from '../swagger/data/get';
import Industry from "../models/industries";
import Skill from "../models/skills";
import Tool from "../models/tools";
import Expertise from "../models/expertise";
import budgetRange from "../models/budgetRange";
import weeklyCommitment from "../models/weeklyCommitment";
import duration from "../models/duration";
import BudgetRange from "../models/budgetRange";
import WeeklyCommitment from "../models/weeklyCommitment";
import Duration from "../models/duration";

const options = { abortEarly: false, stripUnknown: true };
export let dataRoute = [
  {
    method: "POST",
    path: "/{target}",
    options: {
      description: "Create data",
      plugins: createSwagger,
      tags: ["api", "user"],
      validate: {
        payload: createSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const newData = {
          name: request.payload['name'],
        }
        const target = request.params.target;
        let newContent: any;
        if (!target) return response.response([{ message: "No target" }, { code: 404 }]).code(404);
        if (target == "industry") newContent = new Industry(newData);
        if (target == "skill") newContent = new Skill(newData);
        if (target == "tool") newContent = new Tool(newData);
        if (target == "expertise") newContent = new Expertise(newData);
        if (target == "budgetRange") newContent = new BudgetRange(newData);
        if (target == "weeklyCommitment") newContent = new WeeklyCommitment(newData);
        if (target == "duration") newContent = new Duration(newData);
        const contentResult = await newContent.save();
        return response.response([{ contentResult, code: 201 }]).code(201);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/{target}",
    options: {
      description: "Get data",
      plugins: getSwagger,
      tags: ["api", "user"],
      validate: {
        params: getDataSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const target = request.params.target;
        let dropData: any;
        if (!target) return response.response([{ message: "No target" }, { code: 404 }]).code(404);
        if (target == "tool") {
          dropData = await Tool.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        if (target == "skill") {
          dropData = await Skill.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        if (target == "industry") {
          dropData = await Industry.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        if (target == "expertise") {
          dropData = await Expertise.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        if (target == "budgetRange") {
          dropData = await BudgetRange.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        if (target == "weeklyCommitment") {
          dropData = await WeeklyCommitment.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        if (target == "duration") {
          dropData = await Duration.find().select("name");
          const data = dropData.map((item) => item.name);
          return response.response({  data, code: 200 }).code(200);
        }
        return response.response([{ message: "No data", code: 404 }]).code(404);
      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
];
