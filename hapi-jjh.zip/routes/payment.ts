import { Request, ResponseToolkit } from "@hapi/hapi";
// import Jwt from "jsonwebtoken";
// import bcrypt from "bcrypt";
// import fs from "fs";

import { addPaymentMethodSchema, getPaymentMethodSchema } from "../validation/payment/setting";

import { addPaymentMethodSwagger, getPaymentMethodSwagger } from '../swagger/payment/setting';

import PaySetting from "../models/paySetting";
import Account from "../models/accounts";

const options = { abortEarly: false, stripUnknown: true };

export let paymentRoute = [
  {
    method: "POST",
    path: "/setting",
    options: {
      auth: "jwt",
      description: "Add Payment Method",
      plugins: addPaymentMethodSwagger,
      tags: ["api", "user"],
      validate: {
        payload: addPaymentMethodSchema,
        options,
        failAction: (request, h, error) => {
          const details = error.details.map((d) => {
            return {
              message: d.message,
              path: d.path,
            };
          });
          return h.response(details).code(400).takeover();
        },
      },
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const user = await Account.findOne({ email: email });
        if(!user) return response.response([{ message: "User not found", code: 404 }]).code(404);
        const newData = {
          userEmail: email,
          method: request.payload['method'],
          billingEmail: request.payload['billingEmail'],
          billingFullname: request.payload['billingFullname'],
          billingCountry: request.payload['billingCountry'],
          billingState: request.payload['billingState'],
          billingZipCode: request.payload['billingZipCode'],
          cardNumber: request.payload['cardNumber'],
          cardExpirationDate: request.payload['cardExpirationDate'],
          cardSecurityCode: request.payload['cardSecurityCode'],
          paypal: request.payload['paypal'],
        }
        const newContent: any = new PaySetting(newData);
        const newResult = await newContent.save();
        return response.response([{ newResult, message: "Sucessfully added", code: 201 }]).code(201);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  },
  {
    method: "GET",
    path: "/setting",
    options: {
      auth: "jwt",
      description: "Get Payment method for logined user",
      plugins: getPaymentMethodSwagger,
      tags: ["api", "user"],
    },
    handler: async (request: Request, response: ResponseToolkit) => {
      try {
        const email = request.auth.credentials.email;
        const user = await Account.find({ email: email });
        if(!user) return response.response([{ message: "User not found", code: 404 }]).code(404);

        const methods = await PaySetting.find({ userEmail: email});
        return response.response([{ methods: methods, message: "Got payment methods info", code: 200 }]).code(200);

      } catch (error) {
        return response.response(error).code(500);
      }
    },
  }
];
