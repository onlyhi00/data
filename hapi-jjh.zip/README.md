This is starter template for Node.js + HApi + Mongoose

The template use Mongodb Atlas for database.
