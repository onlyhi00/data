import mongoose from "mongoose";

const Schema = mongoose.Schema;
const durationSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
});

const Duration = mongoose.model("duration", durationSchema);
export default Duration;
