import mongoose from "mongoose";

const Schema = mongoose.Schema;
const jobSchema = new Schema({
    type: {
        type: String,
        enum: ["project", "fractionalServices", "onDemandConsultancy", "mentor"],
    },
    title: {
        type: String,
        required: true,
    },
    description: {
        type: String,
        required: false,
    },
    questions: {
        type: Array,
        required: false,
    },
    client: {
        type: String,
        required: false,
    },
    duration: {
        type: String,
        required: false,
    },
    weeklyCommitment: {
        type: String,
        required: false,
    },
    status: {
        type: String,
        required: false,
    },
    skills: {
        type: Array,
        required: false,
    },
    industry: {
        type: Array,
        required: false,
    },
    tools: {
        type: Array,
        required: false,
    },
    visibility: {
        type: String,
        enum: ["public", "inviteOnly"],
    },
    budgetRange: {
        type: Array,
        required: false,
    },
    invitations: [{
        type: {
            type: String,
            enum: ["meeting", "proposal"],
        },
        message: {
            type: String,
            required: false
        },
        expertEmail: {
            type: String,
            required: false
        },
        createdAt: {
            type: Date,
            required: false
        }
    }],
    proposals: [{
        type: {
            type: String,
            enum: ["milestone", "project"],
        },
        expertEmail: {
            type: String,
            required: false
        },
        status: {
            type: String,
            enum: ["pending", "accepted", "rejected"],
        },
        coverLetter: {
            type: String,
            required: false
        },
        createdAt: {
            type: Date,
            required: false
        },
        milestones: [{
            milestoneNumber: {
                type: Number,
                required: false
            },
            description: {
                type: String,
                required: false
            },
            endDate: {
                type: Date,
                required: false
            },
            amount: {
                type: Number,
                required: false
            },
        }],
    }],
    contract: [{
        type: {
            type: String,
            enum: ["milestone", "project"],
        },
        selectedExpert: {
            type: String,
            required: false,
        },
        milestones: [{
            milestoneNumber: {
                type: Number,
                required: false
            },
            description: {
                type: String,
                required: false
            },
            endDate: {
                type: Date,
                required: false
            },
            amount: {
                type: Number,
                required: false
            },
            status: {
                type: String,
                required: false
            },
        }],

        contractCost: {
            type: Number,
            required: false,
        },
        contractHourlyCost: {
            type: Number,
            required: false,
        },
        contractDate: {
            type: Date,
            required: false,
        },
    }],
    createdAt: {
        type: Date,
        default: Date.now(),
    },
    updatedAt: {
        type: Date,
        default: Date.now(),
    },
});

const Job = mongoose.model("job", jobSchema);
export default Job;
