import mongoose from "mongoose";

const Schema = mongoose.Schema;
const budgetRangeSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
});

const BudgetRange = mongoose.model("budgetrange", budgetRangeSchema);
export default BudgetRange;
