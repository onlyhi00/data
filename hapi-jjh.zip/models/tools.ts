import mongoose from "mongoose";

const Schema = mongoose.Schema;
const toolSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
});

const Tool = mongoose.model("tool", toolSchema);
export default Tool;
