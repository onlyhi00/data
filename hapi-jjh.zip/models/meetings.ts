import mongoose from "mongoose";

const Schema = mongoose.Schema;
const meetingSchema = new Schema({
  type: {
    type: String,
    required: false,
  },
  from: {
    type: String,
    required: false,
  },
  to: {
    type: String,
    required: false,
  },
  title: {
    type: String,
    required: false,
  },
  description: {
    type: String,
    required: false,
  },
  start: {
    type: Date,
    required: false,
  },
  end: {
    type: Date,
    required: false,
  },
  video: {
    type: Boolean,
    required: false,
  },
  color: {
    type: String,
    required: false,
  },
  textColor: {
    type: String,
    required: false,
  },
  status: {
    type: String,
    required: false,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
  lastLoggedIn: {
    type: Date,
    default: Date.now(),
  },
});

const Meeting = mongoose.model("meeting", meetingSchema);
export default Meeting;
