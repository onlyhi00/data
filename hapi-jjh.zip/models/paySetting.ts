import mongoose from "mongoose";

const Schema = mongoose.Schema;
const paySettingSchema = new Schema({
  method: {
    type: String,
    enum: ["card", "paypal"],
  },
  userEmail: {
    type: String,
    required: false,
  },
  billingEmail: {
    type: String,
    required: false,
  },
  billingFullname: {
    type: String,
    required: false,
  },
  billingCountry: {
    type: String,
    required: false,
  },
  billingState: {
    type: String,
    required: false,
  },
  billingZipCode: {
    type: String,
    required: false,
  },
  cardNumber: {
    type: String,
    required: false,
  },
  cardExpirationDate: {
    type: String,
    required: false,
  },
  cardSecurityCode: {
    type: String,
    required: false,
  },
  paypal: {
    type: String,
    required: false,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
  lastLoggedIn: {
    type: Date,
    default: Date.now(),
  },
});

const PaySetting = mongoose.model("paysetting", paySettingSchema);
export default PaySetting;
