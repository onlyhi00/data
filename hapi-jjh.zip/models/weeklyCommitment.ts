import mongoose from "mongoose";

const Schema = mongoose.Schema;
const weeklyCommitmentSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
});

const WeeklyCommitment = mongoose.model("weeklycommitment", weeklyCommitmentSchema);
export default WeeklyCommitment;
