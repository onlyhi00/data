import mongoose from "mongoose";

const Schema = mongoose.Schema;
const clientSchema = new Schema({
    email: {
        type: String,
        required: true,
    },
    birthday: {
        type: String,
        required: false,
    },
    country: {
        type: String,
        required: false,
    },
    languages: [{
        language: {
            type: String,
            required: true,
        },
        proficiency: {
            type: String,
            required: true,
        }
    }],
    socialMedia: [{
        type: {
            type: String,
            required: false
        },
        url: {
            type: String,
            required: false
        },
    }],
    profileCompleteness: {
        type: Number,
        required: false,
    },
    //   organization: {
    //     type: Schema.Types.ObjectId,
    //     required: true,
    //   },
    organization:
    {
        organizationName: {
            type: String,
            required: false
        },
        specialities: {
            type: Array,
            required: false
        },
        dayOfRegistraton: {
            type: String,
            required: false
        },
        description: {
            type: String,
            required: false
        },
        revenue: {
            type: String,
            required: false
        },
        headquarters: {
            type: String,
            required: false
        },
        industry: {
            type: Array,
            required: false
        },
        teamSize: {
            type: String,
            required: false
        },
        overview: {
            type: String,
            required: false
        },
        fundingStage: {
            type: String,
            required: false
        },
        logo: {
            type: String,
            required: false
        },
        website: {
            type: String,
            required: false
        },
        linkedin: {
            type: String,
            required: false
        },
    },
    createdAt: {
        type: Date,
        default: Date.now(),
    },
    updatedAt: {
        type: Date,
        default: Date.now(),
    },
    lastLoggedIn: {
        type: Date,
        default: Date.now(),
    },
});

const Client = mongoose.model("client", clientSchema);
export default Client;
