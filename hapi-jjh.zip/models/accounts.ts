import mongoose from "mongoose";

const Schema = mongoose.Schema;
const accountSchema = new Schema({
  type: {
    type: String,
    enum: ["admin", "staff", "customer", "expert"],
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  fullName: {
    type: String,
    required: true,
  },
  phoneNumber: {
    type: String,
    required: false,
  },
  photo: {
    type: String,
    required: false,
  },
  status: {
    type: String,
    required: true,
  },
  emailVerifyStatus: {
    type: String,
    required: true,
  },
  otp: {
    type: String,
    required: false,
  },
  passwordResetAllow: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
  lastLoggedIn: {
    type: Date,
    default: Date.now(),
  },
});

const Account = mongoose.model("account", accountSchema);
export default Account;
