import mongoose from "mongoose";

const Schema = mongoose.Schema;
const expertSchema = new Schema({
  email: {
    type: String,
    required: true,
  },
  titleName: {
    type: String,
    required: true,
  },
  summary: {
    type: String,
    required: true,
  },
  birthday: {
    type: String,
    required: true,
  },
  country: {
    type: String,
    required: true,
  },
  languages: [{
    language: {
      type: String,
      required: true,
    },
    proficiency: {
      type: String,
      required: true,
    }
  }],
  address: {
    type: String,
    required: true,
  },
  zipCode: {
    type: String,
    required: true,
  },
  tools: { // Array of string
    type: Array,
    required: true,
  },
  skills: { // Array of string
    type: Array,
    required: true,
  },
  education: [{ // Array of object
    university: {
      type: String,
      required: false
    },
    degree: {
      type: String,
      required: false
    },
    subject: {
      type: String,
      required: false
    },
    location: {
      type: String,
      required: false
    },
    from: {
      type: String,
      required: false
    },
    to: {
      type: String,
      required: false
    },
    description: {
      type: String,
      required: false
    },
  }],
  experience: [{ // Array of object
    company: {
      type: String,
      required: false
    },
    role: {
      type: String,
      required: false
    },
    location: {
      type: String,
      required: false
    },
    from: {
      type: String,
      required: false
    },
    to: {
      type: String,
      required: false
    },
    description: {
      type: String,
      required: false
    },
  }],
  socialMedia: [{
    type: {
      type: String,
      required: false
    },
    url: {
      type: String,
      required: false
    },
  }],
  projectPreference: { // Array of string
    type: String,
    required: true,
  },
  hourlyRate: {
    type: Number,
    required: true,
  },
  weeklyCommitment: {
    type: Number,
    required: true,
  },
  profileCompleteness: {
    type: Number,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
  lastLoggedIn: {
    type: Date,
    default: Date.now(),
  },
});

const Expert = mongoose.model("expert", expertSchema);
export default Expert;
