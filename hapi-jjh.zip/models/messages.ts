import mongoose from "mongoose";

const Schema = mongoose.Schema;
const messageSchema = new Schema({
  type: {
    type: String,
    required: true,
  },
  from: {
    type: String,
    required: true,
  },
  to: {
    type: String,
    required: true,
  },
  text: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now(),
  },
  updatedAt: {
    type: Date,
    default: Date.now(),
  },
});

const Message = mongoose.model("message", messageSchema);
export default Message;
