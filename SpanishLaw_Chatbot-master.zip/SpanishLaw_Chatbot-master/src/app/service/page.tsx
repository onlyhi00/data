import ChatLayout from "@/components/ChatLayout";

const Service = () => {
  return <ChatLayout />;
};

export default Service;
