const Privacy = () => {
  return (
    <div className="text-center text-[40px] font-semibold text-zinc-100">
      <div>This is Privacy Policy page.</div>
      <div>Coming Soon...</div>
    </div>
  );
};

export default Privacy;
