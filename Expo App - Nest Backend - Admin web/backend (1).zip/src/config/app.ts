const API_VERSION = "v2";

module.exports = {
  API_VERSION
};
