import {Injectable} from '@nestjs/common';
import {afAuth, db} from "./firebase";
import {storage} from "./firebase";

@Injectable()
export class FirebaseService {
  constructor() {
  }

  async getAll(path: string): Promise<any> {
    const snapshot = await db.collection(path)
      .where('trash', '==', false)
      .get();
    const data = [];
    snapshot.forEach(doc => {
      data.push({
        ...doc.data(),
        key: doc.id,
      })
    });
    return data;
  }

  async get(path: string): Promise<any> {
    const snapshot = await db.doc(path).get();
    return {
      ...snapshot.data(),
      key: snapshot.id,
    };
  }

  async update(path: string, item: any): Promise<any> {
    return await db.doc(path).update({
      ...item,
      updatedAt: new Date().getTime()
    });
  }

  async add(path: string, item: any): Promise<any> {
    return await db.collection(path).add({
      ...item,
      updatedAt: new Date().getTime(),
      createdAt: new Date().getTime(),
      trash: false
    })
  }

  async set(path: string, item: any): Promise<any> {
    return await db.doc(path).set({
        ...item,
        updatedAt: new Date().getTime(),
        createdAt: new Date().getTime(),
      },
      {
        merge: true
      }
    );
  }

  async delete(path: string): Promise<any> {
    return await db.doc(path).update({
      trash: true,
      updatedAt: new Date().getTime()
    });
  }

  async uploadFile(file: any, path: string, mimeType:string) {
    const currentFileRef = storage.bucket('tintech-app.appspot.com').file(path);
    await currentFileRef.save(file.buffer, {
      contentType: mimeType,
      predefinedAcl: 'publicRead',
    })

    return currentFileRef.publicUrl();
  }

  async createUser(email: string, password: string) {
    return await afAuth.createUser({
      email,
      password,
      emailVerified: true,
    })
  }
}
