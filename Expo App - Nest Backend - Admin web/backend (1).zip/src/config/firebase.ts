import * as admin from 'firebase-admin'

const viaticorp = require('./viaticorp-app.json')

admin.initializeApp({
  credential: admin.credential.cert({
    privateKey: viaticorp.private_key,
    projectId: viaticorp.project_id,
    clientEmail: viaticorp.client_email,
  }),
  databaseURL: `https://${viaticorp.project_id}.firebaseio.com`,
});

const db = admin.firestore();
const afAuth = admin.auth();
const storage = admin.storage();

export {
  admin,
  db,
  afAuth,
  storage
};
