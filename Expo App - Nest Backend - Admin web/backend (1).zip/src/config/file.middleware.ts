import {Injectable, NestMiddleware} from "@nestjs/common";
import {NextFunction, Response} from "express";

const busboy = require('busboy');
const fs = require('fs');
const os = require('os');
const path = require('path');

@Injectable()
export class FileMiddleware implements NestMiddleware {
  use(req: any, res: Response, next: NextFunction) {
    const bb = busboy({
      headers: req.headers,
      limits: {
        fileSize: 10 * 1024 * 1024,
      },
    });

    const fields = {};
    const files = [];
    const fileWrites = [];
    const tmpdir = os.tmpdir();

    bb.on("field", (key, value) => {
      fields[key] = value;
    });

    bb.on("file", (fieldname, file, filename, encoding, mimetype) => {

      const filepath = path.join(tmpdir, filename.filename);
      const writeStream = fs.createWriteStream(filepath);
      file.pipe(writeStream);

      fileWrites.push(
        new Promise<void>((resolve, reject) => {
          file.on("end", () => writeStream.end());
          writeStream.on("finish", () => {
            fs.readFile(filepath, (err, buffer) => {
              const size = Buffer.byteLength(buffer);
              if (err) {
                return reject(err);
              }
              files.push({
                fieldname,
                originalname: filename,
                encoding,
                mimetype,
                buffer,
                size,
              });

              try {
                fs.unlinkSync(filepath);
              } catch (error) {
                return reject(error);
              }

              resolve();
            });
          });
          writeStream.on("error", reject);
        })
      );
    });

    bb.on("finish", () => {
      Promise.all(fileWrites)
        .then(() => {
          req.body = fields;
          req.files = files;
          next();
        })
        .catch(next);
    });

    bb.end(req.body);
  }
}
