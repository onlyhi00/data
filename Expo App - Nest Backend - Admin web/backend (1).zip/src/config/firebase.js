"use strict";
exports.__esModule = true;
exports.storage = exports.afAuth = exports.db = exports.admin = void 0;
var admin = require("firebase-admin");
exports.admin = admin;
var competenteDev = require('./competente-dev.json');
admin.initializeApp({
    credential: admin.credential.cert({
        privateKey: competenteDev.private_key,
        projectId: competenteDev.project_id,
        clientEmail: competenteDev.client_email
    }),
    databaseURL: "https://".concat(competenteDev.project_id, ".firebaseio.com")
});
var db = admin.firestore();
exports.db = db;
var afAuth = admin.auth();
exports.afAuth = afAuth;
var storage = admin.storage();
exports.storage = storage;
