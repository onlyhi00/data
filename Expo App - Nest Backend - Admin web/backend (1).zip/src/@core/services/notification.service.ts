import {Injectable} from '@nestjs/common';

const sgMail = require('@sendgrid/mail');

@Injectable()
export class NotificationService {

  constructor() {
    const SENDGRID_API_KEY = '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';
    sgMail.setApiKey(SENDGRID_API_KEY);
  }

  async sendEmailNotification(subject: string, emails: string[], html: string) {
    const message: any = {
      from: {
        email: `"${subject}" <contacto@tecnologiasintech.com>`,
        name: 'Tecnologías Intech'
      },
      html,
      subject,
      to: emails,
    };

    sgMail.send([message])
      .then((resp) => {
        console.log(resp);
      })
      .catch(err => {
        console.log('::EMAIL ERROR');
        console.log(err.response.body);
        console.log('::EMAILS SENDED', emails.join());
      });
  }
}
