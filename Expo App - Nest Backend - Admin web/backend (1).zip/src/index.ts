import * as functions from 'firebase-functions';
import {NestFactory} from '@nestjs/core';
import {ExpressAdapter} from '@nestjs/platform-express';
import {AppModule} from './app.module';
import express from 'express';

const server = express();

const createNestServer = async (expressInstance) => {
  const app = await NestFactory.create(
    AppModule,
    new ExpressAdapter(expressInstance),
  );

  app.enableCors({
    credentials: true,
    origin: [
      'http://localhost:3000',
      'http://viaticorp-app.web.app',
      'https://viaticorp-app.web.app',
    ],
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  });

  return app.init();
};

createNestServer(server)
  .then(v => console.log('Nest Ready'))
  .catch(err => console.error('Nest broken', err));

const FUNCTIONS_FOLDER = './my_functions';

// fs.readdirSync(path.resolve(__dirname, FUNCTIONS_FOLDER)).forEach(file => { // list files in the folder.
//   if (file.endsWith('.js')) {
//     const fileBaseName = file.slice(0, -3); // Remove the '.ts' extension
//     if (!process.env.FUNCTION_NAME || process.env.FUNCTION_NAME === fileBaseName) {
//       exports[fileBaseName] = require(`${FUNCTIONS_FOLDER}/${fileBaseName}`)({
//         functions,
//         db,
//         afAuth
//       });
//     }
//   }
// });

export const api = functions.https.onRequest(server);
