import {Injectable} from '@nestjs/common';
import {FirebaseService} from "../config/firebase.service";

@Injectable()
export class UsersService {
  constructor(private _firebase: FirebaseService) {
  }

  async create(email: any, password: any) {
    return await this._firebase.createUser(email, password);
  }
}
