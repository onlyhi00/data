import { Controller, Post, Put, Req, Res } from '@nestjs/common';
import { afAuth } from "../config/firebase";

var convert = require('xml-js');

@Controller('users')
export class UsersController {

  constructor() {
  }

  @Post('create-user')
  async create(
    @Res() res,
    @Req() req
  ) {
    const { email, password, claim } = req.body;

    afAuth.createUser({
      email: email,
      emailVerified: true,
      password: password,
      disabled: false
    }).then(async resp => {
      if (!!claim) await afAuth.setCustomUserClaims(resp.uid, claim);

      res.json({
        ok: true,
        data: resp
      });
    }).catch(err => {
      res.json({
        ok: false,
        err
      });
    });
  }

  @Put('change-password')
  async changePassword(
    @Res() res,
    @Req() req
  ) {
    const { uid, password } = req.body;

    afAuth.updateUser(uid, {
      password: password
    }).then(resp => {
      res.json({
        ok: true,
        data: resp
      });
    }).catch(err => {
      res.json({
        ok: false,
        err
      });
    });
  }

  @Post('delete')
  async delete(
    @Res() res,
    @Req() req
  ) {
    const { uid } = req.body;

    afAuth.deleteUser(uid).then(resp => {
      res.json({
        ok: true,
        data: resp
      });
    }).catch(err => {
      res.json({
        ok: false,
        err
      });
    });
  }

  @Post('update-email')
  async updateEmail(
    @Res() res,
    @Req() req
  ) {
    const { uid, newEmail } = req.body;

    afAuth.updateUser(uid, {
      email: newEmail
    }).then(resp => {
      res.json({
        ok: true,
        data: resp
      });
    }).catch(err => {
      res.json({
        ok: false,
        err
      });
    });
  }

  @Post('claim')
  async setClaim(
    @Res() res,
    @Req() req
  ) {
    const { uid, claim } = req.body;

    afAuth.setCustomUserClaims(uid, claim).then(resp => {
      res.json({
        ok: true,
        data: resp
      });
    }).catch(err => {
      res.json({
        ok: false,
        err
      });
    });
  }

  @Post('xmlData')
  async xmlData(
    @Res() res,
    @Req() req
  ) {
    const { file } = req.body;

    try {
      const result = convert.xml2js(file, { compact: true, spaces: 4 });

      res.json({
        ok: true,
        data: result
      });
    } catch (err) {
      res.json({
        ok: false,
        err
      });
    }
  }
}

