import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import {UsersService} from './users.service';
import {UsersController} from './users.controller';
import {FirebaseService} from "../config/firebase.service";
import { FileMiddleware } from "../config/file.middleware";

@Module({
  controllers: [UsersController],
  providers: [
    UsersService,
    FirebaseService
  ]
})
export class UsersModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(FileMiddleware)
      .forRoutes('users/xmlData');
  }
}
