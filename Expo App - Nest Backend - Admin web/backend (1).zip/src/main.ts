import { NestFactory } from '@nestjs/core';
import { ExpressAdapter } from '@nestjs/platform-express';
import { AppModule } from './app.module';
import express from 'express';

const server = express();
const FUNCTIONS_FOLDER = './my_functions';

const createNestServer = async (expressInstance) => {
  const app = await NestFactory.create(
    AppModule,
    new ExpressAdapter(expressInstance),
  );
  return app.listen(3000);
};

createNestServer(server)
  .then(v => console.log('Nest Ready'))
  .catch(err => console.error('Nest broken', err));

// fs.readdirSync(path.resolve(__dirname, FUNCTIONS_FOLDER)).forEach(file => {
//   if (file.endsWith('.js')) {
//     const fileBaseName = file.slice(0, -3); // Remove the '.js' extension
//     if (!process.env.FUNCTION_NAME || process.env.FUNCTION_NAME === fileBaseName) {
//       exports[fileBaseName] = require(`${FUNCTIONS_FOLDER}/${fileBaseName}`)({
//         functions,
//         db,
//         afAuth
//       });
//     }
//   }
// });
