import {Module} from '@nestjs/common';
import {FirebaseService} from "./config/firebase.service";
import {UsersModule} from "./users/users.module";

@Module({
  controllers: [],
  imports: [
    UsersModule,
  ],
  providers: [FirebaseService],
})
export class AppModule {
}
