import React, { useRef, useState } from 'react';
import { Colors } from "react-native-ui-lib";
import { NavigationContainer } from "@react-navigation/native";
import Menu from "@app/navigation/Menu/Menu";
import { useLoaderStore } from "@app/@core/store/useLoaderStore";
import VLoader from "@app/@core/components/VLoader";
import ActionSheet from "@app/@core/components/ActionSheet";
import Modal from "@app/@core/components/Modal";
import Dialog from "@app/@core/components/Dialog";

Colors.loadColors({
  primary: "#2f3640",
  ripple: "#a4acb7",
  secondary: "#192a56",
  gray: "#718093",
  text: "#222733",
  error: "#d63031",
  success: "#44bd32",
  warn: "#e17055"
});

const Root = () => {
  const refContainer = useRef(null);
  const [isReady, setIsReady] = useState(false);
  const { isLoading } = useLoaderStore();

  return (
    <NavigationContainer
      ref={refContainer}
      onReady={() => setIsReady(true)}
    >
      {isReady && <Menu navigation={refContainer.current}/>}
      {isLoading && <VLoader/>}
      <ActionSheet/>
      <Modal/>
      <Dialog/>
    </NavigationContainer>
  );
};

export default Root;
