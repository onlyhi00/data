import firebase from 'firebase/compat';
import '@firebase/firestore';
import '@firebase/auth';
import "firebase/compat/auth";
import "firebase/compat/firestore";
import "firebase/compat/storage";
import * as firebaseAuth from 'firebase/auth';
import { initializeAuth } from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
  apiKey: "AIzaSyC9PELPgBr7VLeepMjvirUWaq44uYDsIZs",
  authDomain: "viaticorp-app.firebaseapp.com",
  projectId: "viaticorp-app",
  storageBucket: "viaticorp-app.appspot.com",
  messagingSenderId: "593144606098",
  appId: "1:593144606098:web:67aefef863be3a7645254b"
}

const firestoreConfig = {
  host: "viaticorp-app.firebaseapp.com",
  ssl: false,
  merge: true,
  experimentalForceLongPolling: false
};


if (!firebase.apps.length) {
  const defaultApp = firebase.initializeApp(firebaseConfig);
  const reactNativePersistence = (firebaseAuth as any).getReactNativePersistence;

  initializeAuth(defaultApp, {
    persistence: reactNativePersistence(AsyncStorage)
  });

  firebase.firestore().settings(firestoreConfig);
}

const db = firebase.firestore();
const auth = firebase.auth();
const storage = firebase.storage();
// const apiBaseUrl = 'https://22f4-2806-2f0-2420-feb9-a487-b08d-652c-6f05.ngrok-free.app/viaticorp-app/us-central1/api';
const apiBaseUrl = 'https://us-central1-viaticorp-app.cloudfunctions.net/api';

export {
  firebase,
  db,
  auth,
  storage,
  apiBaseUrl
};
