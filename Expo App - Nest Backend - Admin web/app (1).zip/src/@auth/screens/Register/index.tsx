import useAuth from "@app/@auth/hooks/useAuth";
import { StyleSheet, Text, useWindowDimensions } from "react-native";
import { Colors, KeyboardAwareScrollView, TouchableOpacity, View } from "react-native-ui-lib";
import AutoHeightImage from "react-native-auto-height-image";
import { VInput } from "@app/@core/components/VInput";
import { validateEmail } from "@app/@core/utils/validations";
import VButton from "@app/@core/components/VButton";
import React from "react";
import { useNavigation } from "@react-navigation/native";

interface Props {

}

const Register = ({}: Props) => {
  const { registerForm, signUpWithEmailAndPassword } = useAuth();
  const { height } = useWindowDimensions();
  const navigation = useNavigation();

  const handleRedirectToLogin = () => {
    navigation.navigate('Login' as never);
  };

  return (
    <KeyboardAwareScrollView
      style={{
        backgroundColor: "white",
        height
      }}
      keyboardShouldPersistTaps={"handled"}
      contentContainerStyle={{ flexGrow: 1 }}
    >
      <View
        backgroundColor={Colors.primary}
        center
      >
        <AutoHeightImage
          source={require('../../../../assets/images/viaticorp_logo_wbg.png')}
          width={120}
        />
        <Text style={styles.companyName}>Viaticorp</Text>
      </View>

      <View
        paddingH-30
        paddingT-40
        width={'100%'}
      >

        <Text
          style={{
            color: Colors.primary,
            fontSize: 30,
            fontWeight: 'bold',
            marginBottom: 10
          }}
        >Registro</Text>
        <VInput
          placeholder={"correo@ejemplo.com"}
          errors={registerForm.formState.errors}
          control={registerForm.control}
          name={'email'}
          label={'Correo electrónico'}
          isRequired={true}
          returnKeyType={'next'}
          type={'email-address'}
          maxLength={150}
          externalValidation={validateEmail}
          errorMessage={"Correo electrónico no válido"}
        />

        <View marginT-20>
          <VInput
            placeholder={"* * * * *"}
            errors={registerForm.formState.errors}
            control={registerForm.control}
            name={'password'}
            label={'Contraseña'}
            isRequired={true}
            returnKeyType={'next'}
            type={'password'}
            maxLength={150}
          />
        </View>

        <View marginT-20>
          <VInput
            placeholder={"* * * * *"}
            errors={registerForm.formState.errors}
            control={registerForm.control}
            name={'confirmPassword'}
            label={'Confirmar contraseña'}
            isRequired={true}
            returnKeyType={'next'}
            type={'password'}
            maxLength={150}
          />
        </View>

        <View
          marginT-50
        >
          <VButton
            height={60}
            width={'100%'}
            label={'Registrarme'}
            onPress={registerForm.handleSubmit(signUpWithEmailAndPassword)}
          />
        </View>
        <TouchableOpacity
          onPress={handleRedirectToLogin}
          style={{
            marginTop: 20,
            alignItems: 'center'
          }}
        >
          <Text>Iniciar sesión</Text>
        </TouchableOpacity>

      </View>
    </KeyboardAwareScrollView>

  );
};

const styles = StyleSheet.create({
  companyName: {
    color: '#ffffff',
    fontSize: 36,
    fontWeight: 'bold',
    marginBottom: 10,
    textShadowColor: '#5d5d5d',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 3
  }
});

export default Register;
