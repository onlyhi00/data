import React from 'react';
import { Colors, KeyboardAwareScrollView, TouchableOpacity, View } from "react-native-ui-lib";
import { StyleSheet, Text, useWindowDimensions } from "react-native";
import AutoHeightImage from "react-native-auto-height-image";
import useAuth from "@app/@auth/hooks/useAuth";
import { VInput } from "@app/@core/components/VInput";
import { validateEmail } from "@app/@core/utils/validations";
import VButton from "@app/@core/components/VButton";
import { useNavigation } from "@react-navigation/native";

const Login = () => {
  const { control, errors, signInWithEmailAndPassword, handleSubmit } = useAuth();
  const { height } = useWindowDimensions();
  const navigation = useNavigation();

  const handleRedirectToRegister = () => {
    navigation.navigate('Register' as never);
  }

  return (
    <KeyboardAwareScrollView
      style={{
        backgroundColor: "white",
        height: height
      }}
      keyboardShouldPersistTaps={"handled"}
      contentContainerStyle={{ flexGrow: 1 }}
    >
      <View
        backgroundColor={Colors.primary}
        center
      >
        <AutoHeightImage
          source={require('../../../../assets/images/viaticorp_logo_wbg.png')}
          width={120}
        />
        <Text style={styles.companyName}>Viaticorp</Text>
      </View>

      <View
        paddingH-30
        paddingT-40
        width={'100%'}
      >

        <Text
          style={{
            color: Colors.primary,
            fontSize: 30,
            fontWeight: 'bold',
            marginBottom: 10
          }}
        >Iniciar sesión</Text>
        <VInput
          placeholder={"correo@ejemplo.com"}
          errors={errors}
          control={control}
          name={'email'}
          label={'Correo electrónico'}
          isRequired={true}
          returnKeyType={'next'}
          type={'email-address'}
          maxLength={150}
          externalValidation={validateEmail}
          errorMessage={"Correo electrónico no válido"}
        />

        <View marginT-20>
          <VInput
            errors={errors}
            control={control}
            name={'password'}
            label={'Contraseña'}
            isRequired={true}
            returnKeyType={'next'}
            type={'password'}
            maxLength={150}
          />
        </View>

        <View
          marginT-50
        >
          <VButton
            height={60}
            width={'100%'}
            label={'Iniciar sesión'}
            onPress={handleSubmit(signInWithEmailAndPassword)}
          />
        </View>

        <TouchableOpacity
          onPress={handleRedirectToRegister}
          style={{
            marginTop: 20,
            alignItems: 'center'
          }}
        >
          <Text>Registrarme</Text>
        </TouchableOpacity>

      </View>
    </KeyboardAwareScrollView>

  );
};

export default Login;

const styles = StyleSheet.create({
  companyName: {
    color: '#ffffff',
    fontSize: 36,
    fontWeight: 'bold',
    marginBottom: 10,
    textShadowColor: '#5d5d5d',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 3
  }
});
