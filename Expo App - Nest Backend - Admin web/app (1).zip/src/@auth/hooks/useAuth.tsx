import { auth } from '@app/firebase/config';
import { useForm } from "react-hook-form";
import useUser from "@app/@core/hooks/useUser";
import { useNavigation } from "@react-navigation/native";
import useAlert from "@app/@core/hooks/useAlert";
import { useLoaderStore } from "@app/@core/store/useLoaderStore";
import { useUserStore } from "@app/@user/store/useUserStore";
import useFetch, { CachePolicies } from "use-http";
import { useFirebaseData } from "@app/@core/hooks/useFirebaseData";

const useAuth = () => {
  const { getCurrentUser } = useUser();
  const navigation = useNavigation();
  const { showAlert, confirm } = useAlert();
  const { showLoader, hideLoader } = useLoaderStore();
  const { setUser, resetUserData } = useUserStore();
  const {
    control,
    handleSubmit,
    formState: { errors }
  } = useForm({
    mode: 'onChange',
    defaultValues: {
      email: '',
      password: ''
    }
  });
  const registerForm = useForm({
    mode: 'onChange',
    defaultValues: {
      email: '',
      password: '',
      confirmPassword: ''
    }
  });
  const { post } = useFetch(`https://us-central1-viaticorp-app.cloudfunctions.net/api/users/create-user`, {
    cachePolicy: CachePolicies.NO_CACHE
  });
  const { post: deletePost } = useFetch(`https://us-central1-viaticorp-app.cloudfunctions.net/api/users/delete`, {
    cachePolicy: CachePolicies.NO_CACHE
  });
  const dbAdmin = useFirebaseData({
    collectionPath: 'admins'
  });
  const db = useFirebaseData({
    collectionPath: 'users'
  });

  const signInWithEmailAndPassword = async (data: any) => {
    showLoader();

    auth.signInWithEmailAndPassword(data.email, data.password)
      .then((user: any) => {
        getCurrentUser().then(userData => {
          setUser(userData);
          navigation.navigate('Tickets' as never);
        });

        hideLoader();
      })
      .catch(error => {
        hideLoader();
        showAlert('Iniciar sesión', getMessageError(error.code));
      });
  };

  const signUpWithEmailAndPassword = async (data: any) => {
    if (data.password !== data.confirmPassword) return showAlert('Las contraseñas no coinciden', '');

    let resp;
    showLoader();

    try {
      resp = await post({ email: data.email, password: data.password });

      if (!resp?.ok) {
        hideLoader();
        console.log(data);
        console.log(resp);
        return showAlert('Hubo un error al crear la cuenta', '');
      }

      await db.set(resp.data.uid, {
        email: data.email,
        byUser: db.getReference(`users/${resp.data.uid}`),
        type: 'admin',
        trash: false,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });

      await dbAdmin.set(resp.data.uid, {
        email: data.email,
        byUser: db.getReference(`users/${resp.data.uid}`),
        type: 'admin',
        trash: false,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });

      auth.signInWithEmailAndPassword(data.email, data.password)
        .then((user: any) => {
          getCurrentUser().then(userData => {
            setUser(userData);
            navigation.navigate('Tickets' as never);
          });

          hideLoader();
        })
        .catch(error => {
          hideLoader();
          showAlert('Hubo un error al intentar crear la cuenta', '');
        });
    } catch (e) {
      hideLoader();
      console.log(e);
    }
  };

  const deleteAccount = async () => {
    if (!(await confirm('¿Estás seguro que deseas eliminar tu cuenta?', 'Se eliminarán todos tus datos, este cambio no podrá ser reversible'))) return;

    await deletePost({
      uid: auth.currentUser?.uid
    });

    await auth.signOut();
    resetUserData();
  };

  const signOut = async () => {
    await auth.signOut();
    resetUserData();
  };

  const getMessageError = (code: string): string => {
    switch (code) {
      case 'auth/email-already-exists':
        return 'Correo electrónico en uso.';

      case 'auth/invalid-email' :
        return 'Correo electrónico inválido.';

      case 'auth/operation-not-allowed':
        return 'Esta operación no está permitida.';

      case 'auth/weak-password':
        return 'Contraseña muy débil.';

      case 'auth/wrong-password':
        return 'Contraseña incorrecta';

      case 'auth/invalid-password':
        return 'Contraseña inválida, mínimo 6 caracteres';

      case 'auth/invalid-uid':
        return 'Usuario inválido';

      case 'auth/user-disabled':
        return 'Tu usuario ha sido bloqueado';

      case 'auth/user-not-found':
        return 'El usuario no fue encontrado, revise su correo electrónico';

      case 'auth/network-request-failed':
        return 'Error en la conexión';

      case 'auth/email-already-in-use':
        return 'El email ya está en uso';

      case 'auth/invalid-login-credentials':
        return 'Hubo un error y no se pudo iniciar sesión, revise correo y contraseña';

      default:
        return `Pruebe de nuevo. Si el problema persiste contacte con el equipo de soporte: soporte@tecnologiasintech.com`;
    }
  };
  return {
    control,
    errors,
    signInWithEmailAndPassword,
    signUpWithEmailAndPassword,
    getMessageError,
    handleSubmit,
    signOut,
    registerForm,
    deleteAccount
  };
};

export default useAuth;
