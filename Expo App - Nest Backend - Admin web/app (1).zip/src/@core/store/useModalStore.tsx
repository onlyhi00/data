import { create } from 'zustand';
import React from "react";

interface ModalData {
  title: string;
  render: React.ReactNode;
  data?: any;
}

interface ModalStore {
  title: string;
  render: React.ReactNode;
  isVisible?: boolean;
  data?: any;
  showModal: (modalData: ModalData) => void;
  dismissModal: () => void;
}

export const useModalStore = create<ModalStore>((set) => ({
  isVisible: false,
  title: '',
  render: null,
  data: {},
  showModal: (modalData: ModalData) => set(() => ({
    ...modalData,
    isVisible: true
  })),
  dismissModal: () => set(() => ({
    isVisible: false,
    title: '',
    render: null,
    data: {}
  }))
}));
