import { create } from 'zustand';

export interface ActionSheetOption {
  label: string,
  onPress: Function
}

interface ActionSheetStore {
  isVisible: boolean,
  title: string,
  options: ActionSheetOption[],
  showActionSheet: (title: string, options: ActionSheetOption[]) => void,
  dismissActionSheet: () => void,
}

export const useActionSheetStore = create<ActionSheetStore>((set) => ({
  isVisible: false,
  title: '',
  options: [],
  showActionSheet: (title: string, options: ActionSheetOption[]) => {
    set(() => ({
      isVisible: false
    }));

    setTimeout(() => {
      set(() => ({
        isVisible: true,
        title,
        options
      }));
    }, 100);
  },
  dismissActionSheet: () => set(() => ({
    isVisible: false,
    title: '',
    options: []
  }))
}));
