import { create } from 'zustand';

interface Dialog {
  title: string,
  isFullScreen: boolean,
  render: any,
  ignoreBackgroundPress: boolean,
}

interface DialogStore {
  isVisible: boolean,
  title: string,
  isFullScreen: boolean,
  render: any,
  ignoreBackgroundPress: boolean,
  showDialog: ({ title, render, isFullScreen, ignoreBackgroundPress }: Dialog) => void,
  dismissDialog: () => void,
}

export const useDialogStore = create<DialogStore>((set) => ({
  isVisible: false,
  title: '',
  isFullScreen: false,
  render: null,
  ignoreBackgroundPress: false,
  showDialog: (dialog: Dialog) => set(() => ({
    isVisible: true,
    ...dialog
  })),
  dismissDialog: () => set(() => ({
    isVisible: false,
    render: null,
    title: '',
    isFullScreen: false
  }))
}));
