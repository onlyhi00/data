import {
  addDoc,
  collection,
  collectionGroup,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  updateDoc,
  where
} from 'firebase/firestore';
import { getAuth } from '@firebase/auth';
import { useEffect, useState } from 'react';
import _ from 'lodash';
import { storage } from '@app/firebase/config';
import { useUserStore } from "@app/@user/store/useUserStore";

export interface IQuery {
  type: 'where' | 'orderBy';
  field: string;
  operator?: '==' | '<' | '<=' | '>' | '>=' | 'array-contains' | 'in' | 'array-contains-any';
  value?: any;
  direction?: 'asc' | 'desc';
}

interface IProps {
  collectionPath: string;
  queries?: IQuery[];
  initSubscribe?: boolean;
}

export const useFirebaseData = ({
  collectionPath,
  queries = [],
  initSubscribe = false
}: IProps) => {
  const db = getFirestore();
  const auth = getAuth();
  const [docs, setDocs] = useState([]);
  const [docData, setDocData] = useState(null);
  const { user } = useUserStore();
  let unsubscribe: any;
  let unsubscribeDoc: any;

  const getCollectionRef = () => {
    return collection(db, collectionPath);
  };

  const getReference = (path: string) => {
    return doc(db, path);
  };

  const docWithId = async (path: string) => {
    const docRef = doc(db, path);
    const resp = await getDoc(docRef);

    return {
      ...resp.data(),
      id: resp.id,
      key: resp.id
    };
  };

  const set = async (id: string, data: any) => {
    const documentRef = doc(db, collectionPath, id);
    return setDoc(documentRef, data);
  };

  const add = async (data: any, newCollectionPath?: string) => {
    const colRef = newCollectionPath ? collection(db, newCollectionPath) : getCollectionRef();

    return addDoc(colRef, {
      ...data,
      createdAt: new Date().getTime(),
      byUser: getReference(`users/${user.byUser.id}`),
      trash: false
    });
  };

  const update = async (id: string, data: any, path?: string) => {
    delete data['id'];

    const documentRef = doc(db, path || collectionPath, id);

    return updateDoc(documentRef, {
      ...data,
      updatedAt: new Date().getTime()
    });
  };

  const collectionWithIds = async <Type>(queries: IQuery[] = [], distinctCollectionPath?: string): Promise<Type[]> => {
    const snapshot = await getDocs(getQueryRef(queries, collection(db, distinctCollectionPath || collectionPath)));
    return snapshot.docs.map((doc: any) => ({ ...doc.data(), id: doc.id } as any as Type));
  };

  const collectionGroupWithIds = async <Type>(path: string, queries: IQuery[]): Promise<Type[]> => {
    const snapshot: any = await getDocs(getQueryRef(queries, collectionGroup(db, path)));
    return snapshot.docs.map((doc: any) => ({ ...doc.data(), id: doc.id, path: doc.ref.path } as any as Type));
  };

  const listenCollectionGroup = async <Type>(path: string, queries: IQuery[]) => {
    unsubscribe = onSnapshot(getQueryRef(queries, collectionGroup(db, path)), (snapshot: any) => {
      setDocs(snapshot.docs.map((doc: any) => ({ ...doc.data(), id: doc.id, path: doc.ref.path } as any as Type)));
    }, (error) => {
      console.log(error);
    });
  };

  const subscribeCollection = (queries: IQuery[] = []) => {
    unsubscribe = onSnapshot(getQueryRef(queries), (snapshot: any) => {
      setDocs(snapshot.docs.map((doc: any) => ({ ...doc.data(), id: doc.id, path: doc.ref.path })));
    });
  };

  const subscribeDoc = (docID: string, collection: string = collectionPath) => {
    const docRef = doc(db, `${collection}/${docID}`);
    unsubscribeDoc = onSnapshot(docRef, (doc: any) => {
      setDocData({ ...doc.data(), id: doc.id, path: doc.ref.path });
    });
  };

  const getQueryRef = (queries: IQuery[] = [], distinctCollectionRef?: any) => {
    let queryRef: any = query(distinctCollectionRef || getCollectionRef());

    queryRef = query(queryRef, where('byUser', '==', getReference(`users/${user.byUser.id}`)));

    queries.forEach((queryItem: any) => {
      if (queryItem.type === 'where') {
        queryRef = query(queryRef, where(queryItem.field, queryItem.operator, queryItem.value));
      } else if (queryItem.type === 'orderBy') {
        queryRef = query(queryRef, orderBy(queryItem.field, queryItem.direction));
      }
    });

    return queryRef;
  };

  const populateByItem = async (item: any, fields: string[], subFields: string[] = [], subSubFields: string[] = []) => {
    for (let field of fields) {
      if (item[field] && item[field].path) {
        try {
          item[field] = await docWithId(item[field].path);

          for (let subField of subFields) {
            if (item[field][subField]) {
              item[field][subField] = await docWithId(item[field][subField].path);

              for (let subSUbField of subSubFields) {
                if (item[field][subField][subSUbField]) {
                  item[field][subField][subSUbField] = await docWithId(item[field][subField][subSUbField].path);
                }
              }
            }
          }
        } catch (e) {
          console.error(`Hubo un error al obtener el documento del campo ${field.toUpperCase()}`, e);
        }
      }
    }
    return item;
  };

  const populate: any = async (items: any[], fields: string[], subFields: string[] = [], subSubFields: string[] = []) => {
    return await Promise.all(items.map(async item => await populateByItem(item, fields, subFields, subSubFields)));
  };

  const populateArrayFieldByItem = async (item: any, fields: string[]) => {
    for (let field of fields) {
      const array = _.get(item, field);
      if (array) {
        try {
          let populatedArray = (await Promise.all(array.map(async (itemField: any) => {
            return await docWithId(itemField.path);
          })));

          populatedArray = populatedArray.filter((item: any) => !!item);

          _.set(item, field, populatedArray);
        } catch (e) {
          console.error(`Hubo un error al obtener el documento del campo ${field.toUpperCase()}`, e);
        }
      }
    }
    return item;
  };

  const populateArrayField = async (items: any[], fields: string[]) => {
    return await Promise.all(items.map(async item => await populateArrayFieldByItem(item, fields)));
  };

  const uploadFile = async (file: any, path: string): Promise<string> => {
    return new Promise(resolve => {
      const currentFileRef = storage.ref(path);

      currentFileRef.put(file).then(async (snapshot) => {
        const url = await snapshot.ref.getDownloadURL();
        resolve(url);
      });
    });
  };

  const uploadFileByBase64 = async (base64: any, path: string): Promise<string> => {
    return new Promise(resolve => {
      const currentFileRef = storage.ref(path);

      currentFileRef.putString(base64, 'data_url').then(async (snapshot) => {
        const url = await snapshot.ref.getDownloadURL();
        resolve(url);
      });
    });
  };

  useEffect(() => {
    return () => {
      !!unsubscribe && unsubscribe();
      !!unsubscribeDoc && unsubscribeDoc();
    };
  }, []);

  useEffect(() => {
    if (initSubscribe) {
      subscribeCollection(queries);
    }
  }, [initSubscribe]);

  return {
    add,
    set,
    update,
    collectionWithIds,
    docs,
    unsubscribe,
    getReference,
    docWithId,
    populate,
    populateByItem,
    populateArrayField,
    populateArrayFieldByItem,
    auth,
    collectionGroupWithIds,
    listenCollectionGroup,
    subscribeDoc,
    docData,
    subscribeCollection,
    uploadFile,
    uploadFileByBase64
  };
};
