import React, { useState } from 'react';
import useAlert from './useAlert';
import { useFirebaseData } from './useFirebaseData';
import { auth } from '@app/firebase/config';
import useAuth from "@app/@auth/hooks/useAuth";

const useUser = () => {
  const { showAlert } = useAlert();
  // const { getMessageError } = useAuth();
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState(false);
  const { docWithId, set, update: updateDoc } = useFirebaseData({
    collectionPath: 'users'
  });

  const createUser = (user: any) => {
    setLoading(true);
    auth.createUserWithEmailAndPassword(user.email, user.password)
      .then(async (userCredential: any) => {
        delete user.password;
        delete user.confirmPassword;
        const userRef: any = userCredential.user;
        await set(userRef.uid, {
          ...user,
          createdAt: new Date().getTime(),
          updatedAt: new Date().getTime(),
          trash: false
        });

        setLoading(false);
        setOk(true);
      })
      .catch((err: any) => {
        console.log(err.code);

        // showToast(getMessageError(err.code));
        setLoading(false);
      });
  };

  const getCurrentUser = async (): Promise<any> => {
    const user = await docWithId(`users/${auth.currentUser?.uid}`);
    return user as any;
  };

  const update = async (
    key: string,
    user: any,
    loadingMessage = 'Actualizando datos',
    toastMessage = 'Datos actualizados',
    showToastMessage: boolean = true) => {

    //sHOW LOADER HERE

    await updateDoc(key, {
      ...user,
      updatedAt: new Date().getTime()
    });

//STOP LOADER HERE
    if (showToastMessage) showAlert(toastMessage, '');
  };


  return {
    createUser,
    getCurrentUser,
    update,
    loading,
    ok
  };
};

export default useUser;
