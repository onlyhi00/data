import React from 'react';
import { Alert } from "react-native";

const useAlert = () => {


  const confirm = (title: string, text: string, onConfirm?: () => void, onCancel?: () => void) => {
    return new Promise(resolve => {
      Alert.alert(
        title,
        text,
        [
          {
            text: 'Cancelar',
            onPress: () => {
              if (onCancel) onCancel();
              resolve(false);
            },
            style: 'cancel'
          },
          {
            text: 'Aceptar', onPress: () => {
              if (onConfirm) onConfirm();
              resolve(true);
            }
          }
        ],
        { cancelable: false }
      );
    });
  };

  const showAlert = (title: string, message: string) => {
    Alert.alert(title, message);
  };

  return {
    confirm,
    showAlert
  };
};

export default useAlert;
