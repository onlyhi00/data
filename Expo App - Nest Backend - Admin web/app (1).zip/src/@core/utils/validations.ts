export const validatePassword = (password: string): boolean => new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#.\$%\^&\*])(?=.{8,})").test(password);

export const validateEmail = (email: string): boolean => /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);

export const isObjectValid = (object: any): boolean => {
  if (!object) return false;

  for (let property in object) {
    if (object[property] === null || object[property] === '') return false;
  }
  return true;
};
