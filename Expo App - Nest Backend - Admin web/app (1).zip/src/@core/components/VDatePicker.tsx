import React, { useEffect, useState } from 'react';
import { Colors, DateTimePicker, TouchableOpacity, View } from "react-native-ui-lib";
import { StyleSheet, Text } from "react-native";
import FontAwesome5 from "@expo/vector-icons/FontAwesome5";
import ErrorIcon from "@expo/vector-icons/FontAwesome5";
import { Controller } from "react-hook-form";
import moment from "moment";

interface Props {
  name: string;
  errorMessage?: string;
  isRequired?: boolean;
  placeholder?: string;
  value?: string;
  onChangeInput?: (value: string) => void;
  label?: string;
  textStyle?: any;
  maxLength?: number;
  styles?: any;
  control?: any;
  errors?: any;
  externalValidation?: (value: any) => boolean;
  borderColor?: string;
  description?: string;
  requiredIndicator?: boolean;
}

export const VDatePicker = ({
  placeholder,
  label = '',
  textStyle,
  styles,
  control,
  name,
  errors,
  errorMessage = 'Es obligatorio este campo',
  isRequired = false,
  externalValidation,
  borderColor = Colors.primary,
  description = '',
  requiredIndicator = false
}: Props) => {
  const [showError, setShowError] = useState<boolean>(false);

  useEffect(() => {
    if (!errors[name]) setShowError(false);
  }, [errors]);

  return (
    <View style={styles}>
      <View row>
        {!!label && <Text
          style={{
            ...inputStyles.label,
            ...textStyle
          }}
        >
          {label}
        </Text>
        }
        {(isRequired && requiredIndicator && label) && <Text style={inputStyles.requiredAsterisk}>*</Text>}
      </View>
      {description && <Text
        style={inputStyles.description}>
        {description}
      </Text>}
      <Controller
        control={control}
        name={name as any}
        rules={{
          required: isRequired,
          validate: (value: string) => {
            if (externalValidation) return externalValidation(value);
          }
        } as any}
        render={({ field: { onChange, value } }) => {
          return (
            <View centerV>
              <DateTimePicker
                onChange={(e) => {
                  onChange(moment(e).toDate().getTime());
                }}
                renderInput={(props: any) => {
                  return (
                    <View
                      centerV
                      style={{
                        ...inputStyles.input,
                        borderColor: errors[name] ? '#E53131' : borderColor,
                        maxHeight: 150,
                        height: 55,
                        paddingRight: 20
                      }}
                      row
                    >
                      <Text
                        style={{
                          color: 'black',
                          fontSize: 15
                        }}
                      >
                        {!!value ? moment(value).format('DD/MM/YYYY') : 'DD/MM/YYYY'}
                      </Text>

                      <FontAwesome5
                        size={20}
                        style={{
                          position: 'absolute',
                          right: 10
                        }}
                        name={'calendar-alt'}
                      />
                    </View>
                  );
                }}
                migrateTextField
                containerStyle={{ marginVertical: 20 }}
                label={label}
                value={!!value ? moment(value).toDate() : new Date()}
                mode={'date'}
                placeholder={placeholder}
              />

              {errors[name] &&
                <TouchableOpacity
                  style={{
                    ...inputStyles.errorIcon
                  }}
                  onPress={() => {
                    setShowError(!showError);
                  }}
                >
                  <ErrorIcon height={15} width={15} fill={'#E63131'}/>
                </TouchableOpacity>}
            </View>
          );
        }}
      />
      {errors[name] && !showError && errorMessage !== '' && <Text
        style={inputStyles.errorMessage}
      >{errorMessage}</Text>}
    </View>
  );
};

const inputStyles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderRadius: 20,
    padding: 10,
    paddingRight: 70,
    fontSize: 17,
    color: '#000',
    lineHeight: 21,
    fontWeight: '400'
  },
  label: {
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 6
  },
  showPassword: {
    position: 'absolute',
    right: 10
  },
  errorMessage: {
    color: '#E53131',
    fontSize: 12,
    lineHeight: 17,
    marginLeft: 6
  },
  errorIcon: {
    position: 'absolute',
    right: 45
  },
  iconsInput: {
    position: 'absolute',
    right: 0
  },
  customLeftIcon: {
    position: 'absolute',
    left: 15
  },
  description: {
    fontSize: 16,
    color: '#646464',
    fontWeight: '400',
    lineHeight: 19,
    marginLeft: 6,
    marginBottom: 5
  },
  requiredAsterisk: {
    color: '#CF2525',
    fontSize: 18,
    fontWeight: '600'
  }
});
