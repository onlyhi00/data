import React from "react";
import { ActivityIndicator, StyleSheet, useWindowDimensions } from "react-native";
import { Colors, View } from "react-native-ui-lib";

const VLoader = () => {
  const { height } = useWindowDimensions();

  return (
    <View style={style.root}>
      <View
        style={style.backdrop}
        height={height}
      ></View>
      <View
        style={style.loading}
        center
      >
        <ActivityIndicator size={65} color={Colors.primary}/>
      </View>
    </View>
  );
};

export default VLoader;

const style = StyleSheet.create({
  root: {
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "absolute",
    left: 0,
    top: 0
  },
  backdrop: {
    backgroundColor: "#222733",
    opacity: 0.8,
    width: "100%",
    position: "absolute",
    left: 0,
    top: 0
  },
  loading: {
    height: 70,
    width: 70,
    backgroundColor: "white",
    borderRadius: 100,
    padding: 15,
    marginHorizontal: 10
  }
});
