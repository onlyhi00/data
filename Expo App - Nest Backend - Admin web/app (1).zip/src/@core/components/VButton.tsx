import React from "react";
import { StyleSheet, Text } from "react-native";
import { TouchableRipple } from "react-native-paper";
import { Colors, LoaderScreen, View } from "react-native-ui-lib";

interface Props {
  label: string;
  onPress: () => void;
  secondary?: boolean;
  loading?: boolean;
  disabled?: boolean;
  width?: number | string;
  height?: number | string;
  color?: string;
  icon?: React.ReactNode;
}

const PrimaryButton = ({
  label,
  icon,
  color = Colors.primary,
  onPress,
  secondary = false,
  loading = false,
  disabled = false,
  width = '47%',
  height = 48
}: Props) => {

  return (
    <View
      style={{
        ...styles.container,
        width,
        height,
        ...(secondary ? styles.secondary :
          {
            backgroundColor: color
          }),
        ...(disabled ? styles.disabled : {})
      }}
    >
      {!loading && (
        <TouchableRipple
          rippleColor={Colors.ripple}
          style={styles.ripple}
          disabled={disabled}
          onPress={onPress}
        >
          <View
            row
            center>
            {!!icon && <View marginR-10>
              {icon}
            </View>}
            <Text
              style={{
                ...styles.text,
                ...(secondary ? styles.textSecondary : {}),
                ...(disabled ? styles.textDisabled : {})
              }}
            >{label}</Text>
          </View>
        </TouchableRipple>
      )}

      {loading && (
        <View height={20}>
          <LoaderScreen
            color={Colors.white}
            size={32}
          />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    overflow: "hidden",
    borderRadius: 29,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5
  },
  secondary: {
    backgroundColor: "white",
    borderColor: Colors.primary,
    borderWidth: 1
  },
  ripple: {
    height: "100%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center"
  },
  text: {
    fontSize: 18,
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
    opacity: 1
  },
  textSecondary: {
    color: Colors.primary
  },
  disabled: {
    backgroundColor: "#E2E2E2"
  },
  textDisabled: {
    color: "#646464"
  }
});

export default PrimaryButton;
