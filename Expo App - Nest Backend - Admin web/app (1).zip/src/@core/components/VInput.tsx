import React, { useEffect, useState } from 'react';
import { Colors, TouchableOpacity, View } from "react-native-ui-lib";
import { KeyboardTypeOptions, StyleSheet, Text, TextInput, TextStyle } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Controller } from "react-hook-form";
import ErrorIcon from "@expo/vector-icons/FontAwesome5";

interface Props {
  type: KeyboardTypeOptions | 'password' | 'text';
  returnKeyType: 'next' | 'done';
  name: string;
  multiline?: boolean;
  numberOfLines?: number;
  errorMessage?: string;
  isRequired?: boolean;
  placeholder?: string;
  value?: string;
  onChangeInput?: (value: string) => void;
  label?: string;
  textStyle?: any;
  maxLength?: number;
  styles?: any;
  control?: any;
  errors?: any;
  onBlur?: (value: string) => any;
  externalValidation?: (value: any) => boolean;
  borderColor?: string;
  icon?: any;
  leftIconStyle?: any;
  description?: string;
  requiredIndicator?: boolean;
}

export const VInput = ({
  placeholder,
  label = '',
  textStyle,
  styles,
  type,
  returnKeyType,
  maxLength,
  control,
  name,
  errors,
  errorMessage = 'Es obligatorio este campo',
  isRequired = false,
  externalValidation,
  onBlur,
  multiline = false,
  onChangeInput = () => {
  },
  numberOfLines = 1,
  borderColor = Colors.primary,
  icon,
  leftIconStyle = {},
  description = '',
  requiredIndicator = false
}: Props) => {
  const [showPassword, setShowPassword] = useState<boolean>(type == 'password');
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [showError, setShowError] = useState<boolean>(false);
  const toggleShowPassword = () => setShowPassword(!showPassword);

  useEffect(() => {
    if (!errors[name]) setShowError(false);
  }, [errors]);

  return (
    <View
      style={styles}
    >
      <View row>
        {!!label && <Text
          style={{
            ...inputStyles.label,
            ...textStyle
          }}
        >
          {label}
        </Text>
        }
        {(isRequired && requiredIndicator && label) && <Text style={inputStyles.requiredAsterisk}>*</Text>}
      </View>
      {description && <Text
        style={inputStyles.description}
      >
        {description}
      </Text>}
      <Controller
        control={control}
        name={name}
        rules={{
          required: isRequired,
          validate: (value: string) => {
            if (externalValidation) return externalValidation(value);
          }
        }}
        render={({ field: { onChange, value } }) => (
          <View centerV>
            {icon && <View
              style={{
                ...inputStyles.customLeftIcon,
                ...leftIconStyle
              }}
            >
              {icon()}
            </View>}
            <TextInput
              placeholder={placeholder}
              placeholderTextColor={'#646464'}
              secureTextEntry={showPassword}
              numberOfLines={numberOfLines}
              multiline={multiline}
              value={value}
              onChangeText={(value) => {
                onChange(value);
                onChangeInput(value);
              }}
              style={{
                ...inputStyles.input,
                borderWidth: isFocused ? 2 : 1,
                borderColor: errors[name] ? '#E53131' : borderColor,
                height: multiline ? 'auto' : 55,
                paddingLeft: icon ? 50 : 15,
                maxHeight: 150
              }}
              maxLength={maxLength}
              onFocus={() => setIsFocused(true)}
              onBlur={() => {
                if (onBlur) onBlur(value);
                setIsFocused(false);
              }}
              keyboardType={type == 'text' || type == 'password' ? 'default' : type}
              returnKeyType={returnKeyType}
            />
            <View
              style={inputStyles.iconsInput as TextStyle}
              row
              flex
              centerV
            >
              {type === 'password' && <TouchableOpacity
                onPress={toggleShowPassword}
                style={{
                  position: 'relative',
                  padding: 15
                }}
              >
                {showPassword
                  ? <Ionicons
                    name="eye-outline"
                    size={20}
                    color={Colors.text}
                  />
                  : <Ionicons
                    name="eye-off-outline"
                    size={20}
                    color={Colors.text}
                  />}
              </TouchableOpacity>}
              {errors[name] &&
                <TouchableOpacity
                  style={{
                    ...inputStyles.errorIcon,
                    right: type === 'password' ? 45 : 15
                  }}
                  onPress={() => {
                    setShowError(!showError);
                  }}
                >
                  <ErrorIcon height={15} width={15} fill={'#E63131'}/>
                </TouchableOpacity>}
            </View>
          </View>
        )}
      />
      {errors[name] && !showError && errorMessage != '' && <Text
        style={inputStyles.errorMessage}
      >{errorMessage}</Text>}
    </View>
  );
};

const inputStyles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderRadius: 20,
    padding: 10,
    paddingRight: 70,
    fontSize: 17,
    color: '#000',
    lineHeight: 21,
    fontWeight: '400'
  },
  label: {
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 6
  },
  showPassword: {
    position: 'absolute',
    right: 10
  },
  errorMessage: {
    color: '#E53131',
    fontSize: 12,
    lineHeight: 17,
    marginLeft: 6,
  },
  errorIcon: {
    position: 'absolute',
    right: 45
  },
  iconsInput: {
    position: 'absolute',
    right: 0
  },
  customLeftIcon: {
    position: 'absolute',
    left: 15
  },
  description: {
    fontSize: 16,
    color: '#646464',
    fontWeight: '400',
    lineHeight: 19,
    marginLeft: 6,
    marginBottom: 5
  },
  requiredAsterisk: {
    color: '#CF2525',
    fontSize: 18,
    fontWeight: '600'
  }
});
