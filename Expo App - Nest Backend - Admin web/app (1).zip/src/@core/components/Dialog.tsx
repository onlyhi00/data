import React from 'react';
import { Colors, Dialog, Text, TouchableOpacity, View } from "react-native-ui-lib";
import { Platform, useWindowDimensions } from "react-native";
import { useDialogStore } from "@app/@core/store/useDialogStore";

const Modal = () => {
  const { dismissDialog, isFullScreen, title, isVisible, ignoreBackgroundPress, render } = useDialogStore();
  const { height, width } = useWindowDimensions();

  return (
    <Dialog
      modalProps={{
        animationType: 'fade',
        hardwareAccelerated: true,
        onRequestClose: () => dismissDialog()
      }}
      renderPannableHeader={() => {
        if (isFullScreen) return (<View></View>);
        return (
          <View
            marginV-10
          >
            <TouchableOpacity
              onPress={() => dismissDialog()}
              centerH
            >
              <View
                style={{
                  backgroundColor: '#b7b7b7',
                  borderRadius: 120,
                  height: 8,
                  width: 120
                }}
              />
            </TouchableOpacity>
            {!!title && <Text
              black
              marginT-10
              text60
              center
              numberOfLines={1}
              ellipsizeMode={'tail'}
            >{title}</Text>}
          </View>
        );
      }}
      useSafeArea
      bottom
      ignoreBackgroundPress={ignoreBackgroundPress}
      containerStyle={{
        backgroundColor: Colors.white,
        borderRadius: isFullScreen ? 0 : 20,
        borderBottomEndRadius: 0,
        maxHeight: height,
        borderBottomStartRadius: 0,
        marginLeft: -20,
        width,
        ...Platform.OS === 'ios' && {
          bottom: -30
        },
        ...isFullScreen && {
          height: height
        }
      }}
      visible={isVisible}
      onDismiss={() => dismissDialog()}
    >
      <View padding-10={!isFullScreen}>
        <View height={isFullScreen ? height - 20 : 'auto'}>
          {render}
        </View>
      </View>
    </Dialog>
  );
};

export default Modal;
