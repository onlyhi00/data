import React from 'react';
import { TouchableRipple } from "react-native-paper";
import { Colors } from "react-native-ui-lib";

interface Props {
  style?: any;
  onPress?: () => void;
  icon?: any;
}

const VIConButton = ({
  style,
  onPress,
  icon
}: Props) => {
  return (
    <TouchableRipple
      borderless
      rippleColor={Colors.ripple}
      onPress={onPress}

      style={{
        ...style,
        width: 30,
        height: 30,
        borderRadius: 100,
        justifyContent: 'center',
        alignItems: 'center'
      }}
    >
      {icon}
    </TouchableRipple>
  );
};

export default VIConButton;
