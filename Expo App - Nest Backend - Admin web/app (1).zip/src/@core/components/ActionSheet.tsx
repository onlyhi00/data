import React from 'react';
import { ActionSheet as ActionSheetComponent } from "react-native-ui-lib";
import { useActionSheetStore } from "@app/@core/store/useActionSheetStore";


const ActionSheet = () => {
  const { title, options, isVisible } = useActionSheetStore();

  return (
    <ActionSheetComponent
      title={title}
      options={options as any}
      visible={isVisible as any}
    />
  );
};

export default ActionSheet;
