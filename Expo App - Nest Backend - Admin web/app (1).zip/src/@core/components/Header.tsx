import React from 'react';
import { Text, View } from "react-native-ui-lib";
import Ionicons from "@expo/vector-icons/Ionicons";
import { useNavigation } from "@react-navigation/native";
import { StyleSheet } from "react-native";
import { TouchableRipple } from "react-native-paper";
import VButton from "@app/@core/components/VButton";

interface Props {
  headerTitle?: string;
  onBackPress?: () => void;
  labelButton?: string;
  onPressButton?: () => any;
  isValidButton?: boolean;
  buttonWidth?: string | number;
}

const Header = ({
  headerTitle = '',
  onBackPress,
  labelButton = '',
  onPressButton = () => {
  },
  buttonWidth = '100%',
  isValidButton = false
}: Props) => {
  const { goBack } = useNavigation();

  const goBackHandler = () => {
    if (!!onBackPress) return onBackPress();
    goBack();
  };

  return (
    <View
      row
      centerV
      spread
      style={styles.header}
      padding-10
    >
      <View
        row
        centerV
      >
        <TouchableRipple
          style={styles.backButton}
          borderless
          onPress={goBackHandler}
        >
          <Ionicons
            name="arrow-back"
            size={28}
            color={'black'}
          />
        </TouchableRipple>
        <Text
          marginL-20
          black
          style={styles.title}
        >{headerTitle}</Text>
      </View>
      {!!labelButton && <VButton
        width={buttonWidth}
        height={38}
        onPress={onPressButton}
        label={labelButton}
        disabled={!isValidButton}
      />}
    </View>
  );
};

const styles = StyleSheet.create({
  header: {
    borderBottomWidth: 1,
    borderBottomColor: '#e6e6e6'
  },
  backButton: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: 40,
    height: 40,
    borderRadius: 50
  },
  title: {
    fontSize: 20,
    fontWeight: "500",
    lineHeight: 23,
    color: '#222733'
  }
});

export default Header;
