import React, { useEffect, useRef, useState } from 'react';
import { Colors, Picker, PickerModes, TouchableOpacity, View } from "react-native-ui-lib";
import { StyleSheet, Text } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import { Controller } from "react-hook-form";
import ErrorIcon from "@expo/vector-icons/FontAwesome5";
import VIConButton from "@app/@core/components/VIConButton";

interface Props {
  name: string;
  values: any[];
  errorMessage?: string;
  isRequired?: boolean;
  placeholder?: string;
  label?: string;
  textStyle?: any;
  styles?: any;
  control?: any;
  errors?: any;
  externalValidation?: (value: any) => boolean;
  borderColor?: string;
  description?: string;
  requiredIndicator?: boolean;
  mode?: PickerModes;
}

export const VPicker = ({
  placeholder,
  label = '',
  textStyle,
  styles,
  values,
  control,
  name,
  errors,
  mode = PickerModes.SINGLE,
  errorMessage = 'Es obligatorio este campo',
  isRequired = false,
  externalValidation,
  borderColor = Colors.primary,
  description = '',
  requiredIndicator = false
}: Props) => {
  const [showError, setShowError] = useState<boolean>(false);
  const [selectedValue, setSelectedValue] = useState<any>('');
  const onChangeRef = useRef<any>();

  const handleClearSelect = () => {
    setSelectedValue('');
    onChangeRef.current('');
  };

  useEffect(() => {
    if (!errors[name]) setShowError(false);
  }, [errors]);

  return (
    <View style={styles}>
      <View row>
        {!!label && <Text
          style={{
            ...inputStyles.label,
            ...textStyle
          }}
        >
          {label}
        </Text>
        }
        {(isRequired && requiredIndicator && label) && <Text style={inputStyles.requiredAsterisk}>*</Text>}
      </View>
      {description && <Text
        style={inputStyles.description}
      >
        {description}
      </Text>}
      <Controller
        control={control}
        name={name as any}
        rules={{
          required: isRequired,
          validate: (value: string) => {
            if (externalValidation) return externalValidation(value);
          }
        } as any}
        render={({ field: { onChange, value } }) => {
          setSelectedValue(!!value ? values.find((item: any) => item.value === value)?.label : '');
          if (!onChangeRef.current) onChangeRef.current = onChange;

          return (
            <View centerV>
              <Picker
                mode={mode}
                showSearch
                searchPlaceholder={'Buscar'}
                topBarProps={{ title: label }}
                placeholder={placeholder}
                value={value}
                renderPicker={(_value?: any, label?: string) => (
                  <View
                    centerV
                    style={{
                      ...inputStyles.input,
                      borderColor: !!errors && errors[name] ? '#E53131' : borderColor,
                      maxHeight: 150,
                      height: 55,
                      paddingRight: 20
                    }}
                    row
                  >
                    <Text
                      style={{
                        color: 'black',
                        fontSize: 15
                      }}
                    >
                      {label || selectedValue}
                    </Text>

                    <Ionicons
                      size={20}
                      style={{
                        position: 'absolute',
                        right: 10
                      }}
                      name={'chevron-down'}
                    />
                  </View>
                )}
              >
                {values.map((item: { label: string, value: any, disabled?: boolean }) => (
                  <Picker.Item
                    onPress={() => {
                      setSelectedValue(item.label);
                      onChange(item.value);
                    }}
                    key={item.value}
                    value={item.value}
                    label={item.label}
                    disabled={item.disabled}
                  />
                ))}
              </Picker>

              {(!!value || !!selectedValue) && <VIConButton
                onPress={handleClearSelect}
                style={{
                  position: 'absolute',
                  right: 40
                }}
                icon={<Ionicons
                  size={20}
                  name={'close'}
                  color={Colors.red20}
                />}
              />}

              {!!errors && errors[name] &&
                <TouchableOpacity
                  style={{
                    ...inputStyles.errorIcon
                  }}
                  onPress={() => {
                    setShowError(!showError);
                  }}
                >
                  <ErrorIcon height={15} width={15} fill={'#E63131'}/>
                </TouchableOpacity>}
            </View>
          );
        }}
      />
      {!!errors && errors[name] && !showError && errorMessage !== '' && <Text
        style={inputStyles.errorMessage}
      >{errorMessage}</Text>}
    </View>
  );
};

const inputStyles = StyleSheet.create({
  input: {
    borderWidth: 1,
    borderRadius: 20,
    padding: 10,
    paddingRight: 70,
    fontSize: 17,
    color: '#000',
    lineHeight: 21,
    fontWeight: '400'
  },
  label: {
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 6
  },
  showPassword: {
    position: 'absolute',
    right: 10
  },
  errorMessage: {
    color: '#E53131',
    fontSize: 12,
    lineHeight: 17,
    marginLeft: 6
  },
  errorIcon: {
    position: 'absolute',
    right: 45
  },
  iconsInput: {
    position: 'absolute',
    right: 0
  },
  customLeftIcon: {
    position: 'absolute',
    left: 15
  },
  description: {
    fontSize: 16,
    color: '#646464',
    fontWeight: '400',
    lineHeight: 19,
    marginLeft: 6,
    marginBottom: 5
  },
  requiredAsterisk: {
    color: '#CF2525',
    fontSize: 18,
    fontWeight: '600'
  }
});
