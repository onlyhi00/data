import React from "react";
import { Text, TouchableOpacity, View } from "react-native-ui-lib";
import { Modal as ModalComponent, Platform, StyleSheet } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import { useModalStore } from "@app/@core/store/useModalStore";

const Modal = () => {
  const { isVisible, render, title, dismissModal } = useModalStore();

  return (
    <ModalComponent
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={() => dismissModal()}
    >
      <View
        style={styles.centeredView}
        marginT-40={Platform.OS == 'ios'}
      >
        {!!title && <View
          style={styles.headerModal}
          row
          centerV
          padding-15
        >
          <TouchableOpacity
            onPress={() => dismissModal()}
          >
            <Ionicons name="arrow-back" size={24} color="black"/>
          </TouchableOpacity>
          <Text
            text60
            marginL-20
            black
          >{title}</Text>
        </View>}
        {render}
      </View>
    </ModalComponent>
  );
};

const styles = StyleSheet.create({
  centeredView: {
    backgroundColor: "white",
    height: "100%"
  },
  headerModal: {
    borderBottomWidth: 1,
    borderBottomColor: "#D7D7D7"
  }
});

export default Modal;
