import Login from "@app/@auth/screens/Login/Login";
import { Ionicons } from '@expo/vector-icons';
import TicketsList from "@app/@user/screens/Tickets/Tickets";
import TicketDetails from "@app/@user/screens/TicketDetails/TicketDetails";
import Reports from "@app/@user/screens/Reports/Reports";
import { MaterialIcons } from '@expo/vector-icons';
import Register from "@app/@auth/screens/Register";

export interface Route {
  path: string;
  title: string;
  icon?: any;
  headerShown: boolean;
  gestureEnabled?: boolean;
  component: any;
  unmountOnBlur?: boolean;
}

export const routes: Route[] = [
  {
    path: "Login",
    title: "Iniciar sesión",
    headerShown: false,
    gestureEnabled: false,
    component: Login,
  },
  {
    path: "Register",
    title: "Registro",
    headerShown: false,
    gestureEnabled: false,
    component: Register,
  },
  {
    path: "Tickets",
    title: "Tickets",
    headerShown: false,
    gestureEnabled: false,
    icon: <Ionicons name="receipt-outline" size={24} color="white" />,
    component: TicketsList,
  },
  {
    path: "Ticket",
    title: "Ticket",
    headerShown: false,
    gestureEnabled: false,
    unmountOnBlur: true,
    component: TicketDetails,
  },
  {
    path: "Reports",
    title: "Reportes",
    headerShown: false,
    icon: <MaterialIcons name="playlist-add-check" size={24} color="white" />,
    gestureEnabled: false,
    unmountOnBlur: true,
    component: Reports,
  },
];
