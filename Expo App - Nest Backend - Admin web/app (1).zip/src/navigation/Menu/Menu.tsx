import React, { useEffect, useState } from 'react';
import { Colors, Text, View } from "react-native-ui-lib";
import { createDrawerNavigator, DrawerContentScrollView } from "@react-navigation/drawer";
import { Route, routes } from "@app/navigation/Routes";
import { StyleSheet, TouchableOpacity, useWindowDimensions } from "react-native";
import { TouchableRipple } from "react-native-paper";
import useAuth from "@app/@auth/hooks/useAuth";
import { Ionicons } from '@expo/vector-icons';
import { auth } from "@app/firebase/config";
import useUser from "@app/@core/hooks/useUser";
import { useUserStore } from "@app/@user/store/useUserStore";
import AutoHeightImage from "react-native-auto-height-image";

interface Props {
  navigation: any;
}

const Menu = ({
  navigation
}: Props) => {
  const Drawer = createDrawerNavigator();
  const { height } = useWindowDimensions();
  const { signOut, deleteAccount } = useAuth();
  const { getCurrentUser } = useUser();
  const { setUser, user } = useUserStore();
  const [initialRoute, setInitialRoute] = useState<string>();

  const handleRedirect = async (route: Route) => {
    navigation.navigate(route.path);
  };

  const handleSignOut = async () => {
    await signOut();
    return navigation.navigate('Login');
  };

  const handleDeleteAccount = async () => {
    await deleteAccount();
    return navigation.navigate('Login');
  };

  useEffect(() => {
    const onAuth = auth.onAuthStateChanged(async (user: any) => {
      if (!user) return setInitialRoute('Login');

      getCurrentUser().then(async userData => {
        setUser(userData);
        setInitialRoute('Tickets');
      });
    });

    return () => {
      onAuth();
    };
  }, []);

  if (!initialRoute) return <View></View>;

  return (
    <Drawer.Navigator
      initialRouteName={initialRoute}
      screenOptions={{
        swipeEdgeWidth: 0
      }}
      drawerContent={(props: any) => (
        <DrawerContentScrollView
          {...props}
          style={{ backgroundColor: Colors.primary }}
        >
          <View
            height={height}
          >
            <View
              row
              style={styles.drawerContent}
            >
              <View
                marginT-20
                marginL-10
                marginB-30
                row
              >
                <View style={styles.menuItemIcon} centerV>
                  <AutoHeightImage
                    source={require('../../../assets/images/viaticorp_logo_wbg.png')}
                    width={40}
                  />
                </View>

                <View marginL-20 centerV>
                  <Text
                    white
                    text65
                  >{user?.name} {user?.lastName}</Text>
                  <Text
                    white
                    text65
                    center
                  >{user?.email}</Text>
                </View>
              </View>

              {routes.map(route => (!!route.icon && <TouchableRipple
                  borderless
                  rippleColor={Colors.ripple}
                  key={route.path}
                  style={styles.drawerItem}
                  onPress={() => handleRedirect(route)}
                >
                  <View
                    width={'100%'}
                    row
                    centerV
                  >
                    {route.icon}
                    <Text
                      white
                      text70
                      marginL-20
                      center
                    >{route.title}</Text>
                  </View>
                </TouchableRipple>
              ))}
              <TouchableOpacity
                key={"DeleteAccount"}
                style={styles.drawerItem}
                onPress={() => handleDeleteAccount()}
              >
                <View style={styles.menuItemIcon}>
                  <Ionicons name="log-out-outline" size={30} color="white"/>
                </View>
                <Text
                  white
                  text65
                  marginL-10
                  center
                >Eliminar cuenta</Text>
              </TouchableOpacity>
              <TouchableOpacity
                key={"SignOut"}
                style={styles.drawerItem}
                onPress={() => handleSignOut()}
              >
                <View style={styles.menuItemIcon}>
                  <Ionicons name="log-out-outline" size={30} color="white"/>
                </View>
                <Text
                  white
                  text65
                  marginL-10
                  center
                >Cerrar sesión</Text>
              </TouchableOpacity>
            </View>
            <Text
              white
              text90
              style={styles.version}
            >Ver. 0.0.2</Text>
          </View>
        </DrawerContentScrollView>
      )}
    >
      {routes.map(route => (
        <Drawer.Screen
          key={route.path}
          name={route.path}
          options={{
            headerShown: route.headerShown,
            title: route.title,
            swipeEnabled: true,
            unmountOnBlur: route.unmountOnBlur
          }}
          component={route.component}
        />
      ))}
    </Drawer.Navigator>
  );
};

const styles = StyleSheet.create({
  drawerItem: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 18
  },
  drawerContent: {
    width: '100%',
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'flex-start'
  },
  userInfoSection: {
    paddingLeft: 20
  },
  title: {
    fontSize: 16,
    marginTop: 3,
    fontWeight: 'bold'
  },
  caption: {
    fontSize: 14,
    lineHeight: 14
  },
  profileImage: {
    width: 80,
    height: 80,
    marginTop: 20,
    borderRadius: 100
  },
  menuIcon: {
    width: 100,
    height: 100,
    marginTop: 20
  },
  row: {
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center'
  },
  section: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 15
  },
  paragraph: {
    fontWeight: 'bold',
    marginRight: 3
  },
  drawerSection: {
    marginTop: 15
  },
  bottomDrawerSection: {
    marginBottom: 15,
    borderTopColor: '#C4C4C4',
    borderTopWidth: 1
  },
  preference: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16
  },
  profileMenu: {
    borderBottomWidth: 0.5,
    borderBottomColor: '#C4C4C4'
  },
  menuItemIcon: {
    width: 35
  },
  version: {
    position: 'absolute',
    bottom: 30,
    left: 20
  }
});

export default Menu;


