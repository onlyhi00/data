import { create } from 'zustand';

interface FilterStore {
  provider: string | null;
  fromDate: number | null;
  toDate: number | null;
  setFilter: (filter: any) => void;
  resetFilters: () => void;
  setText: (text: string) => void;
  text: string;
}

export const useTicketsFilterStore = create<FilterStore>((set) => ({
  provider: '',
  fromDate: null,
  toDate: null,
  text: '',
  setFilter: (filter: any) => set({ ...filter }),
  setText: (text: string) => set({ text }),
  resetFilters: () => set({ provider: null, fromDate: null, toDate: null })
}));
