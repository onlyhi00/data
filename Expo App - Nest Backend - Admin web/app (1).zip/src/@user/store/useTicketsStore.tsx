import { create } from 'zustand';

interface TicketStore {
  tickets: any[];
  ticketsFiltered: any[];
  setTickets: (tickets: any) => void;
  resetTickets: () => void;
  setTicketsFiltered: (tickets: any) => void;
}

export const useTicketsStore = create<TicketStore>((set) => ({
  tickets: [],
  ticketsFiltered: [],
  setTickets: (tickets: any) => set({ tickets, ticketsFiltered: tickets }),
  setTicketsFiltered: (tickets: any) => set({ ticketsFiltered: tickets }),
  resetTickets: () => set((state) => ({ ...state, ticketsFiltered: state.tickets }))
}));
