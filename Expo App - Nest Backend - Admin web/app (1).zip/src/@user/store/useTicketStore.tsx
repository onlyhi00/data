import { create } from 'zustand';

interface TicketStore {
  ticket: any;
  newTicketUri: string;
  setNewTicketUri: (newTicketUri: string) => void;
  isFile: boolean;
  setIsFile: (isFile: boolean) => void;
  setTicket: (ticket: any) => void;
  resetTicket: () => void;
  xmlData: any;
  setXmlData: (xmlData: any) => void;
}

export const useTicketStore = create<TicketStore>((set) => ({
  ticket: null,
  newTicketUri: '',
  setTicket: (ticket: any) => set({ ticket }),

  isFile: false,
  setIsFile: (isFile: boolean) => set({ isFile }),

  xmlData: null,
  setXmlData: (xmlData: any) => set({ xmlData }),

  resetTicket: () => set({ ticket: null, isFile: false, xmlData: null }),
  setNewTicketUri: (newTicketUri: string) => set({ newTicketUri })
}));
