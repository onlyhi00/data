import { create } from 'zustand';

interface ReportStore {
  reports: any[];
  reportsFiltered: any[];
  setReports: (tickets: any) => void;
  resetReports: () => void;
  setReportsFiltered: (tickets: any) => void;
}

export const useReportsStore = create<ReportStore>((set) => ({
  reports: [],
  reportsFiltered: [],
  setReports: (reports: any) => set({ reports, reportsFiltered: reports }),
  setReportsFiltered: (reports: any) => set({ reportsFiltered: reports }),
  resetReports: () => set((state) => ({ ...state, reportsFiltered: state.reports }))
}));
