import { create } from 'zustand';

interface FilterStore {
  project: string | null;
  costCenter: string | null;
  fromDate: number | null;
  toDate: number | null;
  setFilter: (filter: any) => void;
  resetFilters: () => void;
  setText: (text: string) => void;
  text: string;
}

export const useReportsFilterStore = create<FilterStore>((set) => ({
  project: null,
  costCenter: null,
  fromDate: null,
  toDate: null,
  text: '',
  setFilter: (filter: any) => set({ ...filter }),
  setText: (text: string) => set({ text }),
  resetFilters: () => set({ project: null, fromDate: null, toDate: null, costCenter: null })
}));
