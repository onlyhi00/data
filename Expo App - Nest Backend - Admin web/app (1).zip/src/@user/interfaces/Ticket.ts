export interface Ticket {
  id: string;
  title: string;
  costCenter: any;
  project: any;
  provider: any;
  ticketUrl: string;
  trash?: boolean;
  status?: string;
}
