export enum TaxType {
  ISR = '001',
  IVA = '002',
}
