import React, { useMemo, useRef, useState } from 'react';
import { Card, Colors, Dialog, PanningProvider, View } from "react-native-ui-lib";
import EvilIcons from "@expo/vector-icons/EvilIcons";
import { StyleSheet, TextInput } from "react-native";
import Ionicons from "@expo/vector-icons/Ionicons";
import { TouchableRipple } from 'react-native-paper';
import { useTicketsFilters } from "@app/@user/hooks/useTicketsFilters";
import { VDatePicker } from "@app/@core/components/VDatePicker";
import { VPicker } from "@app/@core/components/VPicker";
import PrimaryButton from "@app/@core/components/VButton";
import { useTicketsFilterStore } from "@app/@user/store/useTicketsFilterStore";
import { useReportsFilters } from "@app/@user/hooks/useReportsFilters";
import { useReportsFilterStore } from "@app/@user/store/useReportsFilterStore";

const ReportsFilter = () => {
  const [isVisible, setIsVisible] = useState(false);
  const {
    control,
    errors,
    isDirty,
    projects,
    costsCenters,
    handleCleanFilters,
    handleApplyFilters
  } = useReportsFilters();
  const { project, fromDate, toDate, setText, costCenter } = useReportsFilterStore();
  const inputTextRef = useRef<any>(null);
  const debounceRef = useRef<any>(null);

  const projectsValues = useMemo(() => {
    return projects.map((project: any) => ({
      label: project.name,
      value: project.id
    }));
  }, [projects]);

  const costsCentersValues = useMemo(() => {
    return costsCenters.map((costCenter: any) => ({
      label: costCenter.name,
      value: costCenter.id
    }));
  }, [costsCenters]);

  const handleChangeText = (text: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);

    debounceRef.current = setTimeout(() => setText(text), 100);
  };

  return (
    <View
      row
      width={'100%'}
      spread
      paddingV-15
    >
      <View
        row
        centerV
        flex-1
      >
        <EvilIcons
          name="search"
          size={24}
          color="#b7b6b6"
        />
        <TextInput
          ref={inputTextRef}
          returnKeyType={'search'}
          style={{
            fontSize: 14,
            flex: 1,
            borderBottomWidth: 1,
            borderBottomColor: `#b7b6b6`
          }}
          placeholder={'Buscar'}
          onChangeText={handleChangeText}
        />
      </View>

      <TouchableRipple
        borderless
        style={styles.filterButton}
        rippleColor={Colors.ripple}
        onPress={() => setIsVisible(true)}
      >
        <Ionicons
          color={project || costCenter || (fromDate && toDate) ? '#0e84fc' : Colors.primary}
          name="filter"
          size={24}
        />
      </TouchableRipple>

      <Dialog
        visible={isVisible}
        onDismiss={() => setIsVisible(false)}
        panDirection={PanningProvider.Directions.DOWN}
      >
        <Card
          padding-20
        >
          <View
            spread
            row
          >
            <View
              paddingR-5
              width={'50%'}
            >
              <VDatePicker
                control={control}
                name={'fromDate'}
                label={'Desde'}
                isRequired={true}
                errors={errors}
              />
            </View>

            <View
              paddingL-5
              width={'50%'}
            >
              <VDatePicker
                control={control}
                name={'toDate'}
                label={'Hasta'}
                isRequired={true}
                errors={errors}
              />
            </View>
          </View>

          <View marginT-10>
            <VPicker
              control={control}
              name={'costCenter'}
              label={'Centro de costos'}
              isRequired={false}
              errors={errors}
              values={costsCentersValues}
            />
          </View>

          <View marginT-10>
            <VPicker
              control={control}
              name={'project'}
              label={'Proyectos'}
              isRequired={false}
              errors={errors}
              values={projectsValues}
            />
          </View>

          <View
            marginT-20
            width={'100%'}
          >
            <PrimaryButton
              label={'Filtrar'}
              width={'100%'}
              onPress={() => {
                handleApplyFilters();
                setIsVisible(false);
              }}
            />

            {isDirty && <View
              marginT-20
            >
              <PrimaryButton
                color={Colors.red20}
                label={'Limpiar'}
                width={'100%'}
                onPress={() => handleCleanFilters()}
              />
            </View>}
          </View>
        </Card>
      </Dialog>
    </View>
  );
};

export default ReportsFilter;

const styles = StyleSheet.create({
  filterButton: {
    paddingHorizontal: 5,
    marginLeft: 10,
    borderRadius: 100,
    width: 40,
    height: 40,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
});
