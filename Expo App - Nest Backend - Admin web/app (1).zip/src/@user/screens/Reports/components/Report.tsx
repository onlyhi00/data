import React, { useState } from 'react';
import { View } from "react-native-ui-lib";
import PrimaryButton from "@app/@core/components/VButton";
import { AntDesign } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system';
import { Alert } from "react-native";
import ImageView from "react-native-image-viewing";
import * as Sharing from 'expo-sharing';

interface Props {
  report: any;
}

const Report = ({
  report
}: Props) => {
  const [visible, setIsVisible] = useState(false);

  const handleDownloadReport = async () => {
    downloadFileByUrl(report.reportUrl)
      .then(async ({ uri }) => {
        await sharedFile(uri, report.name.replaceAll(' ', '_'));
      })
      .catch(err => {
        console.log(err);
        Alert.alert('No se pudo descargar el PDF, intentelo de nuevo');
      });
  };

  const downloadFileByUrl = async (url: string) => {
    return FileSystem.downloadAsync(url, `${FileSystem.documentDirectory}${report.name.replaceAll(' ', '_')}.csv`);
  };

  const sharedFile = async (uri: string, fileName: string) => {
    await Sharing.shareAsync(uri, {
      dialogTitle: fileName
    }).then(resp => {
      console.log(resp);
    }).catch(e => {
      console.log(e);
    });
  };

  return (
    <View height={150}>
      <ImageView
        images={[{ uri: report.reportImageUrl }]}
        imageIndex={0}
        visible={visible}
        onRequestClose={() => setIsVisible(false)}
      />
      <PrimaryButton
        icon={<AntDesign name="eyeo" size={24} color="black"/>}
        secondary
        width={'100%'}
        height={60}
        label={'Ver reporte'}
        onPress={() => {
          setIsVisible(true);
          console.log(report.reportUrl);
        }}
      />

      <View marginT-20>
        <PrimaryButton
          icon={<AntDesign name="download" size={24} color="white"/>}
          width={'100%'}
          height={60}
          label={'Descargar Reporte'}
          onPress={handleDownloadReport}
        />
      </View>
    </View>
  );
};

export default Report;
