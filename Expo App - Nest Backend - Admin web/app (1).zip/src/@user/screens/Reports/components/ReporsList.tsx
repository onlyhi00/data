import React, { useState } from 'react';
import { Badge, BorderRadiuses, Card, Colors, ListItem, Text, View } from "react-native-ui-lib";
import { useTicketsList } from "@app/@user/hooks/useTicketsList";
import { useNavigation } from "@react-navigation/native";
import { useTicketStore } from "@app/@user/store/useTicketStore";
import { FlatList, StyleSheet } from "react-native";
import AutoHeightImage from "react-native-auto-height-image";
import moment from "moment/moment";
import useReports from "@app/@user/hooks/useReports";
import { useDialogStore } from '@app/@core/store/useDialogStore';
import Report from "@app/@user/screens/Reports/components/Report";

const ReportsList = () => {
  const { reports } = useReports();
  const { showDialog } = useDialogStore();
  const handleOpenReport = (report: any) => {
    showDialog({
      title: report.name,
      render: <Report report={report}/>,
      isFullScreen: false,
      ignoreBackgroundPress: false
    });
  };

  return (
    <FlatList
      data={reports}
      contentContainerStyle={{ paddingBottom: 180 }}
      renderItem={({ item }: any) => (
        <Card
          paddingV-10
          marginT-6
        >
          <ListItem
            activeBackgroundColor={Colors.grey60}
            activeOpacity={0.3}
            paddingV-15
            paddingH-10
            onPress={() => handleOpenReport(item)}
          >
            <ListItem.Part left></ListItem.Part>

            <ListItem.Part column containerStyle={[styles.border]}>
              <ListItem.Part>
                <Text
                  numberOfLines={1}
                  ellipsizeMode={'tail'}
                  style={styles.title}
                >{item?.name}</Text>
              </ListItem.Part>

              <ListItem.Part>
                <View>
                  <Text
                    numberOfLines={1}
                    ellipsizeMode={'tail'}
                    grey30
                  >
                    {item?.concept}
                  </Text>

                  <View paddingV-5>
                    <Text
                      numberOfLines={1}
                      ellipsizeMode={'tail'}
                      grey10 text80
                    >
                      Proyecto: {item?.project?.label}
                    </Text>

                    <Text
                      numberOfLines={1}
                      ellipsizeMode={'tail'}
                      grey10
                      text80
                    >
                      Centro de costos: {item?.costCenter?.label}
                    </Text>
                  </View>
                </View>
              </ListItem.Part>
            </ListItem.Part>
            <Badge
              backgroundColor={Colors.ripple}
              label={moment(item?.createdAt).format('DD/MM/YYYY')}
              style={styles.date}
            />
          </ListItem>
        </Card>
      )}
    />
  );
};

export default ReportsList;

const styles = StyleSheet.create({
  image: {
    width: 54,
    height: 54,
    borderRadius: BorderRadiuses.br20,
    marginHorizontal: 14
  },
  border: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.grey70
  },
  date: {
    fontSize: 11,
    color: Colors.grey30,
    position: 'absolute',
    right: 0,
    top: -5
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold'
  }
});
