import React from 'react';
import { View } from "react-native-ui-lib";
import TicketsHeader from "@app/@user/screens/Tickets/components/TicketsHeader";
import { useWindowDimensions } from "react-native";
import ReportsList from "@app/@user/screens/Reports/components/ReporsList";
import ReportsFilter from "@app/@user/screens/Reports/components/ReportsFilter";

const Reports = () => {
  const { height } = useWindowDimensions();
  return (
    <View height={height}>
      <TicketsHeader title={'Lista de reportes'}/>
      <View
        flex-1
        paddingH-15
      >
        <ReportsFilter/>
        <ReportsList/>
      </View>
    </View>
  );
};

export default Reports;
