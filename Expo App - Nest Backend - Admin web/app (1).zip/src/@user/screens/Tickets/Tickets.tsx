import React from 'react';
import { View } from "react-native-ui-lib";
import TicketsHeader from "@app/@user/screens/Tickets/components/TicketsHeader";
import CameraFloatButton from "@app/@user/screens/Tickets/components/CameraFloatButton";
import TicketsList from "@app/@user/screens/Tickets/components/TicketsList";
import { useWindowDimensions } from "react-native";
import TicketsFilter from "@app/@user/screens/Tickets/components/TicketsFilter";

const Tickets = () => {
  const { height } = useWindowDimensions();

  return (
    <View height={height}>
      <TicketsHeader/>
      <View
        flex-1
        paddingH-15
      >
        <TicketsFilter/>
        <TicketsList/>
        <CameraFloatButton/>
      </View>
    </View>
  );
};

export default Tickets;
