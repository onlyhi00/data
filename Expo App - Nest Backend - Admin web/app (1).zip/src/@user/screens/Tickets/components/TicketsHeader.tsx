import React from 'react';
import { Colors, Text, View } from 'react-native-ui-lib';
import { Feather } from '@expo/vector-icons';
import { StyleSheet } from "react-native";
import { TouchableRipple } from "react-native-paper";
import { DrawerActions, useNavigation } from "@react-navigation/native";
import AutoHeightImage from "react-native-auto-height-image";

interface Props {
  title?: string;
}

const TicketsHeader = ({ title = 'Lista de tickets' }: Props) => {
  const navigation: any = useNavigation();
  return (
    <View style={styles.header}>
      <AutoHeightImage
        source={require('../../../../../assets/images/viaticorp_logo_wbg.png')}
        width={40}
      />

      <Text
        white
        text60
      >{title}</Text>

      <TouchableRipple
        rippleColor={Colors.ripple}
        borderless
        onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
        style={styles.menuButton}
      >
        <Feather name="menu" size={30} color="white"/>
      </TouchableRipple>
    </View>
  );
};

export default TicketsHeader;

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#2f3640',
    paddingHorizontal: 15,
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 60
  },
  menuButton: {
    borderRadius: 100,
    width: 40,
    height: 40,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
});
