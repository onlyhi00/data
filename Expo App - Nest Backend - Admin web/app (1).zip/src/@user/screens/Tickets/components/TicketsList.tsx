import React from 'react';
import { Badge, BorderRadiuses, Card, Colors, ListItem, Text, View } from "react-native-ui-lib";
import { useTicketsList } from "@app/@user/hooks/useTicketsList";
import { FlatList, StyleSheet } from "react-native";
import AutoHeightImage from "react-native-auto-height-image";
import { useNavigation } from "@react-navigation/native";
import { useTicketStore } from "@app/@user/store/useTicketStore";
import moment from "moment";
import { FontAwesome } from "@expo/vector-icons";
import useAlert from "@app/@core/hooks/useAlert";

const TicketsList = () => {
  const { tickets } = useTicketsList();
  const navigation: any = useNavigation();
  const { setNewTicketUri, setTicket } = useTicketStore();
  const { showAlert } = useAlert();

  const status: any = {
    'complete': {
      label: 'Enviado',
      color: Colors.success
    },
    'pending': {
      label: 'Pendiente',
      color: Colors.warn
    }
  };

  const handleOpenTicketDetails = (ticket: any) => {
    if (ticket.isFile) return showAlert('Error', 'No se puede editar un ticket de xml');

    navigation.navigate('Ticket');
    setTicket(ticket);
    setNewTicketUri(ticket?.ticketUrl);
  };

  return (
    <FlatList
      data={tickets}
      contentContainerStyle={{ paddingBottom: 180 }}
      renderItem={({ item }: any) => (
        <Card marginV-6 paddingV-10>
          <ListItem
            activeBackgroundColor={Colors.grey60}
            activeOpacity={0.3}
            onPress={() => handleOpenTicketDetails(item)}
          >
            <ListItem.Part left>
              {item?.isFile
                ? <View
                  center
                  style={styles.image}
                >
                  <FontAwesome name="file" size={45} color="#192a56"/>
                </View>
                : <AutoHeightImage
                  width={75}
                  source={{ uri: item?.ticketUrl }}
                  style={styles.image}
                />
              }
            </ListItem.Part>

            <ListItem.Part middle column containerStyle={[styles.border, { paddingRight: 17 }]}>
              <ListItem.Part containerStyle={{ marginBottom: 3 }}>
                <Text grey10 text80 style={{ marginTop: 2 }}>
                  {item?.providerName || 'Sin proveedor'}
                </Text>
              </ListItem.Part>

              <ListItem.Part>
                <Text grey30>
                  {item?.concept}
                </Text>
              </ListItem.Part>

              <ListItem.Part>
                <Text grey10 text80>{moment(item?.date).format('DD/MM/YYYY')}</Text>

                <Badge
                  label={status[item?.status]?.label}
                  backgroundColor={status[item?.status]?.color}
                />
              </ListItem.Part>
            </ListItem.Part>
          </ListItem>
        </Card>
      )}
    />
  );
};

export default TicketsList;

const styles = StyleSheet.create({
  image: {
    width: 54,
    height: 54,
    borderRadius: BorderRadiuses.br20,
    marginHorizontal: 14
  },
  border: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.grey70
  },
  date: {
    fontSize: 11,
    color: Colors.grey30,
    position: 'absolute',
    right: 9,
    top: 5
  }
});
