import React, { useEffect } from 'react';
import { LogBox, StyleSheet, View } from "react-native";
import { Colors } from "react-native-ui-lib";
import { TouchableRipple } from "react-native-paper";
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from "expo-image-picker";
import { useActionSheetStore } from "@app/@core/store/useActionSheetStore";
import { useNavigation } from "@react-navigation/native";
import { useTicketStore } from "@app/@user/store/useTicketStore";
import { getCameraPermissionsAsync, requestCameraPermissionsAsync } from "expo-camera";
import * as DocumentPicker from 'expo-document-picker';
import { useTicket } from "@app/@user/hooks/useTicket";
import useAlert from "@app/@core/hooks/useAlert";

const CameraFloatButton = () => {
  LogBox.ignoreLogs(['Warning: ...']);
  LogBox.ignoreAllLogs();
  const { showActionSheet, dismissActionSheet } = useActionSheetStore();
  const { navigate }: any = useNavigation();
  const { setNewTicketUri, resetTicket, setIsFile, setXmlData } = useTicketStore();
  const { extractDataFormXml } = useTicket();
  const { showAlert } = useAlert();

  const handleOpenCamera = async () => {
    try {
      let image: any = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images
      });

      if (image?.canceled) return;

      resetTicket();
      setNewTicketUri(image.assets[0].uri);
      navigate('Ticket');
      setIsFile(false);

      dismissActionSheet();
    } catch (e) {
      requestPermissions();
    }
  };

  const handleOpenGallery = async () => {
    let files: any = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All
    });

    if (files?.canceled) return;

    resetTicket();
    setNewTicketUri(files.assets[0].uri);
    setIsFile(false);
    navigate('Ticket');

    dismissActionSheet();
  };

  const handleOpenFilePicker = async () => {
    let file: any = await DocumentPicker.getDocumentAsync({
      type: ['application/xml', 'text/xml']
    });

    if (file?.type != 'success') return;

    const data = await extractDataFormXml(file.uri, file.mimeType);

    resetTicket();

    setXmlData(data);
    setNewTicketUri(file.uri);
    setIsFile(true);
    navigate('Ticket');

    dismissActionSheet();
  };

  const handleActionSheetSelector = () => {
    showActionSheet(
      'Selecciona una opción',
      [
        {
          label: 'Tomar foto',
          onPress: () => handleOpenCamera()
        },
        {
          label: 'Seleccionar archivo',
          onPress: () => handleOpenFilePicker()
        },
        {
          label: 'Seleccionar foto',
          onPress: () => handleOpenGallery()
        },
        {
          label: 'Cancelar',
          onPress: () => dismissActionSheet()
        }
      ]
    );
  };

  const requestPermissions = async () => {
    const permission = await getCameraPermissionsAsync();

    if (permission.status == 'denied') {
      showAlert('Permisos de cámara', 'Para poder utilizar la cámara, necesitamos que nos otorgues los permisos correspondientes. Por favor, ve a la configuración de tu dispositivo y otórganos los permisos correspondientes.');
    }

    if (permission.status !== 'granted') {
      const newPermission = await requestCameraPermissionsAsync();
      if (newPermission.status === 'granted') {
        //its granted.
      }
    }
  };

  useEffect(() => {
    requestPermissions();
  }, []);

  return (
    <TouchableRipple
      rippleColor={Colors.ripple}
      borderless
      onPress={handleActionSheetSelector}
      style={styles.floatButton}
    >
      <View
        style={styles.button}
      >
        <Ionicons name="camera-outline" size={30} color="white"/>
      </View>
    </TouchableRipple>
  );
};

export default CameraFloatButton;

const styles = StyleSheet.create({
  floatButton: {
    position: 'absolute',
    bottom: 30,
    right: 20,
    width: 70,
    height: 70,
    borderRadius: 100,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  button: {
    width: '100%',
    height: '100%',
    borderRadius: 100,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#192a56'
  }
});
