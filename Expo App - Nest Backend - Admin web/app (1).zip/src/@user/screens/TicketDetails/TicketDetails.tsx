import React, { useEffect, useMemo, useState } from 'react';
import { Colors, KeyboardAwareScrollView, Text, View } from 'react-native-ui-lib';
import AutoHeightImage from "react-native-auto-height-image";
import PrimaryButton from "@app/@core/components/VButton";
import { Feather, FontAwesome, Ionicons } from '@expo/vector-icons';
import { useTicket } from "@app/@user/hooks/useTicket";
import * as ImagePicker from "expo-image-picker";
import { useActionSheetStore } from "@app/@core/store/useActionSheetStore";
import { useBackHandler } from "@react-native-community/hooks";
import useAlert from "@app/@core/hooks/useAlert";
import { useTicketStore } from "@app/@user/store/useTicketStore";
import Header from "@app/@core/components/Header";
import { LogBox, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { VPicker } from "@app/@core/components/VPicker";
import { VInput } from "@app/@core/components/VInput";
import { VDatePicker } from "@app/@core/components/VDatePicker";
import ImageView from "react-native-image-viewing";
import * as DocumentPicker from "expo-document-picker";
import { TaxType } from "@app/@user/enums/TaxType";

const TicketDetails = () => {
  LogBox.ignoreLogs(['Warning: ...']);
  LogBox.ignoreAllLogs();
  const { confirm } = useAlert();
  const { showActionSheet, dismissActionSheet } = useActionSheetStore();
  const { newTicketUri, setNewTicketUri, setIsFile, isFile, setXmlData, xmlData } = useTicketStore();
  const navigation: any = useNavigation();
  const [visible, setIsVisible] = useState(false);
  const {
    control,
    errors,
    submit,
    isValid,
    providers,
    isDirty,
    paymentTypes,
    setValue,
    extractDataFormXml,
    getValues
  } = useTicket();

  const providersValues = useMemo(() => {
    return providers.map((provider: any) => ({
      label: provider.name,
      value: provider.id
    }));
  }, [providers]);

  const handleOpenCamera = async () => {
    let image: any = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images
    });

    if (image.canceled) return;

    setValue('ticketUrl', image.assets[0].uri, { shouldDirty: true });
    setIsFile(false);
    setNewTicketUri(image.uri);
    dismissActionSheet();
  };

  const handleOpenGallery = async () => {
    let images: any = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images
    });

    if (images.canceled) return;

    setValue('ticketUrl', images.assets[0].uri, { shouldDirty: true });
    setIsFile(false);

    setNewTicketUri(images.assets[0].uri);
    dismissActionSheet();
  };

  const handleOpenFilePicker = async () => {
    let file: any = await DocumentPicker.getDocumentAsync({
      type: ['application/xml', 'text/xml']
    });

    if (file?.type != 'success') return;

    const data = await extractDataFormXml(file.uri, file.mimeType);
    setXmlData(data);

    setValue('ticketUrl', file.uri, { shouldDirty: true });
    setIsFile(true);
    setNewTicketUri(file.uri);
    dismissActionSheet();
  };

  const backConfirmHandler = () => {
    if (isDirty) return confirm('¿Estás seguro de salir?', 'Si sales se perderán los cambios', () => {
      navigation.navigate('Tickets');
    });

    navigation.navigate('Tickets');
  };

  useBackHandler(() => {
    backConfirmHandler();
    return true;
  });

  const handleActionSheetSelector = () => {
    showActionSheet(
      'Selecciona una opción',
      [
        {
          label: 'Tomar foto',
          onPress: () => handleOpenCamera()
        },
        {
          label: 'Seleccionar archivo',
          onPress: () => handleOpenFilePicker()
        },
        {
          label: 'Seleccionar foto',
          onPress: () => handleOpenGallery()
        },
        {
          label: 'Cancelar',
          onPress: () => console.log('Cancelar')
        }
      ]
    );
  };

  const loadXmlData = () => {
    console.log(JSON.stringify(xmlData));
    let exemptTotal = 0;
    const emisor = xmlData['cfdi:Comprobante']['cfdi:Emisor']['_attributes'];
    const concepts = xmlData['cfdi:Comprobante']['cfdi:Conceptos']['cfdi:Concepto']['_attributes'];
    const voucher = xmlData['cfdi:Comprobante']['_attributes'];
    const taxes = xmlData['cfdi:Comprobante']['cfdi:Impuestos']['_attributes'];
    const subtotal = xmlData['cfdi:Comprobante']['_attributes']['SubTotal'];
    const total = xmlData['cfdi:Comprobante']['_attributes']['Total'];

    let complements = xmlData['cfdi:Comprobante']['cfdi:Complemento'] && xmlData['cfdi:Comprobante']['cfdi:Complemento']['implocal:ImpuestosLocales']
      ? xmlData['cfdi:Comprobante']['cfdi:Complemento']['implocal:ImpuestosLocales']['implocal:TrasladosLocales']
      : null;

    if (!Array.isArray(complements)) complements = [complements];

    let retentions = xmlData['cfdi:Comprobante']['cfdi:Impuestos']['cfdi:Retenciones']
      ? xmlData['cfdi:Comprobante']['cfdi:Impuestos']['cfdi:Retenciones']['cfdi:Retencion']
      : null;

    if (!Array.isArray(retentions)) retentions = [retentions];

    let traslados = xmlData['cfdi:Comprobante']['cfdi:Impuestos']['cfdi:Traslados']
      ? xmlData['cfdi:Comprobante']['cfdi:Impuestos']['cfdi:Traslados']['cfdi:Traslado']
      : null;

    if (!Array.isArray(traslados)) traslados = [traslados];

    const retentionsTotal = taxes['TotalImpuestosRetenidos'] ? taxes['TotalImpuestosRetenidos'] : 0;
    const trasladosTotal = taxes['TotalImpuestosTrasladados'] ? taxes['TotalImpuestosTrasladados'] : 0;

    let retentionIva = 0;
    let retentionIsr = 0;

    for (const retention of retentions) {
      if (!retention) continue;

      if (retention['_attributes']['TipoFactor'] === 'Exento') {
        exemptTotal = +retention['_attributes']['Importe'];
      }

      if (retention['_attributes']['Impuesto'] === TaxType.IVA) {
        retentionIva = +retention['_attributes']['Importe'];
      }

      if (retention['_attributes']['Impuesto'] === TaxType.ISR) {
        retentionIsr = +retention['_attributes']['Importe'];
      }
    }

    let trasladoIva16 = 0;
    let trasladoIva8 = 0;

    for (const traslado of traslados) {
      if (!traslado) continue;

      if (traslado['_attributes']['TipoFactor'] === 'Exento') {
        exemptTotal = +traslado['_attributes']['Importe'];
      }

      if (traslado['_attributes']['Impuesto'] === TaxType.IVA) {
        if (traslado['_attributes']['TasaOCuota'] === '0.160000') {
          trasladoIva16 = +traslado['_attributes']['Importe'];
        }

        if (traslado['_attributes']['TasaOCuota'] === '0.080000') {
          trasladoIva8 = +traslado['_attributes']['Importe'];
        }
      }
    }

    for (const complement of complements) {
      if (!complement) continue;
      if (complement['_attributes']['TipoFactor'] === 'Exento' || complement['_attributes']['ImpLocTrasladado'] === 'ISH') {
        exemptTotal = +complement['_attributes']['Importe'];
      }
    }

    setValue('providerRfc', emisor['Rfc'], { shouldDirty: true });
    setValue('providerName', emisor['Nombre'], { shouldDirty: true });
    setValue('concept', concepts['Descripcion'], { shouldDirty: true });
    setValue('subtotal', subtotal, { shouldDirty: true });
    setValue('iva', trasladoIva16, { shouldDirty: true });
    setValue('iva8', trasladoIva8, { shouldDirty: true });
    setValue('total', total, { shouldDirty: true });
    setValue('paymentType', voucher['MetodoPago'], { shouldDirty: true });
    setValue('date', voucher['Fecha'], { shouldDirty: true });
    setValue('retentionIva', retentionIva, { shouldDirty: true });
    setValue('retentionIsr', retentionIsr, { shouldDirty: true });
    setValue('retentionsTotal', retentionsTotal, { shouldDirty: true });
    setValue('trasladosTotal', trasladosTotal, { shouldDirty: true });
    setValue('exempt', exemptTotal, { shouldDirty: true });
  };

  useEffect(() => {
    if (xmlData) {
      loadXmlData();
    }
  }, [xmlData]);

  return (
    <View
      flex-1
    >
      <Header
        onBackPress={backConfirmHandler}
        headerTitle={'Agregar ticket'}
      />
      <KeyboardAwareScrollView
        contentContainerStyle={{
          flexGrow: 1,
          paddingHorizontal: 10,
          paddingBottom: 20
        }}
      >
        <>
          <View
            marginT-10
            centerH
          >
            <TouchableOpacity
              onPress={() => setIsVisible(true)}
            >
              <AutoHeightImage
                source={{ uri: newTicketUri }}
                width={100}
              />
            </TouchableOpacity>
          </View>

          {isFile && (
            <View center>
              <FontAwesome name="file" size={100} color="#192a56"/>
            </View>
          )}

          <View
            marginT-15
          >
            {xmlData && (
              <View marginL-5>
                <Text
                  style={{ fontWeight: 'bold', fontSize: 18 }}
                >Proveedor</Text>
                <Text style={{ fontSize: 17 }}>{getValues('providerName')}</Text>

                <Text style={{ fontWeight: 'bold', fontSize: 18 }} marginT-10>RFC</Text>
                <Text style={{ fontSize: 17 }}>{getValues('providerRfc')}</Text>
              </View>
            )}
          </View>

          <View
            marginT-15
          >
            <VInput
              isRequired={true}
              control={control}
              returnKeyType={'next'}
              type={'text'}
              errors={errors}
              label="Concepto"
              name={'concept'}
            />
          </View>

          <View
            marginT-15
          >
            <VInput
              icon={() => <FontAwesome name="dollar" size={20} color="#192a56"/>}
              isRequired={true}
              control={control}
              returnKeyType={'done'}
              type={'numeric'}
              errors={errors}
              label="Total"
              name={'total'}
            />
          </View>

          <View
            marginT-15
          >
            {xmlData
              ? (
                <View marginL-5>
                  <Text
                    style={{ fontWeight: 'bold', fontSize: 18 }}
                  >Forma de pago</Text>
                  <Text
                    style={{ fontSize: 17 }}
                  >{getValues('paymentType')}</Text>
                </View>
              )
              : <VPicker
                isRequired={true}
                control={control}
                errors={errors}
                values={paymentTypes}
                label="Forma de pago"
                name={'paymentType'}
              />
            }
          </View>

          <View
            marginT-15
          >
            {xmlData
              ? (
                <View marginL-5>
                  <Text
                    style={{ fontWeight: 'bold', fontSize: 18 }}
                  >Fecha</Text>
                  <Text
                    style={{ fontSize: 17 }}
                  >{getValues('date')}</Text>
                </View>
              )
              : <VDatePicker
                isRequired={true}
                control={control}
                errors={errors}
                label="Fecha"
                name={'date'}
              />
            }
          </View>
        </>

        <View
          marginT-30
        >
          <PrimaryButton
            secondary
            width={'100%'}
            height={60}
            label="Cambiar adjunto"
            icon={<Ionicons name="camera-outline" size={20} color="#192a56"/>}
            onPress={handleActionSheetSelector}
          />

          <View marginT-15>
            {isValid ? <PrimaryButton
                width={'100%'}
                label="Enviar"
                height={60}
                color={Colors.success}
                icon={<Feather name="check-circle" size={20} color="white"/>}
                onPress={submit}
              />
              : <PrimaryButton
                width={'100%'}
                height={60}
                label="Guardar"
                icon={<Ionicons name="save" size={20} color="white"/>}
                onPress={submit}
              />}
          </View>
        </View>
        <ImageView
          images={[{ uri: newTicketUri }]}
          imageIndex={0}
          visible={visible}
          onRequestClose={() => setIsVisible(false)}
        />
      </KeyboardAwareScrollView>
    </View>
  );
};

export default TicketDetails;
