import React, { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { useTicketsFilterStore } from "@app/@user/store/useTicketsFilterStore";
import { useFirebaseData } from "@app/@core/hooks/useFirebaseData";

export const useTicketsFilters = () => {
  const [providers, setProviders] = useState<any>([]);
  const { collectionWithIds } = useFirebaseData({ collectionPath: 'providers' });
  const {
    setFilter,
    resetFilters,
    provider,
    fromDate,
    toDate
  } = useTicketsFilterStore();
  const { control, reset, getValues, formState: { errors, isDirty } } = useForm({
    mode: 'onChange',
    defaultValues: {
      provider: provider || '',
      fromDate: fromDate,
      toDate: toDate
    }
  });

  const loadProviders = async () => {
    const providers = await collectionWithIds([{
      type: 'where',
      field: 'trash',
      operator: '==',
      value: false
    },
      {
        type: 'orderBy',
        field: 'name',
        direction: 'asc'
      }]);

    setProviders(providers);
  };

  const handleCleanFilters = () => {
    resetFilters();
    reset();
  };

  const handleApplyFilters = () => {
    setFilter({...getValues()});
  };

  useEffect(() => {
    loadProviders();
  }, []);

  return {
    control,
    errors,
    isDirty,
    providers,
    handleCleanFilters,
    handleApplyFilters
  };
};
