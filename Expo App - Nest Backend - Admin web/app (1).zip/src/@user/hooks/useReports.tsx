import { useEffect, useState } from 'react';
import { useFirebaseData } from "@app/@core/hooks/useFirebaseData";
import { useReportsStore } from "@app/@user/store/useReportsStore";
import { useReportsFilterStore } from "@app/@user/store/useReportsFilterStore";

const useReports = () => {
  const { setReports, reportsFiltered, reports, resetReports, setReportsFiltered } = useReportsStore();
  const { toDate, fromDate, project, costCenter, text } = useReportsFilterStore();
  const [currentReports, setCurrentReports] = useState<any[]>([]);
  const { docs } = useFirebaseData({
    collectionPath: 'reports',
    initSubscribe: true,
    queries: [{
      field: 'createdAt',
      type: 'orderBy',
      direction: 'desc'
    }]
  });

  useEffect(() => {
    setReports(docs);
  }, [docs]);


  useEffect(() => {
    if (!toDate && !fromDate && !project && !text && !costCenter) return resetReports();

    const currentReportsFiltered = reports.filter((report: any) => {
      return (!!project ? report?.project?.value === project : true)
        && (toDate && fromDate ? report?.createdAt >= fromDate && report?.createdAt <= toDate : true)
        && (!!text ? report?.name?.toLowerCase().includes(text.toLowerCase()) : true)
        && (!!costCenter ? report?.costCenter?.value === costCenter : true);
    });

    setReportsFiltered(currentReportsFiltered);
  }, [toDate, fromDate, project, text, costCenter]);


  useEffect(() => {
    setCurrentReports(reportsFiltered);
  }, [reportsFiltered]);

  return {
    reports: currentReports
  };
};

export default useReports;
