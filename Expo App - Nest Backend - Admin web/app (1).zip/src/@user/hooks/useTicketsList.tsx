import React, { useEffect, useState } from 'react';
import { useFirebaseData } from "@app/@core/hooks/useFirebaseData";
import { useTicketsStore } from "@app/@user/store/useTicketsStore";
import { useTicketsFilterStore } from "@app/@user/store/useTicketsFilterStore";

export const useTicketsList = () => {
  const { setTickets, ticketsFiltered, tickets, setTicketsFiltered, resetTickets } = useTicketsStore();
  const { toDate, fromDate, provider, text } = useTicketsFilterStore();
  const [currentTickets, setCurrentTickets] = useState<any[]>([]);
  const { docs, populate } = useFirebaseData({
    collectionPath: 'tickets',
    initSubscribe: true,
    queries: [{
      field: 'createdAt',
      type: 'orderBy',
      direction: 'desc'
    }]
  });

  const loadTickets = async () => {
    const populatedData: any[] = await populate(docs, ['provider']);
    setTickets(populatedData.map((ticket: any) => ({
      ...ticket,
      status: ticket?.isCompleted ? 'complete' : 'pending'
    })));
  };

  useEffect(() => {
    loadTickets();
  }, [docs]);

  useEffect(() => {
    if (!toDate && !fromDate && !provider && !text) return resetTickets();

    const filteredTickets = tickets.filter((ticket: any) => {
      return (!!provider ? ticket?.provider?.id === provider : true)
        && (toDate && fromDate ? ticket?.date >= fromDate && ticket?.date <= toDate : true)
        && (!!text ? ticket?.concept?.toLowerCase().includes(text.toLowerCase()) : true)
    });

    setTicketsFiltered(filteredTickets);
  }, [toDate, fromDate, provider, text]);

  useEffect(() => {
    setCurrentTickets(ticketsFiltered);
  }, [ticketsFiltered]);

  return {
    tickets: currentTickets
  };
};
