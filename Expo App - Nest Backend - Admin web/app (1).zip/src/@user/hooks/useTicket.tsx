import { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { IQuery, useFirebaseData } from "@app/@core/hooks/useFirebaseData";
import { useLoaderStore } from "@app/@core/store/useLoaderStore";
import { isUriLocal, uriToBlob } from "@app/@core/utils/utilities";
import useAlert from "@app/@core/hooks/useAlert";
import { useTicketStore } from "@app/@user/store/useTicketStore";
import { useNavigation } from "@react-navigation/native";
import { useUserStore } from "@app/@user/store/useUserStore";
import moment from "moment";
import { apiBaseUrl } from "@app/firebase/config";

export const useTicket = () => {
  const { showLoader, hideLoader } = useLoaderStore();
  const { user } = useUserStore();
  const { showAlert } = useAlert();
  const { navigate }: any = useNavigation();
  const [providers, setProviders] = useState<any>([]);
  const { add, uploadFile, update, getReference, collectionWithIds } = useFirebaseData({ collectionPath: 'tickets' });
  const { newTicketUri, ticket, isFile } = useTicketStore();
  const {
    control,
    getValues,
    setValue,
    formState: { errors, isValid, isDirty }
  } = useForm({
    mode: 'onChange',
    defaultValues: {
      provider: ticket?.provider?.id || '',
      providerRfc: ticket?.providerRfc || '',
      providerName: ticket?.providerName || '',
      subtotal: ticket?.subtotal || '',
      iva: ticket?.iva || '',
      iva8: ticket?.iva8 || '',
      paymentType: ticket?.paymentType || '',
      total: ticket?.total || '',
      date: ticket?.date || new Date().getTime(),
      concept: ticket?.concept || '',
      ticketUrl: newTicketUri || '',
      user: getReference(`users/${user?.id}`),
      retentionIva: ticket?.retentionIva || 0,
      retentionIsr: ticket?.retentionIsr || 0,
      retentionsTotal: ticket?.retentionsTotal || 0,
      trasladosTotal: ticket?.trasladosTotal || 0,
      exempt: ticket?.exempt || 0,
    }
  });
  const pickerDataQueries: IQuery[] = [{
    type: 'where',
    field: 'trash',
    operator: '==',
    value: false
  },
    {
      type: 'orderBy',
      field: 'name',
      direction: 'asc'
    }];
  const paymentTypes = [
    {
      label: 'Tarjeta de crédito',
      value: 'Tarjeta de crédito'
    },
    {
      label: 'Tarjeta de débito',
      value: 'Tarjeta de débito'
    },
    {
      label: 'Efectivo',
      value: 'Efectivo'
    }
  ];


  const loadProviders = async () => {
    const providers = await collectionWithIds(pickerDataQueries, 'providers');

    setProviders(providers);
  };

  const updateTicket = async () => {
    const formTicket: any = getValues();
    let ticketBlob = null;

    if (isUriLocal(formTicket.ticketUrl)) ticketBlob = await uriToBlob(formTicket.ticketUrl);

    await update(
      ticket.id,
      {
        ...formTicket,
        isCompleted: true,
        project: formTicket.project ? getReference(`projects/${formTicket.project}`) : '',
        costCenter: formTicket.costCenter ? getReference(`costsCenter/${formTicket.costCenter}`) : '',
        provider: formTicket.provider ? getReference(`providers/${formTicket.provider}`) : '',
        date: formTicket.date ? moment(formTicket.date).toDate().getTime() : '',
        isFile
      });

    if (ticketBlob) {
      const ticketUrl = await uploadFile(ticketBlob, `tickets/${ticket.id}`);
      await update(ticket.id, { ticketUrl });
    }

    navigate('Tickets');
    hideLoader();
  };

  const submit = async () => {
    showLoader();

    try {
      if (!!ticket?.id) return updateTicket();

      const ticketForm: any = getValues();

      const ticketBlob = await uriToBlob(ticketForm.ticketUrl);

      const { id }: any = await add({
        ...ticketForm,
        ticketUrl: '',
        isCompleted: true,
        provider: ticketForm.provider ? getReference(`providers/${ticketForm.provider}`) : '',
        date: ticketForm.date ? moment(ticketForm.date).toDate().getTime() : '',
        isFile
      });

      const ticketUrl = await uploadFile(ticketBlob, `tickets/${id}`);
      await update(id, { ticketUrl });

      navigate('Tickets');

    } catch (e) {
      console.log(e);
      showAlert('Error', 'Ocurrió un error al guardar el ticket');
    }
    hideLoader();
  };

  const extractDataFormXml = async (uri: string, type: string) => {
    const formData = new FormData();
    formData.append('file', {
      uri,
      type,
    });

    try {
      const resp: any = await fetch(`${apiBaseUrl}/users/xmlData`, {
        method: 'POST',
        body: formData
      });

      const respJson = await resp.json();

      if (!respJson.ok) throw new Error('Ocurrió un error al extraer los datos del ticket');

      return respJson.data;
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    loadProviders();
  }, []);

  return {
    control,
    errors,
    submit,
    isValid,
    getValues,
    setValue,
    providers,
    isDirty,
    paymentTypes,
    extractDataFormXml
  };
};
