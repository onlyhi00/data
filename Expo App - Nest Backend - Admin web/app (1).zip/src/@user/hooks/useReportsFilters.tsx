import React, { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { useTicketsFilterStore } from "@app/@user/store/useTicketsFilterStore";
import { useFirebaseData } from "@app/@core/hooks/useFirebaseData";
import { useUserStore } from "@app/@user/store/useUserStore";
import { useReportsFilterStore } from "@app/@user/store/useReportsFilterStore";

export const useReportsFilters = () => {
  const [projects, setProjects] = useState<any>([]);
  const [costsCenters, setCostsCenters] = useState<any>([]);
  const { collectionWithIds } = useFirebaseData({ collectionPath: 'projects' });
  const { user } = useUserStore();
  const {
    setFilter,
    resetFilters,
    project,
    fromDate,
    toDate,
    costCenter
  } = useReportsFilterStore();
  const { control, reset, getValues, formState: { errors, isDirty } } = useForm({
    mode: 'onChange',
    defaultValues: {
      project: project || '',
      costCenter: costCenter || '',
      fromDate: fromDate,
      toDate: toDate
    }
  });

  const loadProjects = async () => {
    const projects = await collectionWithIds([
      {
        type: 'where',
        field: 'trash',
        operator: '==',
        value: false
      },
      {
        type: 'orderBy',
        field: 'name',
        direction: 'asc'
      },
      {
        type: 'where',
        field: 'byUser',
        operator: '==',
        value: user.byUser
      }
    ]);

    setProjects(projects);
  };

  const loadCostsCenter = async () => {
    const costsCenter = await collectionWithIds([
      {
        type: 'where',
        field: 'trash',
        operator: '==',
        value: false
      },
      {
        type: 'orderBy',
        field: 'name',
        direction: 'asc'
      },
      {
        type: 'where',
        field: 'byUser',
        operator: '==',
        value: user.byUser
      }
    ], 'costsCenter');

    setCostsCenters(costsCenter);
  };

  const handleCleanFilters = () => {
    resetFilters();
    reset();
  };

  const handleApplyFilters = () => {
    setFilter({ ...getValues() });
  };

  useEffect(() => {
    loadProjects();
    loadCostsCenter();
  }, []);

  return {
    control,
    errors,
    isDirty,
    projects,
    costsCenters,
    handleCleanFilters,
    handleApplyFilters
  };
};
