import React, { useCallback, useEffect, useState } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { Colors } from "react-native-ui-lib";
import Root from "@app/Root";

export default () => {
  const [ready, setReady] = useState(false);

  const onLaunch = useCallback(async () => {
    await SplashScreen.preventAutoHideAsync();

    setReady(true);
    await SplashScreen.hideAsync();
  }, []);

  useEffect(() => {
    onLaunch();
  }, [onLaunch]);

  return (
    <SafeAreaView
      style={{
        ...styles.container,
      }}
    >
      <StatusBar
        translucent={false}
        style={'light'}
        backgroundColor={Colors.primary}/>
      <Root/>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: 0,
    flex: 1
  }
});
