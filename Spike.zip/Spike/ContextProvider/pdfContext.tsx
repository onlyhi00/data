"use client";
import { createContext, useState, ReactNode } from "react";

type PdfContextType = {
  pdfContext: any; // replace 'any' with the type of 'pdfContext' if possible
  setPdfContext: React.Dispatch<React.SetStateAction<any>>; // replace 'any' with the type of 'pdfContext' if possible
};

export const PdfContext = createContext<PdfContextType>({
  pdfContext: {},
  setPdfContext: () => {},
});

type Props = {
  children: ReactNode;
};

export function PdfContextProvider({ children }: Props) {
  const [pdfContext, setPdfContext] = useState({});

  return (
    <PdfContext.Provider value={{ pdfContext, setPdfContext }}>
      {children}
    </PdfContext.Provider>
  );
}
