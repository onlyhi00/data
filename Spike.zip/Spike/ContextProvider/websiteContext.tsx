"use client";
import { createContext, useState, ReactNode } from "react";

type WebsiteContextType = {
  websiteContext: any; // replace 'any' with the type of 'WebsiteContext' if possible
  setWebsiteContext: React.Dispatch<React.SetStateAction<any>>; // replace 'any' with the type of 'WebsiteContext' if possible
};

export const WebsiteContext = createContext<WebsiteContextType>({
  websiteContext: {},
  setWebsiteContext: () => {},
});

type Props = {
  children: ReactNode;
};

export function WebsiteContextProvider({ children }: Props) {
  const [websiteContext, setWebsiteContext] = useState({});

  return (
    <WebsiteContext.Provider value={{ websiteContext, setWebsiteContext }}>
      {children}
    </WebsiteContext.Provider>
  );
}
