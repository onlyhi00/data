"use client";
import { createContext, useState, ReactNode } from "react";

type KeyContextType = {
  openAiKey: any; // replace 'any' with the type of 'openAiKey' if possible
  setOpenAiKey: React.Dispatch<React.SetStateAction<any>>; // replace 'any' with the type of 'openAiKey' if possible
};

export const KeyContext = createContext<KeyContextType>({
  openAiKey: {},
  setOpenAiKey: () => {},
});

type Props = {
  children: ReactNode;
};

export function KeyContextProvider({ children }: Props) {
  const [openAiKey, setOpenAiKey] = useState({});

  return (
    <KeyContext.Provider value={{ openAiKey, setOpenAiKey }}>
      {children}
    </KeyContext.Provider>
  );
}
