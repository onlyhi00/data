"use client";
import { createContext, useState, ReactNode } from "react";

type TextContextType = {
  textContext: any; // replace 'any' with the type of 'TextContext' if possible
  setTextContext: React.Dispatch<React.SetStateAction<any>>; // replace 'any' with the type of 'TextContext' if possible
};

export const TextContext = createContext<TextContextType>({
  textContext: {},
  setTextContext: () => {},
});

type Props = {
  children: ReactNode;
};

export function TextContextProvider({ children }: Props) {
  const [textContext, setTextContext] = useState({});

  return (
    <TextContext.Provider value={{ textContext, setTextContext }}>
      {children}
    </TextContext.Provider>
  );
}
