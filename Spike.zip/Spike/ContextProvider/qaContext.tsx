"use client";
import { createContext, useState, ReactNode } from "react";

type QAContextType = {
  qaContext: any; // replace 'any' with the type of 'QAContext' if possible
  setQAContext: React.Dispatch<React.SetStateAction<any>>; // replace 'any' with the type of 'QAContext' if possible
};

export const QAContext = createContext<QAContextType>({
  qaContext: {},
  setQAContext: () => {},
});

type Props = {
  children: ReactNode;
};

export function QAContextProvider({ children }: Props) {
  const [qaContext, setQAContext] = useState({});

  return (
    <QAContext.Provider value={{ qaContext, setQAContext }}>
      {children}
    </QAContext.Provider>
  );
}
