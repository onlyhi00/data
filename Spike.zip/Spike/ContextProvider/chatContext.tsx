"use client";
import { createContext, useState, ReactNode } from "react";

type ChatContextType = {
  chat: any; // replace 'any' with the type of 'chat' if possible
  setChat: React.Dispatch<React.SetStateAction<any>>; // replace 'any' with the type of 'chat' if possible
};

export const ChatContext = createContext<ChatContextType>({
  chat: {},
  setChat: () => {},
});

type Props = {
  children: ReactNode;
};

export function ChatContextProvider({ children }: Props) {
  const [chat, setChat] = useState({});

  return (
    <ChatContext.Provider value={{ chat, setChat }}>
      {children}
    </ChatContext.Provider>
  );
}
