"use client";
import { usePathname, useRouter } from "next/navigation";

const navItems = ["mychatbot", "pricing", "api"];

const Navbar = () => {
  const pathname = usePathname();
  const router = useRouter();
  return (
    <div className="flex justify-center items-center w-full">
      {navItems.map((item) => (
        <button
          key={item}
          onClick={() => router.push("/" + item)}
          className={`uppercase px-2 py-2 mt-2 text-sm font-semibold bg-transparent rounded-lg md:mt-0 md:ml-4 hover:text-primary-600  ${
            !pathname.includes("/" + item)
              ? "text-zinc-600"
              : "text-primary-600"
          }`}
        >
          {item}
        </button>
      ))}
    </div>
  );
};

export default Navbar;
