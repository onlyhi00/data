import React from "react";

type Props = {};

const Spinner = (props: Props) => {
  return (
    <div className="absolute top-0 left-0 w-screen h-screen flex items-center justify-center bg-white backdrop-blur-lg bg-opacity-5">
      <div className="inline-flex flex-col gap-3">
        <div id="nest3"></div>
        <p className="text-center">Loading...</p>
      </div>
    </div>
  );
};

export default Spinner;
