import React, { useEffect, useRef, useState } from "react";
import Clipboard from "assets/Clipboard";
import DoubleCheck from "assets/DoubleCheck";
import copy from "copy-text-to-clipboard";

type Props = {
  className?: string;
  state: boolean;
  close: any;
  item: string;
};

const EmbededModal = ({ className, state, close, item }: Props) => {
  const modal = useRef(null);
  const [copyText, setCopyText] = useState(true);
  const [menu_status, setMenuStatus] = useState(state);
  useEffect(() => {
    setMenuStatus(state);
  }, [state]);

  const handleClipboard = () => {
    const text = `<style>
    #SPIKE-MSG-BOX {
  scrollbar-width: thin;
  scrollbar-color: blue orange;
}

#SPIKE-MSG-BOX::-webkit-scrollbar {
  width: 12px;
}

#SPIKE-MSG-BOX::-webkit-scrollbar-track {
  background: none;
}

#SPIKE-MSG-BOX::-webkit-scrollbar-thumb {
  background-color: white;
  border-radius: 20px;
  border: 0;
}
  </style>
    <script src="${process.env.API_URL}/bubble.min.js" defer authId="${process.env.api_key}" chatId="${item}"></script>`;
    copy(text);
    setCopyText(false);
    // }
    setTimeout(() => {
      setCopyText(true);
    }, 500);
  };

  return (
    <div
      id="popup-modal"
      className={`fixed top-0 left-0 right-0 z-50 overflow-x-hidden overflow-y-auto md:inset-0 max-h-full flex items-start justify-center ${className} ${
        menu_status ? "animate-slideUpEnter" : "hidden"
      } backdrop-blur-md bg-opacity-40 bg-white`}
      ref={modal}
    >
      <div className="relative w-full max-w-md max-h-full">
        <div className="relative mt-52 bg-main-bg border-[1px] border-zinc-300 rounded-lg shadow-xl shadow-zinc-300">
          <button
            type="button"
            className="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-300 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center "
            onClick={close}
          >
            <svg
              className="w-3 h-3"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 14 14"
            >
              <path
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
              />
            </svg>
            <span className="sr-only">Close modal</span>
          </button>
          <div className="p-6">
            <h5 className="text-2xl font-sans font-semibold">
              Embeded on your Site
            </h5>
            <p className="text-sm my-3">
              To add a chat bubble to the bottom right of your website add this
              script tag to your html
            </p>
            <div className="relative rounded-md bg-slate-100 p-5 text-xs break-words space-y-5">
              <div className="absolute top-2 right-2">
                <div className="relative">
                  <button onClick={handleClipboard}>
                    {copyText ? (
                      <Clipboard className="w-5 text-zinc-700 hover:text-blue-700 cursor-pointer" />
                    ) : (
                      <DoubleCheck className="w-4 fill-blue-700 cursor-pointer" />
                    )}
                  </button>
                  {copyText ? (
                    <></>
                  ) : (
                    <div className="absolute bottom-8 -left-[50%] inline-block px-2 py-1 font-medium text-white transition-opacity duration-300 bg-zinc-500 rounded-md shadow-sm opacity-100 tooltip text-xs">
                      Copied
                      <div className="tooltip-arrow"></div>
                    </div>
                  )}
                </div>
              </div>
              <code>
                {`
                <style>
                #SPIKE-MSG-BOX {
              scrollbar-width: thin;
              scrollbar-color: blue orange;
            }

            #SPIKE-MSG-BOX::-webkit-scrollbar {
              width: 12px;
            }
            
            #SPIKE-MSG-BOX::-webkit-scrollbar-track {
              background: none;
            }
            
            #SPIKE-MSG-BOX::-webkit-scrollbar-thumb {
              background-color: white;
              border-radius: 20px;
              border: 0;
            }
              </style>
                <script
                  src="${process.env.API_URL}/bubble.min.js"
                  defer
                  authId="${process.env.api_key}"
                  chatId="${item}"
                ></script>`}
              </code>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmbededModal;
