import { chatDataService } from "@/services/chatDataService";
import React, { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";

type Props = {
  className?: string;
  state: boolean;
  close: any;
  item: string;
};

const DeleteChat = ({ className, state, close, item }: Props) => {
  const modal = useRef(null);
  const [menu_status, setMenuStatus] = useState(state);
  useEffect(() => {
    setMenuStatus(state);
  }, [state]);
  const chatService = chatDataService();
  const route = useRouter();

  const handleDelete = () => {
    toast.promise(
      chatService
        .deleteById(item)
        .then((res) => {
          if (res) {
            route.push("/mychatbot");
          }
        })
        .catch((err) => {
          console.error(err);
          toast.error((err as Error).message);
        }),
      {
        loading: "Deleting this item...",
        success: "Success deleting item",
        error: "Failed deleting item",
      }
    );
  };

  // useEffect(() => {
  //   function handleOutsideClick(event: any) {
  //     if (modal?.current && !modal?.current?.contains(event.target)) {
  //       // Clicked outside the div
  //       setMenuStatus(false);
  //     }
  //   }

  //   document.addEventListener('click', handleOutsideClick);

  //   return () => {
  //     document.removeEventListener('click', handleOutsideClick);
  //   };
  // }, [modal]);

  return (
    <div
      id="popup-modal"
      className={`fixed top-0 left-0 right-0 z-50 overflow-x-hidden overflow-y-auto md:inset-0 max-h-full flex items-start justify-center ${className} ${
        menu_status ? "animate-slideUpEnter" : "hidden"
      } backdrop-blur-md bg-opacity-40 bg-white`}
      ref={modal}
    >
      <div className="relative w-full max-w-md max-h-full">
        <div className="relative mt-52 bg-main-bg border-[1px] border-zinc-300 rounded-lg shadow-xl shadow-zinc-300">
          <button
            type="button"
            className="absolute top-3 right-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-300 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center "
            onClick={close}
          >
            <svg
              className="w-3 h-3"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 14 14"
            >
              <path
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
              />
            </svg>
            <span className="sr-only">Close modal</span>
          </button>
          <div className="p-6">
            <p className="my-2 text-lg font-medium text-gray-900 text-center">
              Are you sure deleting this bot?
            </p>
            <div className="flex justify-around text-sm">
              <button
                className="px-4 py-1 border-[1px] border-zinc-400 hover:bg-slate-200 rounded-md"
                onClick={close}
              >
                Cancel
              </button>
              <button
                className="px-4 py-1 border-[1px] border-red-700 rounded-md bg-red-500 hover:bg-red-600 text-white"
                onClick={handleDelete}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeleteChat;
