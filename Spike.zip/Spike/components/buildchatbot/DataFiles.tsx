import React, { useContext, useEffect, useRef, useState } from "react";
import * as pdfjs from "pdfjs-dist";
import { PdfContext } from "ContextProvider/pdfContext";
import toast from "react-hot-toast";
import { encode } from "gpt-tokenizer";
import UploadIcon from "assets/upload";

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

const DataFile = () => {
  const [uploading, setUploading] = useState<boolean>(false);
  const fileInput = useRef<any>();
  const { pdfContext, setPdfContext } = useContext(PdfContext);
  const [pdfData, setPdfData] = useState<object>({});
  const [tokenNumber, setTokenNumber] = useState(0);

  //   use effect to update context
  useEffect(() => {
    setPdfContext(pdfData);
  }, [pdfData]);

  const handlePdfUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      const file = event.target.files?.[0];
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          setUploading(true);
          const pdfData = new Uint8Array(reader.result as ArrayBuffer);
          const pdf = await pdfjs.getDocument({ data: pdfData }).promise;
          const numberOfPages = pdf.numPages;
          let chunks = [];
          let token_num = 0;
          for (let i = 1; i <= numberOfPages; i++) {
            const pdfPage = await pdf.getPage(i);
            const pdfText = await pdfPage.getTextContent();

            if (pdfText.items.length === 0) {
              toast.error("Can't detect text from PDF.");
              break;
            }
            const extractedText = pdfText.items
              .map((item: any) => {
                if (item.str === "") {
                  return "\n";
                }
                return item.str;
              })
              .join(" ");

            console.log(extractedText);
            const encodedToken = encode(extractedText);

            token_num += encodedToken.length;
            setTokenNumber(token_num);
            chunks.push({
              role: "user",
              content: `Page ${i} ${extractedText}`,
            });
            chunks.push({
              role: "assistant",
              content: "Next page please.",
            });
          }
          let obj = {
            name: file?.name,
            chunks: chunks,
          };
          setPdfContext(obj);
          setUploading(false);
          toast.success("Success Pdf uploading!");
        } catch (err: any) {
          setUploading(false);
          toast.error(JSON.stringify(err));
        }
      };
      if (file) {
        reader.readAsArrayBuffer(file);
      }
    } catch (error: any) {
      setUploading(false);
      toast.error(error);
    }
  };
  return (
    <>
      <div>
        <label className=" text-center block mb-2 text-sm font-medium text-gray-900 dark:text-white">
          Upload Files
        </label>
        <div className="flex justify-center">
          <button
            className="border border-neutral-500 p-16 rounded-2xl border-dashed hover:bg-slate-100"
            onClick={() => fileInput.current?.click()}
          >
            <div className="flex justify-center">
              <UploadIcon className=" w-8 h-8 fill-black" />
            </div>
            <div className="flex flex-col items-center justify-center gap-4">
              <div className="text-center justify-center items-center">
                <p className="text-sm text-gray-500 ">Click to select files</p>
                <span className="text-xs text-gray-900" id="file_type_help">
                  Supported File Types: .pdf, .doc, .docx, .txt
                </span>
                <p className="text-gray-900">
                  {uploading ? "Uploading..." : "Upload"}
                </p>
              </div>
            </div>
          </button>
        </div>
        <p
          className="mt-2 text-sm text-center text-gray-500"
          id="file_input_help"
        >
          NOTE: Uploading a PDF using safari doesn't work, we're looking into
          the issue. Make sure the text is OCR'd, i.e. you can copy it.
        </p>
      </div>
      <input
        ref={fileInput}
        accept="text/html,.pdf,.doc,.docx,.txt"
        type="file"
        className="hidden"
        onChange={handlePdfUpload}
      />
      <p className="my-3 text-center">The number of Tokens: {tokenNumber}</p>
    </>
  );
};

export default DataFile;
