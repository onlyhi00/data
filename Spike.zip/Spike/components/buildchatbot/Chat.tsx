import React, { useState, useEffect, useRef, useContext, FC } from "react";
import OpenAI from "openai";
import { ChatContext } from "ContextProvider/chatContext";
import DeleteChat from "components/Modals/DeleteChat";
import EmbededModal from "components/Modals/EmbededModal";
import { DataType } from "@/services/chatDataService";
import { Refresh } from "@/app/icons";
import toast from "react-hot-toast";

type Props = {
  data: DataType;
  item: string;
};

const CHAT_HISTORY_KEY = "chat_history";

interface Message {
  role: "user" | "assistant" | "system";
  content: string;
}

const Chat = ({ data, item }: Props) => {
  const [inputValue, setInputValue] = useState<string>("");
  const [thinking, setThinking] = useState<boolean>(false);
  const [apiError, setApiError] = useState<string | false>(false);
  const [embedState, setEmbedState] = useState<boolean>(false);
  const [deleteState, setDeleteState] = useState<boolean>(false);

  const { setChat } = useContext(ChatContext);
  const openAiKey = process.env.api_key;

  const messageShow = useRef<HTMLDivElement>(null);

  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [chatText, setChatText] = useState("");

  useEffect(() => {
    setChat(chatHistory);
  }, [chatHistory]);

  const handleInputSubmit = async (
    e: React.FormEvent | React.ChangeEvent<HTMLButtonElement>
  ) => {
    setChatText("");

    let chunkValue = inputValue;
    console.log((e as React.ChangeEvent<HTMLButtonElement>).target.textContent);
    if (
      (e as React.ChangeEvent<HTMLButtonElement>).target.textContent &&
      data.interface.suggest_msg
        .split("\n")
        .includes(
          (e as React.ChangeEvent<HTMLButtonElement>).target
            .textContent as string
        )
    ) {
      chunkValue = (e as React.ChangeEvent<HTMLButtonElement>).target
        .textContent as string;
    }
    e.preventDefault();
    if (chunkValue.trim() === "") return;
    if (openAiKey?.trim() === "" || openAiKey === "null") {
      setThinking(false);
      setApiError(
        "OpenAI API key not set. Grab it from https://platform.openai.com/account/api-keys and set it on the top right corner."
      );
      return;
    }
    const userInput: Message = { role: "user", content: chunkValue };
    const updatedChatHistory = [...chatHistory, userInput];
    setChatHistory(updatedChatHistory);
    setInputValue("");

    const openai = new OpenAI({
      apiKey: openAiKey,
      dangerouslyAllowBrowser: true,
    });

    try {
      setThinking(true);
      let arrayTop: Message[] = [
        {
          role: "system",
          content:
            data.prompt +
            " After each page, you will ask the user if there are more pages to be added. If the user provides another page, you will repeat the process until the user writes the exact words 'END OF DATA.' Once the user has finished adding pages, you will switch to 'query mode,' where you will only answer questions related to the contents of the data.",
        },
      ];
      data.chunks.map((item: any) => {
        if (item._id) {
          delete item._id;
        }
        arrayTop.push(item);
      });
      arrayTop.push({
        role: "user",
        content: "END OF DATA",
      });
      arrayTop.push({
        role: "assistant",
        content: "Thank you for the pdf, now you can ask me questions",
      });

      let remaining_part = chatHistory.concat(userInput);
      const response = await openai.chat.completions.create({
        model: data.mode,
        messages: arrayTop.concat(remaining_part),
        temperature: data.temperature,
        stream: true,
      });

      setThinking(false);
      updatedChatHistory.push({ role: "assistant", content: "" });
      for await (const part of response) {
        setChatText((s) => s.concat(part.choices[0]?.delta?.content || ""));

        setChatHistory((updatedChatHistory) => {
          updatedChatHistory[updatedChatHistory.length - 1].content +=
            part.choices[0]?.delta?.content || "";
          return updatedChatHistory;
        });
        if (messageShow.current) {
          try {
            setTimeout(() => {
              if (messageShow.current)
                messageShow.current.scrollTop =
                  messageShow.current?.scrollHeight;
            }, 100);
          } catch (error) {
            console.warn(error);
          }
        }
      }
      // const aiResponse = response.choices[0].message;
      // setChatHistory([...updatedChatHistory, aiResponse]);
    } catch (error: any) {
      setApiError(error.message);
      toast.error(error.message);
      updatedChatHistory.pop();
      setChatHistory(updatedChatHistory);
      setThinking(false);
      if (messageShow.current) {
        try {
          setTimeout(() => {
            if (messageShow.current)
              messageShow.current.scrollTop = messageShow.current?.scrollHeight;
          }, 100);
        } catch (error) {
          console.warn(error);
        }
      }
    }

    setChatHistory((updatedChatHistory) => updatedChatHistory);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      if (!thinking && inputValue.trim() !== "") {
        handleInputSubmit(e);
      }
      e.preventDefault();
    }
  };

  const getTextColor = (color: string) => {
    const hex = color.replace("#", "");
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 128 ? "#000" : "#fff"; // Return black or white based on brightness
  };

  return (
    <div className="w-full h-[calc(100%-5rem)] flex flex-col items-center">
      <div
        id="messages"
        className="flex flex-col space-y-4 p-3 overflow-y-scroll scroll-smooth h-[calc(100%-3rem)] w-2/3 border-2 rounded-t-md relative"
        ref={messageShow}
      >
        <div className="border-b-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {!data.interface.remove_img && data.interface.img && (
              <img
                src={data.interface.img as string}
                className="w-10 h-10 rounded-full"
              />
            )}
            <p
              className={
                data.interface.theme === "dark" ? "text-white" : "text-black"
              }
            >
              {data.interface.display_name}
            </p>
          </div>
          <div className="flex justify-center items-center">
            <button
              className="text-sm py-3   hover:text-zinc-600 text-zinc-700"
              onClick={() => {
                setChatHistory([]);
              }}
            >
              <Refresh className={`h-5 w-5`} />
            </button>
          </div>
        </div>
        <div className="chat-message">
          <div className={`flex items-end`}>
            <div className="flex flex-col space-y-2 text-lg max-w-2xl mx-2 order-2 items-start">
              <div>
                <span
                  className={`px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600 rounded-bl-none`}
                >
                  {data.interface.init_msg}
                </span>
              </div>
            </div>
          </div>
        </div>
        {chatHistory.map((msg, i) => {
          return (
            <div className="chat-message" key={i}>
              <div
                className={`flex items-end ${
                  msg.role !== "user" ? "" : "justify-end"
                }`}
              >
                <div className="flex flex-col space-y-2 text-lg max-w-2xl mx-2 order-2 items-start">
                  <div>
                    <span
                      className={`px-4 py-2 rounded-lg inline-block  ${
                        msg.role !== "user"
                          ? "bg-gray-300 text-gray-600 rounded-bl-none"
                          : "bg-primary-600 text-white rounded-br-none"
                      }`}
                      style={
                        msg.role == "user"
                          ? {
                              color: getTextColor(data.interface.msg_color),
                              backgroundColor: data.interface.msg_color,
                            }
                          : {}
                      }
                    >
                      {msg.content}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {thinking ? (
          <div className="chat-message">
            <div className={`flex items-end`}>
              <div className="flex flex-col space-y-2 text-lg max-w-xs mx-2 order-2 items-start">
                <div>
                  <span
                    className={`px-4 py-2 rounded-lg inline-block bg-gray-300 text-gray-600 rounded-bl-none`}
                  >
                    Um, thinking ...
                  </span>
                </div>
              </div>
            </div>
          </div>
        ) : null}
        <div className="py-3 flex overflow-x-auto absolute bottom-2">
          {data?.interface.suggest_msg &&
            data?.interface.suggest_msg.split("\n").map((item, index) => {
              return (
                <button
                  className="rounded-xl whitespace-nowrap  mr-1 mt-1 py-2 px-3 text-sm   bg-zinc-100 hover:bg-zinc-200"
                  key={index}
                  onClick={handleInputSubmit}
                >
                  {item}
                </button>
              );
            })}
        </div>
      </div>
      <div className="px-4 pt-4 mb-2 sm:mb-0 w-2/3">
        <div className="relative flex">
          <form className="w-full">
            <input
              type="text"
              placeholder="Write your message!"
              name="inputValue"
              id="inputValue"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full focus:outline-none focus:placeholder-gray-400 text-gray-600 placeholder-gray-600 pl-4 bg-gray-200 rounded-md py-3"
            />
          </form>
          <div className="absolute right-0 items-center inset-y-0 hidden sm:flex">
            <button
              type="button"
              className="inline-flex items-center justify-center rounded-lg px-4 py-3 transition duration-500 ease-in-out text-white bg-zinc-500 hover:bg-zinc-400 focus:outline-none cursor-pointer"
              onClick={handleInputSubmit}
              disabled={thinking || inputValue.trim() === ""}
            >
              <span className="font-bold">Send</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                fill="currentColor"
                className="h-6 w-6 ml-2 transform rotate-90"
              >
                <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>

      <EmbededModal
        state={embedState}
        close={() => {
          setEmbedState(false);
        }}
        item={item}
      />
      <DeleteChat
        state={deleteState}
        close={() => {
          setDeleteState(false);
        }}
        item={item}
      />
    </div>
  );
};

export default Chat;
