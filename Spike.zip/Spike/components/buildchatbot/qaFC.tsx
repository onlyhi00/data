import React, { RefObject, useContext, useRef, useState } from "react";
import { encode } from "gpt-tokenizer";
import toast from "react-hot-toast";
import { QAContext } from "@/ContextProvider/qaContext";

type QAType = {
  question: string;
  answer: string;
};

const QAFC = () => {
  const qaForm = useRef<HTMLDivElement>(null);
  const btn = useRef<HTMLButtonElement>(null);
  const { qaContext, setQAContext } = useContext(QAContext);
  const [question, setQuestion] = useState<string>("");
  const [answer, setAnswer] = useState<string>("");
  const [QAs, setQAs] = useState<Array<QAType>>([]);

  const handleQAs = () => {
    if (qaForm.current) {
      qaForm.current.className = "hidden";
      if (encode(question + answer).length > 3000) {
        toast.error("Your token is too much, optimize that!");
        return;
      }
      setQAs([...QAs, { question, answer }]);
      setQuestion("");
      setAnswer("");
      // let encodedToken = encode(websiteObject.chunks[0].content);
      //       let decoded_token = "";
      //       let index = 0;
      //       for (const token of decodeGenerator(encodedToken)) {
      //         if (index >= 2500) {
      //           break;
      //         }
      //         decoded_token += token;
      //         index++;
      //       }
      //       websiteObject.chunks[0].content = decoded_token;
      //       await setWebsiteContext(websiteObject);
      const query: any[] = [];
      [...QAs, { question, answer }].map((item: QAType) => {
        query.push({
          role: "user",
          content: `This is question: ${item.question}, The answer for this question is [${item.answer}]`,
        });
        query.push({
          role: "assistant",
          content: "Next page please.",
        });
      });
      if (encode(JSON.stringify({ query })).length > 3000) {
        toast.error("Your token is too much, optimize that!");
        return;
      }
      setQAContext({ name: "qas", chunks: query });
    }
  };

  return (
    <div>
      <div className="flex justify-end">
        <button
          className="bg-red-500 text-white px-3 py-1 rounded-md block"
          onClick={(e: React.MouseEvent) => {
            if (qaForm.current) {
              qaForm.current.className = "block";
            }
          }}
          ref={btn}
        >
          create one
        </button>
      </div>
      {QAs.length > 0 &&
        QAs.map((item: QAType, index: number) => {
          return (
            <div className="border-t-[1px] mt-2 mx-5 px-5" key={index}>
              <p className="border-b-[1px]">
                <b>Q:</b> {item.question}
              </p>
              <p>
                <b>A: </b>
                {item.answer}
              </p>
            </div>
          );
        })}
      <div ref={qaForm} className="hidden">
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Question
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            type="text"
            onChange={(e) => {
              setQuestion(e.target.value);
            }}
            value={question}
            placeholder="Question..."
          />
        </div>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Answer
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            type="text"
            onChange={(e) => {
              setAnswer(e.target.value);
            }}
            value={answer}
            placeholder="Answer..."
          />
        </div>
        <div className="flex items-center justify-end">
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            type="button"
            onClick={handleQAs}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default QAFC;
