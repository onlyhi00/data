import React, { useState, useEffect, useContext } from "react";
import toast from "react-hot-toast";
import { dataScrapService } from "services";
import { encode } from "gpt-tokenizer";
import Spinner from "components/Spinner";
import { WebsiteContext } from "@/ContextProvider/websiteContext";
import Trash from "@/assets/Trash";

const ScrapData = () => {
  const { websiteContext, setWebsiteContext } = useContext(WebsiteContext);
  const dataService = dataScrapService();
  const [pageURL, setPageURL] = useState("");
  const [btnState, setBtnState] = useState<boolean>(false);
  const getData = async () => {
    setBtnState(true);
    let url;
    try {
      url = new URL(pageURL);
    } catch (error: any) {
      toast.error(error.message);

      setBtnState(false);
      return;
    }
    await dataService.getSuburl(pageURL);
    setBtnState(false);
  };

  useEffect(() => {
    if (dataService.data) {
      let chunks: any[] = [];
      dataService.data.map((item) => {
        chunks.push({
          role: "user",
          content: `This is content of this page ${item.url}: ${item.content}`,
        });
        chunks.push({ role: "assistant", content: `I see, next page please.` });
      });
      const url = new URL(pageURL);
      setWebsiteContext({ name: url.hostname, chunks });
      setBtnState(false);
    }
  }, [dataService.data]);

  const handleData = (index: number) => {
    const data = dataService.data;
    if (data) {
      delete data[index];
      dataService.setData(data);
      toast.success("Success delete website!");
      let chunks: any[] = [];
      data.map((item) => {
        chunks.push({
          role: "user",
          content: `This is content of this page ${item.url}: ${item.content}`,
        });
        chunks.push({ role: "assistant", content: `I see, next page please.` });
      });
      setWebsiteContext({ name: "website", chunks });
    }
  };

  return (
    <div>
      <input
        type="url"
        onChange={(e) => setPageURL(e.target.value)}
        className="w-full border-[1px] border-gray-700 rounded-xl p-5"
      />
      <div className="w-full flex justify-end mt-5">
        <button
          onClick={getData}
          className="bg-gray-800 text-white px-6 py-3 rounded-md shadow-md hover:shadow-xl active:shadow-2xl"
          disabled={btnState}
        >
          {btnState ? "Scraping..." : "Scrape"}
        </button>
      </div>
      <div className="w-full flex flex-col gap-2 mt-3">
        {dataService.data &&
          dataService.data.map((item, index) => {
            return (
              <div
                className="flex gap-2 items-center justify-stretch"
                key={index}
              >
                <input
                  type="text"
                  value={item.url}
                  disabled
                  className="w-8/12 border-[1px] border-gray-700 px-2 py-1 rounded-xl"
                />
                <span className="w-3/12 text-center">
                  token: {encode(item.content).length}
                </span>
                <button
                  className="bg-red-700 text-white w-7 h-8 p-1 rounded-full flex items-center justify-center hover:bg-red-800"
                  onClick={() => {
                    handleData(index);
                  }}
                >
                  <Trash className="w-4 fill-white" />
                </button>
              </div>
            );
          })}
        {btnState ? <Spinner /> : <></>}
      </div>
    </div>
  );
};

export default ScrapData;
