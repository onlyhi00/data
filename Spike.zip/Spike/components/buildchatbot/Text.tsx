import React, { useContext, useEffect, useState } from "react";
import { encode } from "gpt-tokenizer";
import toast from "react-hot-toast";
import { TextContext } from "@/ContextProvider/textContext";

type Props = {};

const Text = (props: Props) => {
  const { textContext, setTextContext } = useContext(TextContext);
  const [tokenNumber, setTokenNumber] = useState(0);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    let token_num = encode(e.target.value).length;
    setTokenNumber(token_num);
    if (token_num > 3000) {
      toast.error("The number of token is to much!");
      return;
    }
    let chunks = [
      {
        role: "user",
        content: `text: ${e.target.value.replace("text: ", "")}`,
      },
    ];
    if (textContext.name) {
      setTextContext({
        ...textContext,
        chunks,
      });
    } else {
      setTextContext({ name: "text", chunks });
    }
  };

  return (
    <div>
      <textarea
        rows={10}
        className="w-full resize-none border-[1px] border-gray-700 rounded-xl p-5"
        placeholder="write Text.."
        value={
          textContext.chunks
            ? textContext.chunks[0].content.replace("text: ", "")
            : ""
        }
        onChange={handleChange}
      />
      <p>The number of token: {tokenNumber}</p>
    </div>
  );
};

export default Text;
