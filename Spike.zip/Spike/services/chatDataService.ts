import cheerio from "cheerio";
import { create } from "zustand";
import { useFetch } from "helpers/client";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";

const initialState = {
  data: undefined,
  dataById: undefined,
};

const chatDataStore = create<ChatDataStore>(() => initialState);

export { chatDataService };

function chatDataService(): ChatDataService {
  const router = useRouter();
  const fetch = useFetch();
  const { data, dataById } = chatDataStore();
  return {
    data,
    dataById,
    create: async (data: any) => {
      try {
        const response = await fetch.post(`/api/data`, { ...data });
        chatDataStore.setState({ ...initialState, data: response });
        if (response) {
          router.push(`/chatapp/${response[0].id}`);
          toast.success("Success creating bot!");
        }
      } catch (error) {
        toast.error(JSON.stringify(error));
      }
    },
    getAll: async () => {
      const response = await fetch.get(`/api/data`);
      chatDataStore.setState({ data: response });
    },
    getById: async (id: string) => {
      const response = await fetch.get(`/api/data?id=${id}`);
      chatDataStore.setState({ ...initialState, dataById: response });
    },
    update: async (id: string, mode: string, data: DataType) => {
      try {
        const formData = new FormData();
        if (typeof data.interface.img === "object") {
          formData.append("img", data.interface.img);
        }
        if (typeof data.interface.chat_icon === "object") {
          formData.append("chat_icon", data.interface.chat_icon);
        }
        if (
          typeof data.interface.img === "object" ||
          typeof data.interface.chat_icon === "object"
        ) {
          const uploadResponse: UploadResponseType = await fetch.put(
            `/api/upload`,
            formData
          );
          for (const key in uploadResponse) {
            data.interface[key as "img" | "chat_icon"] = (
              uploadResponse[key as "img" | "chat_icon"] as string
            ).replace("public", "");
          }
        }
        const response = await fetch.put(`/api/data`, { id, mode, data });
        chatDataStore.setState({ ...initialState, dataById: response });

        toast.success("Success to update!");
      } catch (err: any) {
        console.error(err);
        toast.error(err);
      }
    },
    deleteById: async (id: string) => {
      try {
        const response = await fetch.delete(`/api/data?id=${id}`);
        // chatDataStore.setState({ ...initialState, dataById: response });
        return response;
      } catch (err) {
        return err;
      }
    },
  };
}

type ChunkProp = {
  role: string;
  content: string;
  _id: string;
};

type UploadResponseType = {
  img: string;
  chat_icon?: string;
};

export type DataType = {
  chunks: Array<ChunkProp>;
  createdAt: Date;
  name: string;
  updatedAt: Date;
  user: string;
  id: string;
  mode: string;
  prompt: string;
  temperature: number;
  interface: {
    bubble_color: string;
    bubble_position: string;
    chat_icon: string | File;
    img: string | File;
    remove_img: boolean;
    init_msg: string;
    msg_color: string;
    suggest_msg: string;
    theme: string;
    display_name: string;
    remove_chat_icon: boolean;
    init_msg_display_delay_time: number;
  };
  leads: {
    email: string | null;
    name: string | null;
    number: string | null;
    title: string;
  };
  notification: {
    leads: string[] | null;
    conversation: string[] | null;
  };
  security: {
    visibility: string;
    only_domain: string | null;
    rate_limit: string;
    limit_hit: string;
  };
};

interface ChatDataStore {
  data: Array<any> | undefined;
  dataById: DataType | undefined;
}

interface ChatDataService extends ChatDataStore {
  create: (data: { data: any }) => Promise<void>;
  getAll: () => Promise<void>;
  getById: (id: string) => Promise<void>;
  update: (id: string, mode: string, data: any) => Promise<void>;
  deleteById: (id: string) => Promise<any>;
}
