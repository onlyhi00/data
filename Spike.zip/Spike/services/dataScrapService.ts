import cheerio from "cheerio";
import { create } from "zustand";
import { useFetch } from "helpers/client";
import toast from "react-hot-toast";

const initialState = {
  data: undefined,
};
const dataScrapStore = create<IDataScrapStore>(() => initialState);

export { dataScrapService };

function dataScrapService(): IDataScrapService {
  const fetch = useFetch();
  const { data } = dataScrapStore();
  return {
    data,
    getSuburl: async (url: string) => {
      try {
        const response = await fetch.get(`/api/scrap?url=${url}`);
        dataScrapStore.setState({ data: response });
        if (response.length === 0) {
          toast.error("We can't detect suburl");
        } else {
          toast.success("Success scrapping data from url");
        }
      } catch (error: any) {
        toast.error(error.message);
      }
    },
    setData: async (param: Array<DataType>) => {
      dataScrapStore.setState({ data: param });
    },
  };
}

type DataType = {
  url: string;
  content: string;
};

interface IDataScrapStore {
  data?: Array<DataType>;
}

interface IDataScrapService extends IDataScrapStore {
  getSuburl: (url: string) => Promise<void>;
  setData: (param: Array<DataType>) => Promise<void>;
}
