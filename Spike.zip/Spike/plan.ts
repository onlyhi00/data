export const monthlyPlan = [
  {
    name: "monthly-Hobby",
    description: "Hobby Plan!",
    price: "$19/month",
    stripePriceId: "price_1OAGdjJ0Mr1kpgXBQQImElzh",
  },
  {
    name: "monthly-Standard",
    description: "Standard Plan!",
    price: "$99/month",
    stripePriceId: "price_1OAGfgJ0Mr1kpgXBh6E7s9CN",
  },
  {
    name: "monthly-Unlimited",
    description: "Unlimited Plan!",
    price: "$399/month",
    stripePriceId: "price_1OAGgGJ0Mr1kpgXBth4HNljS",
  },
];

export const yearlyPlan = [
  {
    name: "yearly-Hobby",
    description: "Hobby Plan!",
    price: "$190/year",
    stripePriceId: "price_1OAGhSJ0Mr1kpgXBODXSupEV",
  },
  {
    name: "yearly-Standard",
    description: "Standard Plan!",
    price: "$990/year",
    stripePriceId: "price_1OAGitJ0Mr1kpgXBBK9yZPu3",
  },
  {
    name: "yearly-Unlimited",
    description: "Unlimited Plan!",
    price: "$3990/year",
    stripePriceId: "price_1OAGjbJ0Mr1kpgXBe5UZNIBo",
  },
];
