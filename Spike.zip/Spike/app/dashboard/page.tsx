import { auth, clerkClient } from "@clerk/nextjs";
import { redirect } from "next/navigation";
import Spinner from "@/components/Spinner";

export default async function DashboardPage() {
  const { userId } = auth();
  if (!userId) {
    redirect("/");
  }
  const user = await clerkClient.users.getUser(userId);

  if (user) {
    return redirect("mychatbot");
  } else {
    return <Spinner />;
  }
}
