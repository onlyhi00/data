import Link from "next/link";

export default function Page() {
  return (
    <article className="mx-auto max-w-[80%] py-10">
      <h1 className="text-3xl text-center font-bold mb-4">
        Doc for chatbot: structure:
      </h1>
      <h3 className="text-xl mt-2 mb-1 font-medium">
        <b>Q:</b> What is chatlabz?
      </h3>
      <p>
        <b>A:</b> <b>Chatlabz</b> is an AI chatbot builder that allows you to
        create your own chatbot using your data. It utilizes ChatGPT to train
        the chatbot and provides options to add a chat widget to your website or
        interact with it through the API. With <b>Chatlabz</b>, you can upload
        documents or add a link to your website to create a chatbot that can
        answer questions about the content. It's a powerful tool for building
        interactive chatbots for your business!
      </p>
      <Link
        href={`mailto:support@chatlabz.com`}
        className="underline text-blue-700 hover:text-blue-800 mb-2"
      >
        Ask for Email
      </Link>

      <h3 className="text-xl mt-2 mb-1 font-medium">
        <b>Q:</b> How do I add data to my chatbot?
      </h3>
      <p>
        <b>A:</b> To add data to your chatbot, you have a few options. You can
        upload documents in formats such as .pdf, .txt, .doc, or .docx.
        Alternatively, you can paste text directly into the chatbot or provide a
        link to your website for <b>Chatlabz</b> to extract the data from it.
        Once the data is uploaded or extracted, <b>Chatlabz</b> will train
        ChatGPT on your data, enabling the chatbot to answer questions related
        to the content. You can access the data upload feature by clicking on
        "Manage Sources" in your chatbot menu. Give it a try!
      </p>
      <Link
        href={`mailto:support@chatlabz.com`}
        className="underline text-blue-700 hover:text-blue-800 mb-2"
      >
        Ask for Email
      </Link>

      <h3 className="text-xl mt-2 mb-1 font-medium">
        <b>Q:</b> Is there a free plan?
      </h3>
      <p>
        <b>A:</b> Absolutely! By signing up for <b>Chatlabz</b>, you
        automatically get a free plan. The free plan includes 30 message credits
        per month and allows you to test out <b>Chatlabz</b> and see if it meets
        your needs. However, please note that the free plan does not provide API
        access. If you require API access and additional features, you may
        consider upgrading to one of our paid plans.
      </p>
      <Link
        href={`mailto:support@chatlabz.com`}
        className="underline text-blue-700 hover:text-blue-800 mb-2"
      >
        Ask for Email
      </Link>
    </article>
  );
}
