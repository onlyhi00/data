export default function Page() {
  return <h1 className="text-center text-3xl my-10">Coming Soon!</h1>;
}
