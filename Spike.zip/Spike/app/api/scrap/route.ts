import { apiHandler } from "helpers/server/api";
import cheerio from "cheerio";
import axios from "axios";
import url from "url";

module.exports = apiHandler({
  GET: fetchData,
});

async function fetchData(req: Request) {
  const url = new URL(req.url!);
  const queryParams = new Map(url.searchParams.entries());
  const pageURL = queryParams.get("url") || "";

  const content = scrapeAllSubPages(pageURL).then((content) => {
    return content;
  });
  return content;
}

const fetchPage = async (pageUrl: string) => {
  const url = new URL(pageUrl);
  const hostname = url.hostname;
  try {
    const response = await axios.get(pageUrl, {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
        Host: hostname,
      },
    });
    return cheerio.load(response.data);
  } catch (err) {
    console.error(err);
    throw err;
  }
};

const extractPageLinks = (baseUrl: any, $: any) => {
  const links: any[] = [];
  $("a").each((i: any, link: any) => {
    const href = $(link).attr("href");
    if (href && !href.includes("javascript:")) {
      if (!href.includes("#") && !href.includes("https://")) {
        links.push(url.resolve(baseUrl, href));
      }
    }
  });
  const setLinks = new Set(links);
  return [...(setLinks as any)]; // Deduplicate links
};

const removeTags = async ($$: any, tags: string[]) => {
  tags.forEach((tag: string) => {
    $$(tag).remove();
  });
};

const scrapeAllSubPages = async (baseUrl: string) => {
  const $ = await fetchPage(baseUrl);
  const pageUrls = extractPageLinks(baseUrl, $);
  const tagsToRemove = ["script", "style", "iframe", "button", "br", "img"];
  const data: any[] = [];
  await Promise.all(
    pageUrls.map(async (pageUrl) => {
      try {
        const $$ = await fetchPage(pageUrl);
        await removeTags($$, tagsToRemove);
        data.push({
          url: pageUrl,
          content: $$("body").text().trim(),
        });
      } catch (err) {
        data.push({ url: pageUrl, content: "" });
      }
    })
  );
  return data;
};

// const mainUrl = 'http://example.com';
// scrapeAllSubPages(mainUrl).then(content => console.log(content));
