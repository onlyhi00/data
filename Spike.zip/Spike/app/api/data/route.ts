import { dataRepo } from "helpers/server";
import { apiHandler } from "helpers/server/api";

module.exports = apiHandler({
  GET: getData,
  POST: create,
  PUT: update,
  DELETE: deleteData,
});

// async function getAll() {
//   return await dataRepo.getAll();
// }

async function create(req: Request) {
  const body = await req.json();

  const data = await dataRepo.create(body.data);
  return data;
}

async function getAll() {
  return await dataRepo.getAll();
}

async function getById(id: string) {
  return await dataRepo.getById(id);
}

async function getData(req: Request) {
  const url = new URL(req.url!);
  const queryParams = new Map(url.searchParams.entries());
  const id = queryParams.get("id") || "";
  if (id) {
    return await getById(id);
  } else {
    return await getAll();
  }
}

async function update(req: Request) {
  const body = await req.json();
  return await dataRepo.update(body.id, body.mode, body.data);
}

async function deleteData(req: Request) {
  console.log(req.url);
  const url = new URL(req.url!);
  const queryParams = new Map(url.searchParams.entries());
  const id = queryParams.get("id") || "";
  return await dataRepo.deleteById(id);
}
