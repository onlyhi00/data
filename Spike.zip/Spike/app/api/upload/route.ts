import { dataRepo } from "helpers/server";
import { apiHandler } from "helpers/server/api";
import formidable from "formidable";
import fs from "fs";
import { isArrayBufferView } from "util/types";
import path from "path";
import { v4 as uuid } from "uuid";

module.exports = apiHandler({
  PUT: uploadImg,
});

async function uploadImg(req: Request) {
  try {
    const formData = await req.formData();
    let resData = {} as ResDataType;

    const formDataImg = formData.get("img") as FormDataEntryValue | null;
    const formDataChatIcon = formData.get(
      "chat_icon"
    ) as FormDataEntryValue | null;

    if (
      formDataImg &&
      typeof formDataImg === "object" &&
      "arrayBuffer" in formDataImg
    ) {
      resData.img = await writeImg(formDataImg);
    }
    if (
      formDataChatIcon &&
      typeof formDataChatIcon === "object" &&
      "arrayBuffer" in formDataChatIcon
    ) {
      resData.chat_icon = await writeImg(formDataChatIcon);
    }
    return resData;
  } catch (err) {
    console.error(err, "err");
  }
}

type ResDataType = {
  img?: string;
  chat_icon: string;
};

async function writeImg(formDataFile: object): Promise<string> {
  const folderPath = "public/img";
  if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath);
  }
  const file = formDataFile as Blob;
  const buffer = Buffer.from(await file.arrayBuffer());
  const filename = folderPath + "/" + uuid() + path.extname(file.name);
  fs.writeFileSync(filename, buffer);
  return filename as string;
}
