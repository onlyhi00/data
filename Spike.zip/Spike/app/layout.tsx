import { ClerkProvider, SignedIn, UserButton } from "@clerk/nextjs";
import "./globals.css";
import { Inter } from "next/font/google";
import Link from "next/link";
import Script from "next/script";
import { Metadata } from "next";
import Navbar from "@/components/Navbar";
import { Toaster } from "react-hot-toast";
import { PdfContextProvider } from "@/ContextProvider/pdfContext";
import { TextContextProvider } from "@/ContextProvider/textContext";
import { WebsiteContextProvider } from "@/ContextProvider/websiteContext";
import { QAContextProvider } from "@/ContextProvider/qaContext";
import { ChatContextProvider } from "@/ContextProvider/chatContext";
import icon from "@/assets/icon.png";
import { Logo } from "./icons";
import { ReactNode } from "react";
import Image from "next/image";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "ChatLabz",
  description:
    "A simple and powerful Next.js template featuring authentication and user management powered by Clerk.",
  openGraph: { images: ["/og.png"] },
};

const navItems = ["mychatbot", "api", "pricing"];

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body
        className={`${inter.className} min-h-screen flex flex-col`}
        suppressHydrationWarning={true}
      >
        <ClerkProvider
          appearance={{
            variables: { colorPrimary: "#000000" },
            elements: {
              formButtonPrimary:
                "bg-black border border-black border-solid hover:bg-white hover:text-black",
              socialButtonsBlockButton:
                "bg-white border-gray-200 hover:bg-transparent hover:border-black text-gray-600 hover:text-black",
              socialButtonsBlockButtonText: "font-semibold",
              formButtonReset:
                "bg-white border border-solid border-gray-200 hover:bg-transparent hover:border-black text-gray-500 hover:text-black",
              membersPageInviteButton:
                "bg-black border border-black border-solid hover:bg-white hover:text-black",
              card: "bg-[#fafafa]",
            },
          }}
        >
          <header className="flex items-center h-20 gap-4 px-4 border-b border-black border-solid sm:px-8 border-opacity-20">
            <Link href="/" className="">
              <Image
                src={Logo.default}
                alt="logo"
                className="w-64 ml-0 md:ml-8"
              />
            </Link>
            <Navbar />
            <SignedIn>
              <UserButton afterSignOutUrl="/" />
            </SignedIn>
          </header>
          <PdfContextProvider>
            <TextContextProvider>
              <WebsiteContextProvider>
                <QAContextProvider>
                  <ChatContextProvider>
                    <main className="grow">{children}</main>
                    <Toaster position="top-center" reverseOrder={false} />
                  </ChatContextProvider>
                </QAContextProvider>
              </WebsiteContextProvider>
            </TextContextProvider>
          </PdfContextProvider>
          <footer className="flex items-center justify-between h-20 gap-1 px-8 font-medium border-t md:px-20 bg-white">
            <div>
              ChatLabz <span className="text-sm">© 2023</span>
            </div>
            <div>
              <Link
                href={`/docs`}
                className="underline mr-3 hover:text-blue-900"
              >
                Documentation
              </Link>
              <Link
                href={`/terms`}
                className="underline mr-3 hover:text-blue-900"
              >
                Terms of Service
              </Link>
              <Link href={`/privacy`} className="underline hover:text-blue-900">
                Privacy Policy
              </Link>
            </div>
          </footer>
        </ClerkProvider>
      </body>

      <Script src="https://cdn.jsdelivr.net/npm/prismjs@1/components/prism-core.min.js" />
      <Script src="https://cdn.jsdelivr.net/npm/prismjs@1/plugins/autoloader/prism-autoloader.min.js" />
    </html>
  );
}
