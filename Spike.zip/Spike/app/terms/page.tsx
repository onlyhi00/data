import Link from "next/link";

export default function Page() {
  return (
    <article className="mx-auto max-w-[80%] py-10">
      <h1 className="text-3xl text-center font-bold mb-4">Terms of Service</h1>
      <p className="text-right">Last updated: March 2, 2023</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">1. Preamble</h3>
      <p>
        These Service Terms (“Terms”) outline the guidelines for using our
        Service and establish the legal bond between the user of the Service and{" "}
        <b>Chatlabz</b>. By accessing{" "}
        <Link
          href={`/`}
          className="underline text-blue-700 hover:text-blue-800"
        >
          chatlabz.com (“Website”)
        </Link>{" "}
        and utilizing our Service, users affirm that they have perused,
        comprehended, and consented to these Terms and our Privacy Policy. If
        any disagreement arises with these stipulations, users are advised not
        to use our Service. For concerns, reach out to{" "}
        <Link
          href={`mailto:support@chatlabz.com`}
          className="underline text-blue-700 hover:text-blue-800"
        >
          support@chatlabz.com
        </Link>
        .
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">2. Terminology</h3>
      <p>The terms below have the following interpretations:</p>
      <ul className="list-disc list-inside ml-5">
        <li>Profile – The user's dashboard for accessing the Service.</li>
        <li>
          Contract – The service agreement between the user and <b>Chatlabz</b>.
        </li>
        <li>
          API – <b>Chatlabz</b>'s interface for software integration.
        </li>
        <li>
          <b>Chatlabz</b> – Refers to{" "}
          <Link
            href={`/`}
            className="underline text-blue-700 hover:text-blue-800"
          >
            chatlabz.com
          </Link>
          .
        </li>
        <li>
          Material – All content, including text and images, shared by users.
        </li>
        <li>
          Equipment– Devices like PCs, phones, or tablets used to access the
          Website.
        </li>
        <li>Visitor – Anyone browsing the Website.</li>
        <li>
          Proprietary Rights – Exclusive rights held by <b>Chatlabz</b>.
        </li>
        <li>License – Permission to use the API or other tools.</li>
        <li>
          External Sites – Websites other than <b>Chatlabz</b>.
        </li>
        <li>Security Code – A unique code for user authentication.</li>
        <li>
          Privacy Guidelines– Rules for data handling, available at{" "}
          <Link
            href={`/privacy`}
            className="underline text-blue-700 hover:text-blue-800"
          >
            chatlabz.com/privacy
          </Link>
          .
        </li>
        <li>
          Service – All offerings by <b>Chatlabz</b>, including the Website and
          API.
        </li>
        <li>User – Registered members with a Profile.</li>
        <li>
          Tool– A feature or widget from <b>Chatlabz</b> for user websites.
        </li>
      </ul>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        3. General Provisions{" "}
      </h3>
      <p>
        Acceptance of these Terms is mandatory for using our Service. The Terms
        solely govern the relationship between <b>Chatlabz</b> and its users or
        visitors. Any third-party services will have their own terms. Users must
        ensure their devices meet the technical requirements for our Service.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        4. Profile Creation{" "}
      </h3>
      <p>
        Users can create a Profile via the Website using social media logins or
        by registering with an email. It's crucial to provide accurate details.
        Users are responsible for their Profile's security.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">5. Communication </h3>
      Upon Profile creation, users may opt to receive newsletters and
      promotional content.
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        6. Promotional Activities
      </h3>
      Any promotions available through <b>Chatlabz</b> may have distinct rules,
      separate from these Terms.
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        7. Subscription Details
      </h3>
      <p>
        Certain features are available on a subscription basis. Billing details
        and terms are specified during the subscription process.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        8. Pricing Adjustments{" "}
      </h3>
      <p>
        <b>Chatlabz</b> reserves the right to modify subscription prices. Users
        will be informed of any changes.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">9. Refund Policy </h3>
      Unless mandated by Estonian law, subscription fees are non-refundable.
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">10. User Content </h3>
      <p>
        Users can share content via our Service. They are responsible for the
        legality and appropriateness of their content.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        11. Unacceptable Usage{" "}
      </h3>
      <p>
        Users must not misuse our Service or engage in any illegal activities.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        12. Usage Analytics
      </h3>
      <p>
        Third-party tools, like Google Analytics and Mixpanel, may be used to
        analyze Service usage.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        13. Proprietary Rights{" "}
      </h3>
      <p>
        All original content and features of the Service remain the property of{" "}
        <b>Chatlabz</b>.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        14. Copyright Considerations{" "}
      </h3>
      <p>
        <b>Chatlabz</b> respects intellectual property rights and expects users
        to do the same.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        15. DMCA Procedures
      </h3>
      <p>
        For copyright concerns, users can reach out to{" "}
        <Link
          href={`mailto:support@chatlabz.com`}
          className="underline text-blue-700 hover:text-blue-800"
        >
          support@chatlabz.com
        </Link>
        .
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        16. Feedback and Error Reporting
      </h3>
      <p>
        Users can share feedback and report issues to{" "}
        <Link
          href={`mailto:support@chatlabz.com`}
          className="underline text-blue-700 hover:text-blue-800"
        >
          support@chatlabz.com
        </Link>
        .
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">17. External Links</h3>
      <p>
        <b>Chatlabz</b> may have links to other sites. We are not responsible
        for the content or policies of these sites.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        18. Warranty Disclaimer{" "}
      </h3>
      <p>Our Service is provided "as is" without any warranties.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        19. Liability Limitations{" "}
      </h3>
      <p>
        <b>Chatlabz</b>'s liability is limited as described in this section.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        20. User Responsibilities
      </h3>
      <p>Users are accountable for their actions on the Service.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        21. Service Interruptions{" "}
      </h3>
      <p>There may be occasional downtimes or interruptions in our Service.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        22. Data Protection{" "}
      </h3>
      <p>
        <b>Chatlabz</b> prioritizes user data protection. Details are in our
        Privacy Guidelines.
      </p>
    </article>
  );
}
