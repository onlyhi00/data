import Link from "next/link";

export default function Page() {
  return (
    <article className="mx-auto max-w-[80%] py-10">
      <h1 className="text-3xl text-center font-bold mb-4">
        Privacy Policy <b>chatlabz</b>
      </h1>
      <p className="text-right">Last modified: [Your Date]</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">1. Introduction</h3>
      <p>
        Before utilizing our Service, including the Website, Widget, and API,
        please familiarize yourself with this Privacy Policy (“Privacy Policy”).
        This policy outlines the nature of the information we gather and our
        practices regarding its use and sharing. By accessing and using the
        Service, you consent to our Terms of Service available at [Your Terms of
        Service Link] (“Terms of Service”), which encompasses the Privacy Policy
        detailed here. <b>chatlabz</b> (“Company”) manages the Service. We
        utilize your data to enhance and offer the Service. By employing the
        Service, you consent to the gathering and use of information in line
        with this policy. Terms in this Privacy Policy have the same definitions
        as in our Terms of Service unless otherwise specified.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">2. Definitions</h3>
      <p>
        API refers to the <b>chatlabz</b> application programming interface
        integrated with the User’s software.
      </p>
      <p>Cookies are tiny files stored on your Device.</p>
      <p>Device denotes a computer or mobile device.</p>
      <p>
        Data Controller is an entity that determines the purposes and means of
        processing personal data. In the context of this Privacy Policy, we act
        as the Data Controller for your data.
      </p>
      <p>
        Data Processors are entities processing data on behalf of the Data
        Controller. We might employ various Service Providers to process your
        data more efficiently.
      </p>
      <p>Data Subject is an individual whose personal data is processed.</p>
      <p>
        Personal Data pertains to information about an individual that can be
        identified from that data.
      </p>
      <p>Service encompasses the Website, Widget, and/or the API.</p>
      <p>Usage Data is data collected automatically from using the Service</p>
      <p>
        User refers to the individual using our Service. The User corresponds to
        the Data Subject
      </p>
      <p>
        Website refers to web pages located at <b>chatlabz.com</b> (or your
        domain).
      </p>
      <p>
        Widget is a <b>chatlabz</b> widget that can be added to the User’s
        website.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        3. The Data Controller
      </h3>
      <p>
        Your Personal Data is controlled by: <b>chatlabz</b>.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        4. Information Collection and Use
      </h3>
      <p>
        We gather various types of information for different purposes to enhance
        and offer our Service.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        5. Types of Data Collected
      </h3>
      <h4 className="ml-1 font-semibold">Personal Data</h4>
      <p>
        While using our Service, we might request you to provide personally
        identifiable information, including:
      </p>
      <ul className="list-disc ml-10">
        <li>Email address,</li> <li>First name and last name,</li>
        <li>Cookies and Usage Data.</li>
      </ul>
      <h4 className="ml-1 font-semibold">Usage Data</h4>
      <p>
        We might also collect data sent by your browser when you access our
        Service. This can include your IP address, browser type and version, the
        pages you visit on our Service, the time and date of your visit, time
        spent on those pages, and other diagnostic data.
      </p>
      <h4 className="ml-1 font-semibold">Tracking Cookies Data</h4>
      <p>
        We employ cookies and similar tracking technologies to monitor activity
        on our Service. You can instruct your browser to refuse cookies.
        However, refusing cookies might make some parts of our Service
        inaccessible.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">6. Use of Data</h3>
      <p>
        <b>chatlabz</b> uses the collected data for:
      </p>
      <ul className="list-disc ml-10">
        <li> Providing and maintaining the Service,</li>
        <li> Notifying you about changes to our Service,</li>
        <li> Allowing interactive features of our Service,</li>
        <li> Providing customer support,</li>
        <li>Gathering analysis to improve our Service,</li>
        <li> Monitoring Service usage,</li>
        <li>Detecting and addressing technical issues.</li>
      </ul>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        7. Retention of Data
      </h3>
      <p>
        We retain your Personal Data as long as necessary for the purposes
        outlined in this Privacy Policy. We also retain Usage Data for internal
        analysis.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        8. Transfer of Data
      </h3>
      <p>
        Your data might be transferred and maintained on computers outside your
        jurisdiction where data protection laws might differ. If you're outside
        the United States and provide information to us, note that we transfer
        the data, including Personal Data, to the United States for processing.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        9. Disclosure of Data
      </h3>
      <p>
        We might disclose your Personal Data under certain circumstances, such
        as in compliance with legal obligations or during mergers and
        acquisitions.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        10. Security of Data
      </h3>
      <p>
        We prioritize the security of your data. However, no electronic storage
        method or data transmission over the Internet is entirely secure.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        11. Your Data Protection Rights
      </h3>
      <p>
        If you are a resident of the European Union (EU) and European Economic
        Area (EEA), you have certain data protection rights under the GDPR.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        12. Your Data Protection Rights under CalOPPA
      </h3>
      <p>CalOPPA mandates commercial websites to post a privacy policy.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        13. Service Providers
      </h3>
      <p>We might employ third-party companies to facilitate our Service.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">14. Analytics</h3>
      <p>
        We might use third-party Service Providers for analytics, such as Google
        Analytics and Mixpanel.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">15. Payments</h3>
      <p>
        For paid products/services within our Service, we use third-party
        payment processors like Stripe.
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        16. Links to Other Sites
      </h3>
      <p>Our Service might contain links to other sites not operated by us.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        17. Children's Privacy
      </h3>
      <p>Our Service isn't intended for anyone under 16.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        18. Changes to This Privacy Policy
      </h3>
      <p>We might update our Privacy Policy periodically.</p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">19. Contact Us</h3>
      <p>
        For queries about this Privacy Policy, reach out to us at{" "}
        <Link
          href={`mailto:support@chatlabz.com`}
          className="underline text-blue-700 hover:text-blue-800"
        >
          support@chatlabz.com
        </Link>
        .
      </p>
      <h3 className="text-xl mt-2 mb-1 ml-2 font-medium">
        20. Privacy Policy Addendum
      </h3>
      <p>Addendum for Canada, Mexico, Japan, Republic of Korea</p>
    </article>
  );
}
