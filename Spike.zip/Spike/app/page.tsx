"use client";
import { RightArrow } from "./icons";
import "./home.css";
import { useRouter } from "next/navigation";

export default function Home() {
  const router = useRouter();
  return (
    <main className="">
      <article className="grid lg:grid-cols-2">
        <div className="px-8 py-20 md:px-20 lg:py-48">
          <h1 className="text-5xl font-semibold text-transparent md:text-6xl gradient">
            Build Chatbot here
          </h1>
          <p className="mt-2 text-lg">
            Just connect your data sources and get a ChatGPT-like chatbot for
            your data. Then add it as a widget to your website or chat with it
            through our integrations or API.
          </p>
          <div className="flex gap-2 mt-8">
            <button
              className="flex content-center gap-2 px-4 py-2 font-semibold text-white transition-colors duration-200 rounded-lg bg-primary-600 hover:bg-primary-700"
              onClick={() => router.push("/dashboard")}
            >
              Build Your Chatbot
              <div className="m-auto">
                <RightArrow />
              </div>
            </button>
            {/* <a
              className="flex gap-2 px-4 py-2 font-semibold text-gray-600 transition duration-100 rounded-lg hover:text-gray-800"
              href="#features"
            >
              Learn more
              <div className="m-auto">
                <DownArrow />
              </div>
            </a> */}
          </div>
        </div>
      </article>
      <article className="px-8 py-12  md:px-20 md:py-24" id="qas">
        <h1 className="text-center text-3xl font-semibold">
          Frequently asked questions
        </h1>

        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown"
          >
            <div className="dropdown__text">What exactly is Chatlabz?</div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            Chatlabz is a platform that enables you to craft AI-driven chatbots
            using ChatGPT. By simply uploading a document or linking your
            website, you can have a chatbot ready to answer queries based on the
            provided content.
          </p>
        </div>

        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown1" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown1"
          >
            <div className="dropdown__text">
              How should I prepare my data for Chatlabz?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            You have the flexibility to either upload files (formats like .pdf,
            .txt, .doc, .docx are supported), directly paste your text, or
            simply provide a link to your website which will be scraped for
            content.
          </p>
        </div>

        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown2" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown2"
          >
            <div className="dropdown__text">
              Is it possible to guide my chatbots on how they should respond?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            Absolutely! You can customize the initial prompt, name your chatbot,
            define its personality, and even instruct it on specific ways to
            respond, such as answering exclusively in Spanish.
          </p>
        </div>

        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown3" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown3"
          >
            <div className="dropdown__text">
              Where does Chatlabz keep my data?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            Rest assured, your document's content is securely stored on GCP/AWS
            servers located in the us-east region.
          </p>
        </div>
        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown4" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown4"
          >
            <div className="dropdown__text">
              Which version of GPT does Chatlabz utilize?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            By default, chatbots on Chatlabz are powered by gpt-3.5-turbo.
            However, if you're on the Standard or Unlimited plans, you can opt
            for gpt-4.
          </p>
        </div>
        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown5" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown5"
          >
            <div className="dropdown__text">
              What's the process to integrate my chatbot on my site?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            It's quite simple! You can either embed it using an iframe or
            position a chat bubble on the bottom right corner of your site.
            After creating your chatbot, just hit "Embed on website".
            Additionally, there's an API available for more diverse
            integrations.
          </p>
        </div>
        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown6" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown6"
          >
            <div className="dropdown__text">
              Does Chatlabz cater to multiple languages?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            Indeed, Chatlabz boasts support for an impressive 95 languages. This
            means you can provide content in any language and the chatbot will
            be equipped to answer queries in multiple languages.
          </p>
        </div>
        <div className="dropdown my-4">
          <input type="checkbox" id="dropdown7" />

          <label
            className="dropdown__face  border rounded-t-3xl border-gray-100"
            htmlFor="dropdown7"
          >
            <div className="dropdown__text">
              Can I share the chatbot I've designed with others?
            </div>

            <div className="dropdown__arrow"></div>
          </label>

          <p className="dropdown__items border-2 border-t-0 border-gray-100 rounded-b-3xl">
            Of course! While every chatbot you design is set to private by
            default, you have the freedom to make it public and share the link
            with anyone you wish.
          </p>
        </div>

        <svg>
          <filter id="goo">
            <feGaussianBlur
              in="SourceGraphic"
              stdDeviation="10"
              result="blur"
            />
            <feColorMatrix
              in="blur"
              type="matrix"
              values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7"
              result="goo"
            />
            <feBlend in="SourceGraphic" in2="goo" />
          </filter>
        </svg>
      </article>
    </main>
  );
}
