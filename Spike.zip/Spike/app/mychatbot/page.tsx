"use client";
import React, { useEffect, useState } from "react";
import { chatDataService } from "services/chatDataService";
import ChatIcon from "assets/2950714.png";
import Spinner from "components/Spinner";
import { useRouter } from "next/navigation";

type Props = {};

const MyChatbot = (props: Props) => {
  const router = useRouter();
  const dataService = chatDataService();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    dataService.getAll();
  }, []);

  const handleBuild = (url: string) => {
    router.push(`/chatapp/${url}`);
  };

  return dataService.data ? (
    <main className="">
      <div className="flex justify-around w-full items-end my-5">
        <h1 className="text-5xl font-sans font-bold">
          My Chatbot{" "}
          <span className="text-xl">({dataService.data.length} items)</span>
        </h1>
        <button
          onClick={() => router.push("/create-chat-bot")}
          className="btn bg-zinc-700 hover:bg-zinc-600 text-zinc-200 px-4 py-2 rounded-md font-semibold"
        >
          Build Your Chatbot
        </button>
      </div>
      <div className="flex gap-4 flex-wrap px-0 md:px-28">
        {dataService.data.map((item, index) => {
          return (
            <button
              key={index}
              className="flex flex-col border-[1px] rounded-md max-w-[150px] p-5 divide-y-2 divide-dashed divide-slate-500 hover:bg-slate-200"
              onClick={() => {
                handleBuild(item.id);
              }}
            >
              <img src={ChatIcon.src} />
              <span className="w-full text-xs py-1 ">{item.name}</span>
            </button>
          );
        })}
      </div>
      <div id="demo"></div>
    </main>
  ) : (
    <Spinner />
  );
};

export default MyChatbot;
