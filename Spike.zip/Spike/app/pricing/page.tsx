"use client";
import { useState } from "react";
import { CheckIcon } from "../icons";
import PriceDot from "../icons/PriceDot";
import { SignedIn, SignedOut } from "@clerk/clerk-react";
import Link from "next/link";

export default function Page() {
  const [billingState, setBillingState] = useState(true);

  const pricingData = [
    {
      name: "Free",
      data: [
        "20 message credits/month",
        "1 chatbot",
        "400,000 characters/chatbot",
        "Limit to 10 links to train on",
        "Embed on unlimited websites",
        "Upload multiple files",
        "View conversation history",
        "Chatbots get deleted after 7 days of inactivity",
      ],
      monthly: 0,
      yearly: 0,
    },
    {
      name: "Hobby",
      data: [
        "2,000 message credits/month",
        "2 chatbots",
        "11,000,000 characters/chatbot",
        "Unlimited links to train on",
        "Embed on unlimited websites",
        "Upload multiple files",
        "View conversation history",
        "Capture leads",
        "API access",
        "Zapier integration",
        "Slack integration",
        "Wordpress integration",
        "WhatsApp integration",
        "Messenger integration (coming soon)",
      ],
      monthly: 19,
      yearly: 190,
    },
    {
      name: "Standard",
      data: [
        "10,000 message credits/month",
        "5 chatbots",
        "11,000,000 characters/chatbot",
        "Unlimited links to train on",
        "Embed on unlimited websites",
        "Upload multiple files",
        "View conversation history",
        "Capture leads",
        "API access",
        "Zapier integration",
        "Slack integration",
        "Wordpress integration",
        "WhatsApp integration",
        "Messenger integration (coming soon)",
        "Option to Choose GPT-4",
      ],
      monthly: 99,
      yearly: 990,
    },
    {
      name: "Unlimited",
      data: [
        "40,000 message credits/month included (Messages over the limit will use your OpenAI API Key)",
        "10 chatbots",
        "11,000,000 characters/chatbot",
        "Unlimited links to train on",
        "Embed on unlimited websites",
        "Upload multiple files",
        "View conversation history",
        "Capture leads",
        "API access",
        "Zapier integration",
        "Slack integration",
        "Wordpress integration",
        "WhatsApp integration",
        "Messenger integration (coming soon)",
        "Option to Choose GPT-4",
        "Remove 'Powered by Chatbase'",
        "Use your own custom domains",
      ],
      monthly: 399,
      yearly: 3990,
    },
  ];

  return (
    <section className="py-16 sm:py-24">
      <div className=" px-8 sm:px-24 ">
        <div className="sm:flex sm:flex-col sm:align-center">
          <h1 className="text-4xl font-extrabold text-black sm:text-center sm:text-6xl">
            Pricing Plans
          </h1>
          <p className="mt-6 text-center">
            Get 2 months for free by subscribing yearly!
          </p>
          <div className="relative self-center mt-2 bg-zinc-100 rounded-lg px-10 py-5  flex gap-20 sm:mt-4 border border-zinc-200 ">
            <input
              type="radio"
              id="monthly"
              name="tab"
              className="hidden"
              checked={billingState}
              onChange={() => setBillingState((value) => !value)}
            />
            <label
              htmlFor="monthly"
              className={`z-[1] cursor-pointer font-bold duration-300 ${
                billingState ? "text-white" : "text-black"
              }`}
            >
              Monthly billing
            </label>
            <input
              type="radio"
              id="yearly"
              name="tab"
              className="hidden"
              checked={!billingState}
              onChange={() => setBillingState((value) => !value)}
            />
            <label
              htmlFor="yearly"
              className={`z-[1] cursor-pointer font-bold duration-300 ${
                !billingState ? "text-white" : "text-black"
              }`}
            >
              Yearly billing
            </label>
            <div className="marker bg-stone-400 z-0 rounded-lg"></div>
          </div>
        </div>
        <div className="mt-12 space-y-4 sm:mt-16 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-6 lg:max-w-4xl lg:mx-auto xl:max-w-none xl:mx-0 xl:grid-cols-4">
          {pricingData.map((item, index) => {
            return (
              <div
                className="rounded-lg shadow-sm divide-y divide-zinc-400 bg-zinc-100 "
                key={index}
              >
                <div className="p-4 flex flex-col justify-between h-full">
                  <div>
                    <h2 className="text-2xl leading-6 font-semibold text-black">
                      {item.name}
                    </h2>
                    <div className="py-4">
                      {item.data.map((listItem, i) => {
                        return (
                          <li className="flex space-x-2 mb-3" key={i}>
                            {item.name === "Free" ? (
                              <PriceDot className="h-2 w-2 flex-shrink-0" />
                            ) : (
                              <CheckIcon className="h-5 w-5 flex-shrink-0 text-green-500" />
                            )}
                            <span className="text-sm font-semibold text-zinc-700">
                              {listItem}
                            </span>
                          </li>
                        );
                      })}
                    </div>
                  </div>
                  <div>
                    <p className="mt-8">
                      <span className="text-3xl font-bold white duration-300 ease-in-out">
                        ${billingState ? item.monthly : item.yearly}
                      </span>
                      {item.name !== "Free" && (
                        <span className="text-base font-medium text-zinc-900 duration-300 ease-in-out">
                          /{billingState ? "month" : "year"}
                        </span>
                      )}
                    </p>
                    <SignedIn>
                      <button
                        className=" block w-full rounded-md py-2 text-sm font-semibold text-white text-center hover:bg-zinc-900 my-2 bg-zinc-800"
                        type="button"
                      >
                        Subscribe
                      </button>
                    </SignedIn>
                    <SignedOut>
                      <Link
                        className=" block w-full rounded-md py-2 text-sm font-semibold text-white text-center hover:bg-zinc-900 my-2 bg-zinc-800"
                        href={"/dashboard"}
                      >
                        Get Started
                      </Link>
                    </SignedOut>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
