"use client";
import { chatDataService } from "@/services/chatDataService";
import { useState } from "react";

export default function Page() {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  const [formData, setFormData] = useState(chatData);

  const handleSave = () => {
    chatService.update(chatData?.id as string, "model", {
      ...formData,
    });
  };
  return (
    <div className="col-span-12 sm:col-span-8 lg:col-span-10 h-full">
      <div className="border border-gray-200 rounded mb-10">
        <div className="border-b border-gray-200 bg-white py-4 px-5">
          <h3 className="text-xl font-semibold leading-6 text-gray-900 ">
            Model
          </h3>
        </div>
        <div className="p-5 overflow-auto h-[calc(100%-6.813rem)]">
          <div className="pb-8">
            <div className="flex justify-between">
              <label className="block text-sm font-medium text-gray-700">
                Base Prompt (system message)
              </label>
              <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                Reset
              </button>
            </div>
            <div className="mt-1">
              <textarea
                name="intructions"
                rows={5}
                className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                maxLength={5000}
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      prompt: e.target.value as string,
                    });
                  }
                }}
                value={formData?.prompt}
              />
            </div>
            <p className="mt-2 text-sm text-zinc-500">
              The base prompt allows you to customize your chatbot's personality
              and style. Please make sure to experiment with the base prompt by
              making it very specific to your data and use case.
            </p>
          </div>
          <div className="pb-8">
            <label className="block text-sm font-medium text-gray-700">
              Model
            </label>
            <select
              id="model"
              name="model"
              className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
              value={formData?.mode}
              onChange={(e) => {
                if (formData) {
                  setFormData({ ...formData, mode: e.target.value as string });
                }
              }}
            >
              <option value="gpt-3.5-turbo">gpt-3.5-turbo</option>
              <option value="gpt-4">gpt-4</option>
            </select>
            <p className="mt-2 text-sm text-zinc-500">
              gpt-4 is much better at following the base prompt and not
              hallucinating, but it's slower and more expensive than
              gpt-3.5-turbo (1 message using gpt-3.5-turbo costs 1 message
              credit. 1 message using gpt-4 costs 20 message credits)
            </p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Temperature
            </label>
            <p className="text-sm">{formData?.temperature}</p>
            <input
              id="steps-range"
              type="range"
              min={0}
              max={1}
              step={0.1}
              className="w-full h-2 bg-gray-200 rounded-lg accent-violet-700 appearance-none cursor-pointer duration-100 ease-in-out "
              value={formData?.temperature}
              onChange={(e) => {
                if (formData) {
                  setFormData({
                    ...formData,
                    temperature: parseFloat(e.target.value) as number,
                  });
                }
              }}
            />
            <div className="flex justify-between">
              <p className="text-zinc-700 text-xs">Reserved</p>
              <p className="text-zinc-700 text-xs">Creative</p>
            </div>
          </div>
        </div>
        <div className="flex justify-end bg-gray-100 px-5 py-3">
          <button
            data-variant="flat"
            className="inline-flex items-center justify-center transform-none normal-case rounded leading-6 transition ease-in-out duration-150 shadow-sm font-semibold text-center border focus:outline-none focus:ring-2 focus:ring-opacity-50 bg-zinc-700 text-zinc-200 border-zinc-600  hover:text-zinc-200 hover:border-zinc-600 hover:bg-zinc-700 h-7 w-16"
            onClick={handleSave}
          >
            Save
          </button>
        </div>
      </div>
      <div
        aria-live="assertive"
        className="pointer-events-none fixed inset-0 flex items-end px-4 z-20 py-6 sm:items-start sm:p-6"
      >
        <div className="flex w-full flex-col items-center space-y-4 sm:items-end"></div>
      </div>
    </div>
  );
}
