"use client";

import { chatDataService } from "@/services/chatDataService";
import { useRef, useState } from "react";
import ColorPicker from "./ColorPicker";
import { Refresh, Exit } from "@/app/icons";

export default function Page() {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  const [formData, setFormData] = useState(chatData);
  const [profileImg, setProfileImg] = useState(formData?.interface.img);
  const [chatImg, setChatImg] = useState(formData?.interface.chat_icon);

  const handleSave = () => {
    chatService.update(chatData?.id as string, "model", {
      ...formData,
    });
  };

  const getTextColor = (color: string) => {
    const hex = color.replace("#", "");
    const r = parseInt(hex.substring(0, 2), 16);
    const g = parseInt(hex.substring(2, 4), 16);
    const b = parseInt(hex.substring(4, 6), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 128 ? "#000" : "#fff"; // Return black or white based on brightness
  };

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const i = e.target.files?.[0];
    if (formData && i) {
      setProfileImg(URL.createObjectURL(i));

      setFormData({
        ...formData,
        interface: { ...formData?.interface, img: i },
      });
    }
  };

  const handleChatImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const i = e.target.files?.[0];
    if (formData && i) {
      setChatImg(URL.createObjectURL(i));
      setFormData({
        ...formData,
        interface: { ...formData?.interface, chat_icon: i },
      });
    }
  };

  return (
    <div className="border border-gray-200 rounded-md mb-10 h-full">
      <div className="border-b border-gray-200 bg-white py-4 px-5 rounded-t-md">
        <h3 className="text-xl font-semibold leading-6 text-gray-900 ">
          Chat Interface
        </h3>
      </div>
      <div className="p-5 overflow-auto h-[calc(100%-6.813rem)]">
        <h4 className="mb-8 text-sm text-zinc-600">
          Note: Applies when embedded on a website
        </h4>
        <div className=" flex justify-between lg:space-x-8 flex-col lg:flex-row">
          <div className="flex-1 w-2/2 lg:w-1/2 pb-5">
            <div className="pb-8">
              <div className="flex justify-between">
                <label className="block text-sm font-medium text-gray-700">
                  Initial Messages
                </label>
                <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                  Reset
                </button>
              </div>
              <div className="mt-1">
                <textarea
                  name="initial_messages"
                  // placeholder="Hi! What can I help you with?"
                  className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                  maxLength={1000}
                  onChange={(e) => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        interface: {
                          ...formData.interface,
                          init_msg: e.target.value as string,
                        },
                      });
                    }
                  }}
                  value={formData?.interface.init_msg}
                />
                <p className="mt-2 text-sm text-zinc-500">
                  Enter each message in a new line.
                </p>
              </div>
            </div>
            <div className="pb-8">
              <label className="block text-sm font-medium text-gray-700">
                Suggested Messages
              </label>
              <div className="mt-1">
                <textarea
                  name="suggested_messages"
                  placeholder="What is example.com?"
                  className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                  onChange={(e) => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        interface: {
                          ...formData.interface,
                          suggest_msg: e.target.value as string,
                        },
                      });
                    }
                  }}
                  value={formData?.interface.suggest_msg}
                />
                <p className="mt-2 text-sm text-zinc-500">
                  Enter each message in a new line.
                </p>
              </div>
            </div>
            <div className="pb-8">
              <label className="block text-sm font-medium text-gray-700">
                Theme
              </label>
              <select
                id="theme"
                name="theme"
                className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      interface: {
                        ...formData.interface,
                        theme: e.target.value as string,
                      },
                    });
                  }
                }}
                value={formData?.interface.theme}
              >
                <option value="light">light</option>
                <option value="dark">dark</option>
              </select>
            </div>
            {!formData?.interface.remove_img && (
              <div className="pb-8">
                <label className="block text-sm font-medium text-gray-700">
                  Update chatbot profile picture
                </label>
                <input
                  id="bot_profile_picture"
                  type="file"
                  accept="image/*"
                  name="bot_profile_picture"
                  className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                  onChange={handleImage}
                />
                <label className="block text-sm font-medium text-red-700"></label>
              </div>
            )}
            <div className="pb-8 inline-flex gap-2">
              <input
                type="checkbox"
                id="should_remove_bot_profile_picture"
                name="should_remove_bot_profile_picture"
                className="h-4 w-4 rounded border-gray-300 text-violet-600 focus:ring-violet-600"
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      interface: {
                        ...formData?.interface,
                        remove_img: e.target.checked,
                      },
                    });
                  }
                }}
                checked={formData?.interface.remove_img}
              />
              <label
                className="block text-sm font-medium text-gray-700"
                htmlFor={"should_remove_bot_profile_picture"}
              >
                Remove Chatbot Profile Picture
              </label>
            </div>
            <div className="pb-8">
              <label className="block text-sm font-medium text-gray-700">
                Display name
              </label>
              <div className="mt-1">
                <input
                  type="text"
                  name="name"
                  className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                  onChange={(e) => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        interface: {
                          ...formData.interface,
                          display_name: e.target.value as string,
                        },
                      });
                    }
                  }}
                  value={formData?.interface.display_name}
                />
              </div>
            </div>
            <div className="pb-8">
              <div className="flex justify-between">
                <label className="block text-sm font-medium text-gray-700">
                  User Message Color
                </label>
                <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                  Reset
                </button>
              </div>
              <div className="">
                <ColorPicker
                  color={formData?.interface.msg_color}
                  setColor={(msg_color) => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        interface: { ...formData.interface, msg_color },
                      });
                    }
                  }}
                />
              </div>
            </div>
            <p className="text-sm text-zinc-900 pb-10">
              **If the changes here don't show up immediately on your website
              try clearing your browser cache or use incognito. (New users will
              see the changes immediately)**
            </p>
            {!formData?.interface.remove_chat_icon && (
              <div className="pb-8">
                <label className="block text-sm font-medium text-gray-700">
                  Update chat icon
                </label>
                <input
                  id="chat_icon"
                  type="file"
                  accept="image/*"
                  name="bot_profile_picture"
                  className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                  onChange={handleChatImage}
                />
                <label className="block text-sm font-medium text-red-700"></label>
              </div>
            )}
            <div className="pb-2 inline-flex gap-2">
              <input
                type="checkbox"
                id="should_remove_bot_profile_picture"
                className="h-4 w-4 rounded border-gray-300 text-violet-600 focus:ring-violet-600"
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      interface: {
                        ...formData.interface,
                        remove_chat_icon: e.target.checked,
                      },
                    });
                  }
                }}
                checked={formData?.interface.remove_chat_icon}
              />
              <label
                className="block text-sm font-medium text-gray-700"
                htmlFor="should_remove_bot_profile_picture"
              >
                Remove chat icon
              </label>
            </div>
            <div className="pb-8">
              <div className="flex justify-between ">
                <label className="block text-sm font-medium text-gray-700">
                  Chat Bubble Button Color
                </label>
                <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                  Reset
                </button>
              </div>
              <ColorPicker
                color={formData?.interface.bubble_color}
                setColor={(bubble_color: string) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      interface: {
                        ...formData.interface,
                        bubble_color,
                      },
                    });
                  }
                }}
              />
            </div>
            <div className="pb-8">
              <label className="block text-sm font-medium text-gray-700">
                Align Chat Bubble Button
              </label>
              <select
                id="theme"
                name="theme"
                className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                value={formData?.interface.bubble_position}
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      interface: {
                        ...formData.interface,
                        bubble_position: e.target.value as string,
                      },
                    });
                  }
                }}
              >
                <option value="right">right</option>
                <option value="left">left</option>
              </select>
            </div>
            <div className="mt-1 text-sm text-zinc-700">
              Auto show initial messages pop-ups after{" "}
              <input
                name="auto_open_chat_window_after"
                type="number"
                className="min-w-0 p-1 px-2 rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      interface: {
                        ...formData.interface,
                        init_msg_display_delay_time: parseInt(
                          e.target.value
                        ) as number,
                      },
                    });
                  }
                }}
                value={formData?.interface.init_msg_display_delay_time}
              />{" "}
              seconds (negative to disable)
            </div>
          </div>
          <div className="flex-1 w-2/2 lg:w-1/2">
            <div
              className="h-[38rem] overflow-hidden flex flex-col flex-auto flex-shrink-0 bg-gray-100 mb-4 rounded border-zinc-200 border px-2 pb-2"
              style={{
                background:
                  formData?.interface.theme === "light" ? "white" : "black",
              }}
            >
              <div className="w-full">
                <div
                  className="flex justify-between py-1 mb-4 "
                  style={{
                    borderBottom: "1px solid rgb(241, 241, 240)",
                    background:
                      formData?.interface.theme === "light" ? "white" : "black",
                  }}
                >
                  <div className="flex items-center gap-2">
                    {!formData?.interface.remove_img && profileImg && (
                      <img
                        src={profileImg as string}
                        className="w-10 h-10 rounded-full"
                      />
                    )}
                    <p
                      className={
                        formData?.interface.theme === "dark"
                          ? "text-white"
                          : "text-black"
                      }
                    >
                      {formData?.interface.display_name}
                    </p>
                  </div>
                  <div className="flex justify-center items-center">
                    <button className="text-sm py-3   hover:text-zinc-600 text-zinc-700">
                      <Refresh
                        className={`h-5 w-5 ${
                          formData?.interface.theme === "dark"
                            ? "text-white"
                            : "text-black"
                        }`}
                      />
                    </button>
                    <button className="text-sm py-3 ml-3  hover:text-zinc-600 text-zinc-700">
                      <Exit
                        className={`h-6 w-6 ${
                          formData?.interface.theme === "dark"
                            ? "text-white"
                            : "text-black"
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>
              <div className="h-full overflow-auto">
                <div className="react-scroll-to-bottom--css-pfoiy-79elbk h-full">
                  <div className="react-scroll-to-bottom--css-pfoiy-1n7m0yu pr-2">
                    <div>
                      <div className="flex justify-start mr-8">
                        <div
                          className=" overflow-auto max-w-prose mb-3 rounded-lg py-3 px-4"
                          style={{
                            backgroundColor: "rgb(241, 241, 240)",
                            color: "black",
                          }}
                        >
                          <div className="flex flex-col items-start gap-4 break-words">
                            <div className="prose text-inherit text-left w-full break-words dark:prose-invert ">
                              <p>{formData?.interface.init_msg}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-end ml-8">
                        <div
                          className=" overflow-auto max-w-prose mb-3 rounded-lg py-3 px-4"
                          style={{
                            backgroundColor: formData?.interface.msg_color,
                          }}
                        >
                          <div className="flex flex-col items-start gap-4 break-words dark">
                            <div className="prose text-inherit text-left w-full break-words">
                              {formData && (
                                <p
                                  style={{
                                    color: getTextColor(
                                      formData.interface.msg_color
                                    ),
                                  }}
                                >
                                  Hi
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="clear-both ">
                <div className="py-3 flex overflow-x-auto ">
                  {formData?.interface.suggest_msg &&
                    formData?.interface.suggest_msg
                      .split("\n")
                      .map((item, index) => {
                        return (
                          <button
                            className="rounded-xl whitespace-nowrap  mr-1 mt-1 py-2 px-3 text-sm   bg-zinc-100 hover:bg-zinc-200"
                            key={index}
                          >
                            {item}
                          </button>
                        );
                      })}
                </div>
                <div
                  className="flex pl-3 p-1 rounded"
                  style={{
                    background:
                      formData?.interface.theme === "light" ? "white" : "black",
                    border: " 1px solid rgb(228, 228, 231)",
                  }}
                >
                  <input
                    type="text"
                    aria-label="chat input"
                    className=" min-w-0 bg-inherit flex-1 appearance-none rounded-md focus:outline-none sm:text-sm "
                  />
                  <div>
                    <button type="submit" className="p-2 flex-none">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        aria-hidden="true"
                        className={`h-5 w-5 ${
                          formData?.interface.theme === "dark"
                            ? "fill-white"
                            : "fill-black"
                        }`}
                      >
                        <path d="M3.478 2.405a.75.75 0 00-.926.94l2.432 7.905H13.5a.75.75 0 010 1.5H4.984l-2.432 7.905a.75.75 0 00.926.94 60.519 60.519 0 0018.445-8.986.75.75 0 000-1.218A60.517 60.517 0 003.478 2.405z"></path>
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div
              className="flex pb-12 duration-200 ease-in-out"
              style={{
                justifyContent:
                  formData?.interface.bubble_position === "right"
                    ? "flex-end"
                    : "flex-start",
              }}
            >
              {!formData?.interface.remove_chat_icon && chatImg ? (
                <img
                  className="w-11 h-11 rounded-full"
                  src={chatImg as string}
                />
              ) : (
                <div
                  className="p-3 rounded-full"
                  style={{ backgroundColor: formData?.interface.bubble_color }}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth="2.3"
                    stroke="white"
                    width="24"
                    height="24"
                    style={{ fill: formData?.interface.bubble_color }}
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M2.25 12.76c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.076-4.076a1.526 1.526 0 011.037-.443 48.282 48.282 0 005.68-.494c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z"
                    ></path>
                  </svg>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-end bg-gray-100 px-5 py-3">
        <button
          data-variant="flat"
          className="inline-flex items-center justify-center transform-none normal-case leading-6 transition ease-in-out duration-150 shadow-sm font-semibold text-center border focus:outline-none focus:ring-2 focus:ring-opacity-50 bg-zinc-700 text-zinc-200 border-zinc-600  hover:text-zinc-200 hover:border-zinc-600 hover:bg-zinc-700 h-7 w-16 rounded-b-md"
          onClick={handleSave}
        >
          Save
        </button>
      </div>
    </div>
  );
}
