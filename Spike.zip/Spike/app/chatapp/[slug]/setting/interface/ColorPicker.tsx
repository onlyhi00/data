import { SketchPicker } from "react-color";
import React, { useRef, useState, useEffect } from "react";

type Props = {
  color?: string;
  setColor: (msg_color: string) => void;
};

const ColorPicker = ({ color, setColor }: Props) => {
  const [menu_status, setMenuStatus] = useState(false);
  const btn_self = useRef<HTMLButtonElement>(null);
  const colorPicker = useRef<any>(null);

  useEffect(() => {
    function handleOutsideClick(event: any) {
      if (
        colorPicker.current &&
        !colorPicker.current?.contains(event.target) &&
        btn_self.current &&
        !btn_self.current?.contains(event.target)
      ) {
        // Clicked outside the div
        setMenuStatus(false);
      }
    }

    document.addEventListener("click", handleOutsideClick);

    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, [colorPicker]);

  return (
    <div className="relative">
      <button
        className="p-1 border bg-gray-100 inline-flex"
        role="colorPicker"
        ref={btn_self}
        onClick={() => {
          setMenuStatus(!menu_status);
        }}
      >
        <div
          className="h-5 w-5"
          role="colorPicker"
          style={{ backgroundColor: color }}
        ></div>
      </button>
      {menu_status && (
        <div ref={colorPicker}>
          <SketchPicker
            color={color}
            onChangeComplete={(clr: any) => {
              setColor(clr.hex);
            }}
            className="absolute top-9 left-0"
          />
        </div>
      )}
    </div>
  );
};

export default ColorPicker;
