"use client";

import { chatDataService } from "@/services/chatDataService";
import { useState } from "react";

export default function Page() {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  const [formData, setFormData] = useState(chatData);

  const handleSave = () => {
    chatService.update(chatData?.id as string, "model", {
      ...formData,
    });
  };

  return (
    <div className="border border-gray-200 rounded-md mb-10 h-full">
      <div className="border-b border-gray-200 rounded-t-md bg-white py-4 px-5">
        <h3 className="text-xl font-semibold leading-6 text-gray-900">
          Security
        </h3>
      </div>
      <div className="p-5 overflow-auto h-[calc(100%-6.813rem)]">
        <div className="pb-8">
          <label className="block text-sm font-medium text-gray-700">
            Visibility
          </label>
          <select
            className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
            onChange={(e) => {
              if (formData) {
                setFormData({
                  ...formData,
                  security: {
                    ...formData.security,
                    visibility: e.target.value as string,
                  },
                });
              }
            }}
            value={formData?.security.visibility}
          >
            <option value="private">private</option>
            <option value="public">public</option>
          </select>
          <p className="mt-2 text-sm text-zinc-500">
            'private': No one can access your chatbot except you (your account)
          </p>
          <p className="mt-2 text-sm text-zinc-500">
            'public': Other people can chat with your chatbot if you send them
            the link. You can also embed it on your website so your website
            visitors are able to use it.
          </p>
        </div>
        <div className="pb-8">
          <div>
            <label className="block text-sm font-medium text-gray-700 pb-2">
              Only allow the iframe and widget on specific domains
            </label>
            <button
              className={`bg-gray-200 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-violet-600 focus:ring-offset-2 ${
                formData?.security.only_domain !== null
                  ? "bg-violet-600"
                  : "bg-gray-200"
              }`}
              id="headlessui-switch-:rl:"
              role="switch"
              type="button"
              tabIndex={0}
              aria-checked="false"
              data-headlessui-state=""
              onClick={() => {
                if (formData) {
                  setFormData({
                    ...formData,
                    security: {
                      ...formData.security,
                      only_domain:
                        formData?.security.only_domain !== null ? null : "",
                    },
                  });
                }
              }}
            >
              <span
                aria-hidden="true"
                className={`${
                  formData?.security.only_domain !== null
                    ? "translate-x-5"
                    : "translate-x-0"
                } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
              ></span>
            </button>
          </div>
          {formData?.security.only_domain !== null && (
            <div className="my-3">
              <label className="block text-sm font-medium text-gray-700">
                Domains
              </label>
              <textarea
                name="initial_messages"
                // placeholder="Hi! What can I help you with?"
                className={`min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900`}
                maxLength={1000}
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      security: {
                        ...formData.security,
                        only_domain: e.target.value as string,
                      },
                    });
                  }
                }}
                value={formData?.security.only_domain}
              />
            </div>
          )}
        </div>

        <div>
          <div className="flex justify-between">
            <label className="block text-sm font-medium text-gray-700">
              Rate Limiting
            </label>
            <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
              Reset
            </button>
          </div>
          <p className="mt-2 text-sm text-zinc-500">
            Limit the number of messages sent from one device on the iframe and
            chat bubble (this limit will not be applied to you on chatbase.co,
            only on your website for your users to prevent abuse).
          </p>
          <div className="mt-1 text-sm text-zinc-700">
            Limit to only
            <input
              name="ip_limit"
              type="number"
              className="min-w-0 p-1 px-2 rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
              onChange={(e) => {
                if (formData) {
                  setFormData({
                    ...formData,
                    security: {
                      ...formData.security,
                      rate_limit: `${e.target.value as string}${
                        e.target.value.split("/")[1]
                      }`,
                    },
                  });
                }
              }}
              value={formData?.security.rate_limit.split("/")[0]}
            />
            messages every
            <input
              name="ip_limit_timeframe"
              type="number"
              className="min-w-0 p-1 px-2 rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
              onChange={(e) => {
                if (formData) {
                  setFormData({
                    ...formData,
                    security: {
                      ...formData.security,
                      rate_limit: `${e.target.value as string}${
                        e.target.value.split("/")[1]
                      }`,
                    },
                  });
                }
              }}
              value={formData?.security.rate_limit.split("/")[1]}
            />
            seconds.
          </div>
          <div className="text-sm text-zinc-700 my-4">
            Show this message to show when limit is hit
            <input
              name="ip_limit_message"
              className="min-w-0 p-1 mt-1 px-2 w-full rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
              onChange={(e) => {
                if (formData) {
                  setFormData({
                    ...formData,
                    security: {
                      ...formData.security,
                      limit_hit: e.target.value as string,
                    },
                  });
                }
              }}
              value={formData?.security.limit_hit}
            />
          </div>
        </div>
      </div>
      <div className="flex justify-end bg-gray-100 px-5 py-3">
        <button
          data-variant="flat"
          className="inline-flex items-center justify-center transform-none normal-case rounded-b-md leading-6 transition ease-in-out duration-150 shadow-sm font-semibold text-center border focus:outline-none focus:ring-2 focus:ring-opacity-50 bg-zinc-700 text-zinc-200 border-zinc-600 hover:text-zinc-200 hover:border-zinc-600 hover:bg-zinc-700 h-7 w-16"
          onClick={handleSave}
        >
          Save
        </button>
      </div>
    </div>
  );
}
