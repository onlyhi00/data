"use client";

import Clipboard from "@/assets/Clipboard";
import { chatDataService } from "@/services/chatDataService";
import { SignedIn } from "@clerk/nextjs";
import { useState } from "react";

export default function General() {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  const [formData, setFormData] = useState(chatData);

  const handleGeneralSubmit = () => {
    chatService.update(chatData?.id as string, "general", {
      ...formData,
    });
  };

  return (
    <SignedIn>
      <div className="border border-gray-200 rounded-md mb-10 h-full">
        <div className="border-b border-gray-200 bg-white py-4 px-5 rounded-t-md">
          <h3 className="text-xl font-semibold leading-6 text-gray-900 ">
            General
          </h3>
        </div>
        <div className="p-5 overflow-auto h-[calc(100%-6.813rem)]">
          <div className="pb-8">
            <label className="block text-sm font-medium text-gray-700">
              Chatbot ID
            </label>
            <div className="flex space-x-4 items-center mt-1">
              <div className="font-semibold">{chatData?.id}</div>
              <button className="h-7 w-7 border border-zinc-900/10 text-gray-700 p-1 rounded-lg hover:bg-gray-200">
                <Clipboard />
              </button>
            </div>
          </div>
          <div className="pb-8">
            <label className="block text-sm font-medium text-gray-700">
              Number of characters
            </label>
            <div className="mt-1 font-semibold">30,080</div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Name
            </label>
            <div className="mt-1">
              <input
                type="text"
                name="name"
                className="min-w-0 p-1 flex-auto w-full appearance-none rounded-md border border-zinc-900/10 bg-white px-3 placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                value={formData?.name}
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      name: e.target.value as string,
                    });
                  }
                }}
              />
            </div>
          </div>
        </div>
        <div className="flex justify-end bg-gray-100 px-5 py-3">
          <button
            data-variant="flat"
            className="inline-flex items-center justify-center transform-none normal-case rounded-b-md leading-6 transition ease-in-out duration-150 shadow-sm font-semibold text-center border focus:outline-none focus:ring-2 focus:ring-opacity-50 bg-zinc-700 text-zinc-200 border-zinc-600  hover:text-zinc-200 hover:border-zinc-600 hover:bg-zinc-700 h-7 w-16"
            onClick={handleGeneralSubmit}
          >
            Save
          </button>
        </div>
      </div>
    </SignedIn>
  );
}
