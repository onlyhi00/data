"use client";

import { chatDataService } from "@/services/chatDataService";
import { useState } from "react";

export default function Page() {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  const [formData, setFormData] = useState(chatData);
  const [leadsName, setLeadsName] = useState("");
  const [conversationName, setConversationName] = useState("");

  const handleSave = () => {
    chatService.update(chatData?.id as string, "model", {
      ...formData,
    });
  };

  return (
    <div className="border border-gray-200 rounded-md mb-10 h-full">
      <div className="border-b border-gray-200 rounded-t-md bg-white py-4 px-5">
        <h3 className="text-xl font-semibold leading-6 text-gray-900 ">
          Notifications
        </h3>
      </div>
      <div className="p-5 overflow-auto h-[calc(100%-6.813rem)]">
        <div className="pb-4">
          <div>
            <div className="py-4 mb-2 border-b">
              <div className="flex flex-row justify-between">
                <label className="block text-md font-medium text-gray-700 pb-2">
                  Receive email with daily leads
                </label>
                <button
                  className={`bg-gray-200 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-violet-600 focus:ring-offset-2 ${
                    formData?.notification.leads !== null
                      ? "bg-violet-600"
                      : "bg-gray-200"
                  }`}
                  id="headlessui-switch-:rl:"
                  role="switch"
                  type="button"
                  tabIndex={0}
                  aria-checked="false"
                  data-headlessui-state=""
                  onClick={() => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        notification: {
                          ...formData.notification,
                          leads:
                            formData.notification.leads !== null ? null : [],
                        },
                      });
                    }
                  }}
                >
                  <span
                    aria-hidden="true"
                    className={`${
                      formData?.notification.leads !== null
                        ? "translate-x-5"
                        : "translate-x-0"
                    } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                  ></span>
                </button>
              </div>
              {formData?.notification.leads !== null && (
                <div>
                  <div className="mt-2">
                    <input
                      name="email_input"
                      className="w-4/6 sm:w-1/2 p-1 mt-1 px-2 mr-5 rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                      maxLength={50}
                      onChange={(e) => setLeadsName(e.target.value as string)}
                      value={leadsName}
                    />
                    <button
                      className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto"
                      onClick={() => {
                        setLeadsName("");
                        if (formData && formData.notification.leads !== null) {
                          setFormData({
                            ...formData,
                            notification: {
                              ...formData.notification,
                              leads: [
                                ...formData.notification.leads,
                                leadsName,
                              ],
                            },
                          });
                        }
                      }}
                    >
                      Add Email
                    </button>
                  </div>
                  <label className="block text-sm font-medium text-red-700 mt-1"></label>
                  <div className="mt-3 flex flex-wrap"></div>
                </div>
              )}
              <div className="mt-3 flex flex-wrap">
                {formData?.notification.leads !== null &&
                  formData?.notification.leads.map((item, index) => {
                    return (
                      <span
                        className="flex w-min items-center rounded-full px-3 py-1 mb-2 text-sm font-normal text-gray-700 border border-gray-300 mr-2 hover:bg-gray-100"
                        key={index}
                      >
                        {item}
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          aria-hidden="true"
                          className="h-4 w-4 ml-3 hover:cursor-pointer"
                          onClick={() => {
                            let temp = formData?.notification.leads;
                            temp?.splice(index, 1);
                            if (
                              formData &&
                              formData.notification.leads !== null
                            ) {
                              setFormData({
                                ...formData,
                                notification: {
                                  ...formData.notification,
                                  leads: temp,
                                },
                              });
                            }
                          }}
                        >
                          <path
                            fillRule="evenodd"
                            d="M5.47 5.47a.75.75 0 011.06 0L12 10.94l5.47-5.47a.75.75 0 111.06 1.06L13.06 12l5.47 5.47a.75.75 0 11-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 010-1.06z"
                            clipRule="evenodd"
                          ></path>
                        </svg>
                      </span>
                    );
                  })}
              </div>
            </div>
            <div className="py-4 mb-2 border-b">
              <div className="flex flex-row justify-between">
                <label className="block text-md font-medium text-gray-700 pb-2">
                  Receive email with daily conversations
                </label>
                <button
                  className={`bg-gray-200 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-violet-600 focus:ring-offset-2 ${
                    formData?.notification.conversation !== null
                      ? "bg-violet-600"
                      : "bg-gray-200"
                  }`}
                  id="headlessui-switch-:rl:"
                  role="switch"
                  type="button"
                  tabIndex={0}
                  aria-checked="false"
                  data-headlessui-state=""
                  onClick={() => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        notification: {
                          ...formData.notification,
                          conversation:
                            formData.notification.conversation !== null
                              ? null
                              : [],
                        },
                      });
                    }
                  }}
                >
                  <span
                    aria-hidden="true"
                    className={`${
                      formData?.notification.conversation !== null
                        ? "translate-x-5"
                        : "translate-x-0"
                    } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                  ></span>
                </button>
              </div>
              {formData?.notification.conversation !== null && (
                <div>
                  <div className="mt-2">
                    <input
                      name="email_input"
                      className="w-4/6 sm:w-1/2 p-1 mt-1 px-2 mr-5 rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                      maxLength={50}
                      onChange={(e) =>
                        setConversationName(e.target.value as string)
                      }
                      value={conversationName}
                    />
                    <button
                      className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto"
                      onClick={() => {
                        setConversationName("");
                        if (
                          formData &&
                          formData.notification.conversation !== null
                        ) {
                          setFormData({
                            ...formData,
                            notification: {
                              ...formData.notification,
                              conversation: [
                                ...formData.notification.conversation,
                                conversationName,
                              ],
                            },
                          });
                        }
                      }}
                    >
                      Add Email
                    </button>
                  </div>
                  <label className="block text-sm font-medium text-red-700 mt-1"></label>
                  <div className="mt-3 flex flex-wrap"></div>
                </div>
              )}
              <div className="mt-3 flex flex-wrap">
                {formData?.notification.conversation !== null &&
                  formData?.notification.conversation.map((item, index) => {
                    return (
                      <span
                        className="flex w-min items-center rounded-full px-3 py-1 mb-2 text-sm font-normal text-gray-700 border border-gray-300 mr-2 hover:bg-gray-100"
                        key={index}
                      >
                        {item}
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          aria-hidden="true"
                          className="h-4 w-4 ml-3 hover:cursor-pointer"
                          onClick={() => {
                            let temp = formData?.notification.conversation;
                            temp?.splice(index, 1);
                            if (
                              formData &&
                              formData.notification.conversation !== null
                            ) {
                              setFormData({
                                ...formData,
                                notification: {
                                  ...formData.notification,
                                  conversation: temp,
                                },
                              });
                            }
                          }}
                        >
                          <path
                            fillRule="evenodd"
                            d="M5.47 5.47a.75.75 0 011.06 0L12 10.94l5.47-5.47a.75.75 0 111.06 1.06L13.06 12l5.47 5.47a.75.75 0 11-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 010-1.06z"
                            clipRule="evenodd"
                          ></path>
                        </svg>
                      </span>
                    );
                  })}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-end bg-gray-100 px-5 py-3">
        <button
          data-variant="flat"
          className="inline-flex items-center justify-center transform-none normal-case rounded-b-md leading-6 transition ease-in-out duration-150 shadow-sm font-semibold text-center border focus:outline-none focus:ring-2 focus:ring-opacity-50 bg-zinc-700 text-zinc-200 border-zinc-600  hover:text-zinc-200 hover:border-zinc-600 hover:bg-zinc-700  h-7 w-16"
          onClick={handleSave}
        >
          Save
        </button>
      </div>
    </div>
  );
}
