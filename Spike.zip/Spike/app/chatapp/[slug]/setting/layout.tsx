"use client";

import {
  Interface,
  Leads,
  Model,
  Notification,
  Security,
  Setting,
} from "@/app/icons";
import Spinner from "@/components/Spinner";
import { chatDataService } from "@/services/chatDataService";
import { usePathname, useRouter } from "next/navigation";
import React from "react";

const layout = ({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { slug: string };
}) => {
  const route = useRouter();
  const pathname: string = usePathname();
  const chatService = chatDataService();
  const chatData = chatService.dataById;

  if (chatData && params.slug && children && route && pathname) {
    return (
      <main className="flex h-[calc(100vh-20rem)] w-full justify-center gap-5">
        <div className="w-20 h-fit rounded-md inline-flex flex-col items-start gap-2 overflow-auto border">
          <button
            onClick={() =>
              route.push(`/chatapp/${params.slug}/setting/general`)
            }
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col items-center hover:text-primary-600  cursor-pointer text-xs relative ${
              pathname.includes("setting/general") &&
              "text-primary-600 bg-slate-100  sidebar-active"
            }`}
            disabled={pathname.includes("setting/general")}
          >
            <Setting className="w-3/5" />
            General
          </button>
          <button
            onClick={() => route.push(`/chatapp/${params.slug}/setting/model`)}
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col text-xs items-center gap-2 hover:text-primary-600 justify-start cursor-pointer relative ${
              pathname.includes("setting/model") &&
              "text-primary-600 bg-slate-100  sidebar-active"
            }`}
            disabled={pathname.includes("setting/model")}
          >
            <Model className="w-3/5" />
            Model
          </button>
          <button
            onClick={() =>
              route.push(`/chatapp/${params.slug}/setting/interface`)
            }
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col text-xs items-center gap-2 hover:text-primary-600 justify-start cursor-pointer relative ${
              pathname.includes("setting/interface") &&
              "text-primary-600 bg-slate-100  sidebar-active"
            }`}
            disabled={pathname.includes("setting/interface")}
          >
            <Interface className="w-3/5" />
            Chat Interface
          </button>
          <button
            onClick={() =>
              route.push(`/chatapp/${params.slug}/setting/security`)
            }
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col text-xs items-center gap-2 hover:text-primary-600 justify-start cursor-pointer relative ${
              pathname.includes("setting/security") &&
              "text-primary-600 bg-slate-100  sidebar-active"
            }`}
            disabled={pathname.includes("setting/security")}
          >
            <Security className="w-3/5" />
            Security
          </button>
          <button
            onClick={() => route.push(`/chatapp/${params.slug}/setting/leads`)}
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col text-xs items-center gap-2 hover:text-primary-600 justify-start cursor-pointer relative ${
              pathname.includes("setting/leads") &&
              "text-primary-600 bg-slate-100  sidebar-active"
            }`}
            disabled={pathname.includes("setting/leads")}
          >
            <Leads className="w-3/5" />
            Leads
          </button>
          <button
            onClick={() =>
              route.push(`/chatapp/${params.slug}/setting/notification`)
            }
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col text-xs items-center gap-2 hover:text-primary-600 justify-start cursor-pointer relative ${
              pathname.includes("setting/notification") &&
              "text-primary-600 bg-slate-100 sidebar-active"
            }`}
            disabled={pathname.includes("setting/notification")}
          >
            <Notification className="w-3/5" />
            Notification
          </button>
          {/* <button
            onClick={() =>
              route.push(`/chatapp/${params.slug}/setting/domains`)
            }
            className={`w-full px-3 py-1 rounded-md hover:bg-slate-100 duration-100 ease-in-out flex flex-col items-center gap-2 hover:text-primary-600 justify-start cursor-pointer ${
              pathname.includes("setting/domains") &&
              "text-primary-600 bg-slate-100"
            }`}
            disabled={pathname.includes("setting/domains")}
          >
            Domains
          </button> */}
        </div>
        <div className="px-2 w-full max-w-7xl h-full">{children}</div>
      </main>
    );
  } else {
    return <Spinner />;
  }
};

export default layout;
