"use client";

import { chatDataService } from "@/services/chatDataService";
import { useState } from "react";

export default function Page() {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  const [formData, setFormData] = useState(chatData);

  const handleSave = () => {
    chatService.update(chatData?.id as string, "model", {
      ...formData,
    });
  };
  return (
    <div className="border border-gray-200 rounded-md mb-10 h-full">
      <div className="border-b border-gray-200 rounded-t-md bg-white py-4 px-5">
        <h3 className="text-xl font-semibold leading-6 text-gray-900">Leads</h3>
      </div>
      <div className="p-5 overflow-auto h-[calc(100%-6.813rem)]">
        <div className="pb-4">
          <div className="max-w-lg">
            <div className="py-4">
              <div className="flex justify-between">
                <label className="block font-semibold text-sm pb-2">
                  Title
                </label>
                <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                  Reset
                </button>
              </div>
              <input
                name="title"
                className="min-w-0 p-1 mt-1 px-2 w-full rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                maxLength={300}
                onChange={(e) => {
                  if (formData) {
                    setFormData({
                      ...formData,
                      leads: {
                        ...formData.leads,
                        title: e.target.value as string,
                      },
                    });
                  }
                }}
                value={formData?.leads.title}
              />
            </div>
            <div className="py-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 pb-2">
                  Name
                </label>
                <button
                  className={`bg-gray-200 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-violet-600 focus:ring-offset-2 ${
                    formData?.leads.name !== null
                      ? "bg-violet-600"
                      : "bg-gray-200"
                  }`}
                  id="headlessui-switch-:rl:"
                  role="switch"
                  type="button"
                  tabIndex={0}
                  aria-checked="false"
                  data-headlessui-state=""
                  onClick={() => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        leads: {
                          ...formData.leads,
                          name: formData.leads.name !== null ? null : "name",
                        },
                      });
                    }
                  }}
                >
                  <span
                    aria-hidden="true"
                    className={`${
                      formData?.leads.name !== null
                        ? "translate-x-5"
                        : "translate-x-0"
                    } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                  ></span>
                </button>
              </div>
              {formData?.leads.name !== null && (
                <div className="py-4">
                  <div className="flex justify-end">
                    <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                      Reset
                    </button>
                  </div>
                  <input
                    name="title"
                    className="min-w-0 p-1 mt-1 px-2 w-full rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                    maxLength={300}
                    onChange={(e) => {
                      if (formData) {
                        setFormData({
                          ...formData,
                          leads: {
                            ...formData.leads,
                            name: e.target.value as string,
                          },
                        });
                      }
                    }}
                    value={formData?.leads.name}
                  />
                </div>
              )}
            </div>
            <div className="py-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 pb-2">
                  Email
                </label>
                <button
                  className={`bg-gray-200 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-violet-600 focus:ring-offset-2 ${
                    formData?.leads.email !== null
                      ? "bg-violet-600"
                      : "bg-gray-200"
                  }`}
                  id="headlessui-switch-:rl:"
                  role="switch"
                  type="button"
                  tabIndex={0}
                  aria-checked="false"
                  data-headlessui-state=""
                  onClick={() => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        leads: {
                          ...formData.leads,
                          email: formData.leads.email !== null ? null : "email",
                        },
                      });
                    }
                  }}
                >
                  <span
                    aria-hidden="true"
                    className={`${
                      formData?.leads.email !== null
                        ? "translate-x-5"
                        : "translate-x-0"
                    } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                  ></span>
                </button>
              </div>
              {formData?.leads.email !== null && (
                <div className="py-4">
                  <div className="flex justify-end">
                    <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                      Reset
                    </button>
                  </div>
                  <input
                    name="title"
                    className="min-w-0 p-1 mt-1 px-2 w-full rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                    maxLength={300}
                    onChange={(e) => {
                      if (formData) {
                        setFormData({
                          ...formData,
                          leads: {
                            ...formData.leads,
                            email: e.target.value as string,
                          },
                        });
                      }
                    }}
                    value={formData?.leads.email}
                  />
                </div>
              )}
            </div>
            <div className="py-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 pb-2">
                  Phone Number
                </label>
                <button
                  className={`bg-gray-200 relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-violet-600 focus:ring-offset-2 ${
                    formData?.leads.number !== null
                      ? "bg-violet-600"
                      : "bg-gray-200"
                  }`}
                  id="headlessui-switch-:rl:"
                  role="switch"
                  type="button"
                  tabIndex={0}
                  aria-checked="false"
                  data-headlessui-state=""
                  onClick={() => {
                    if (formData) {
                      setFormData({
                        ...formData,
                        leads: {
                          ...formData.leads,
                          number:
                            formData.leads.number !== null
                              ? null
                              : "phone number",
                        },
                      });
                    }
                  }}
                >
                  <span
                    aria-hidden="true"
                    className={`${
                      formData?.leads.number !== null
                        ? "translate-x-5"
                        : "translate-x-0"
                    } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                  ></span>
                </button>
              </div>
              {formData?.leads.number !== null && (
                <div className="py-4">
                  <div className="flex justify-end">
                    <button className="inline-flex items-center justify-center rounded-md border border-transparent bg-zinc-200 py-1 px-2 text-sm font-medium text-black shadow-sm hover:bg-zinc-300 focus:outline-none focus:ring-2 focus:ring-offset-2 sm:w-auto">
                      Reset
                    </button>
                  </div>
                  <input
                    name="title"
                    className="min-w-0 p-1 mt-1 px-2 w-full rounded-md border border-zinc-900/10 bg-white placeholder:text-zinc-400 focus:border-violet-500 focus:outline-none focus:ring-4 focus:ring-violet-500/10 sm:text-sm text-gray-900"
                    maxLength={300}
                    onChange={(e) => {
                      if (formData) {
                        setFormData({
                          ...formData,
                          leads: {
                            ...formData.leads,
                            number: e.target.value as string,
                          },
                        });
                      }
                    }}
                    value={formData?.leads.number}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-end bg-gray-100 px-5 py-3">
        <button
          data-variant="flat"
          className="inline-flex items-center justify-center transform-none normal-case rounded-b-md leading-6 transition ease-in-out duration-150 shadow-sm font-semibold text-center border focus:outline-none focus:ring-2 focus:ring-opacity-50 bg-zinc-700 text-zinc-200 border-zinc-600 hover:text-zinc-200 hover:border-zinc-600 hover:bg-zinc-700 h-7 w-16"
          onClick={handleSave}
        >
          Save
        </button>
      </div>
    </div>
  );
}
