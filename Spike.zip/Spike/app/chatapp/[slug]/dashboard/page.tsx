export default function Page() {
  return <h1 className="text-center text-3xl">Coming Soon!</h1>;
}
