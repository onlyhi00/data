export default function Page() {
  return <h1>Coming Soon!</h1>;
}
