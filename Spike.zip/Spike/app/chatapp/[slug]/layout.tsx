"use client";
import DeleteChat from "@/components/Modals/DeleteChat";
import EmbededModal from "@/components/Modals/EmbededModal";
import Spinner from "@/components/Spinner";
import { chatDataService } from "@/services/chatDataService";
import classNames from "classnames";
import { usePathname, useRouter } from "next/navigation";
import React, { useEffect, useState } from "react";

const layout = ({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { slug: string };
}) => {
  const [embedState, setEmbedState] = useState<boolean>(false);
  const [deleteState, setDeleteState] = useState<boolean>(false);
  const router = useRouter();
  const pathname: string = usePathname();

  const chatService = chatDataService();

  useEffect(() => {
    async function getDataById(slug: string) {
      await chatService.getById(slug);
    }
    getDataById(params.slug);
  }, []);
  const chatData = chatService.dataById;
  return (
    <div className="flex-1 p:2 sm:p-6 flex flex-col h-[calc(100vh-10rem)] gap-2">
      <div className=" pt-3 bg-white">
        <h1 className="text-3xl text-center mb-2 font-semibold">
          {chatData && chatData.name}
        </h1>
        <div className="flex justify-center">
          <div className="inline-flex px-6 justify-center space-x-8 whitespace-nowrap text-sm border-b mx-auto">
            <button
              onClick={() => {
                router.push(`/chatapp/${params.slug}`);
              }}
              className={classNames(
                "items-center px-1 pt-1 border-transparent border-b-2 font-medium pb-1 col-span-1 duration-100 ease-in-out",
                {
                  "border-violet-500 text-gray-900":
                    pathname === `/chatapp/${params.slug}`,
                  "hover:border-gray-300 hover:text-gray-700 text-gray-500":
                    pathname !== `/chatapp/${params.slug}`,
                }
              )}
            >
              Chatbot
            </button>
            <button
              onClick={() => {
                router.push(`/chatapp/${params.slug}/setting/general`);
              }}
              className={classNames(
                "items-center px-1 pt-1 border-transparent font-medium pb-1 border-b-2 col-span-1 duration-100 ease-in-out",
                {
                  "border-violet-500 text-gray-900": pathname.includes(
                    `/chatapp/${params.slug}/setting`
                  ),
                  "hover:border-gray-300 hover:text-gray-700 text-gray-500":
                    !pathname.includes(`/chatapp/${params.slug}/setting`),
                }
              )}
            >
              Settings
            </button>
            <button
              onClick={() => {
                router.push(`/chatapp/${params.slug}/dashboard`);
              }}
              className={classNames(
                "items-center px-1 pt-1 border-transparent font-medium pb-1 border-b-2 col-span-1 duration-100 ease-in-out",
                {
                  "border-violet-500 text-gray-900": pathname.includes(
                    `/chatapp/${params.slug}/dashboard`
                  ),
                  "hover:border-gray-300 hover:text-gray-700 text-gray-500":
                    !pathname.includes(`/chatapp/${params.slug}/dashboard`),
                }
              )}
            >
              Dashboard
            </button>
            <button
              onClick={() => {
                router.push(`/chatapp/${params.slug}/sources`);
              }}
              className={classNames(
                "items-center px-1 pt-1 border-transparent font-medium pb-1 border-b-2 col-span-1 duration-100 ease-in-out",
                {
                  "border-violet-500 text-gray-900": pathname.includes(
                    `/chatapp/${params.slug}/sources`
                  ),
                  "hover:border-gray-300 hover:text-gray-700 text-gray-500":
                    !pathname.includes(`/chatapp/${params.slug}/sources`),
                }
              )}
            >
              Sources
            </button>
            <button
              onClick={() => {
                router.push(`/chatapp/${params.slug}/integration`);
              }}
              className={classNames(
                "items-center px-1 pt-1 border-transparent font-medium pb-1 border-b-2 col-span-1 duration-100 ease-in-out",
                {
                  "border-violet-500 text-gray-900": pathname.includes(
                    `/chatapp/${params.slug}/integration`
                  ),
                  "hover:border-gray-300 hover:text-gray-700 text-gray-500":
                    !pathname.includes(`/chatapp/${params.slug}/integration`),
                }
              )}
            >
              Integration
            </button>

            <button
              onClick={() => setEmbedState(true)}
              className="pb-1 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 items-center border-b-2 px-1 pt-1 font-normal duration-100 ease-in-out"
            >
              Embed on site
            </button>
            <button
              onClick={() => setDeleteState(true)}
              className="pb-1 border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 items-center border-b-2 px-1 pt-1 font-normal duration-100 ease-in-out"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
      {chatData ? children : <Spinner />}
      <EmbededModal
        state={embedState}
        close={() => {
          setEmbedState(false);
        }}
        item={params.slug}
      />
      <DeleteChat
        state={deleteState}
        close={() => {
          setDeleteState(false);
        }}
        item={params.slug}
      />
    </div>
  );
};

export default layout;
