"use client";
import Spinner from "components/Spinner";
import Chat from "components/buildchatbot/Chat";
import React, { useEffect } from "react";
import { chatDataService } from "services/chatDataService";

type Props = { params: { slug: string } };

const ChatApp = ({ params }: Props) => {
  const chatService = chatDataService();
  const chatData = chatService.dataById;
  return chatData ? <Chat data={chatData} item={params.slug} /> : <Spinner />;
};

export default ChatApp;
export const runtime = "edge"; // 'nodejs' (default) | 'edge'
