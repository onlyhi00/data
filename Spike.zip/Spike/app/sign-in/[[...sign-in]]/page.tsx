"use client";
import { SignIn } from "@clerk/nextjs";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";

export default function Page() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    router.replace(
      `${pathname}?redirect_url=${searchParams
        .get("redirect_url")
        ?.replace("http://localhost", process.env.REPLACE_HOSTNAME as string)}`
    );
  }, [searchParams]);
  return (
    <div className="flex justify-center py-24">
      <SignIn />
    </div>
  );
}
