"use client";
import { PdfContext } from "ContextProvider/pdfContext";
import Spinner from "components/Spinner";
import Text from "components/buildchatbot/Text";
import DataFile from "components/buildchatbot/DataFiles";
import QAFC from "components/buildchatbot/qaFC";
import { redirect } from "next/navigation";
import { useState, useEffect, useContext } from "react";
import ScrapData from "components/buildchatbot/ScrapData";
import { chatDataService } from "services/chatDataService";
import toast from "react-hot-toast";
import { encode, decodeGenerator } from "gpt-tokenizer";
import { useAuth } from "@clerk/nextjs";
import { TextContext } from "@/ContextProvider/textContext";
import { WebsiteContext } from "@/ContextProvider/websiteContext";
import { QAContext } from "@/ContextProvider/qaContext";

const CreateChatBot = () => {
  const [openTab, setOpenTab] = useState(1);
  const [loading, setLoading] = useState(false);
  const { pdfContext, setPdfContext } = useContext(PdfContext);
  const { textContext, setTextContext } = useContext(TextContext);
  const { websiteContext, setWebsiteContext } = useContext(WebsiteContext);
  const { qaContext, setQAContext } = useContext(QAContext);
  const { userId } = useAuth();

  // const chatService = chatDataService();
  useEffect(() => {
    setPdfContext({});
    setTextContext({});
    setWebsiteContext({});
    setQAContext({});
  }, []);

  const chatService = chatDataService();
  const handleBuild = () => {
    setLoading(true);
    let data = [];
    if (pdfContext.chunks) data.push(pdfContext);
    if (textContext.chunks) data.push(textContext);
    if (websiteContext.chunks) data.push(websiteContext);
    if (qaContext.chunks) data.push(qaContext);
    if (data.length !== 0) {
      const websiteObject = data.find((obj) => obj.name === "website");
      if (websiteObject) {
        if (encode(JSON.stringify(websiteObject)).length > 3000) {
          if (websiteObject.chunks.length === 2) {
            let encodedToken = encode(websiteObject.chunks[0].content);
            let decoded_token = "";
            let index = 0;
            for (const token of decodeGenerator(encodedToken)) {
              if (index >= 2500) {
                break;
              }
              decoded_token += token;
              index++;
            }
            websiteObject.chunks[0].content = decoded_token;
            setWebsiteContext(websiteObject);
            data = [];
            if (pdfContext.chunks) data.push(pdfContext);
            if (textContext.chunks) data.push(textContext);
            if (websiteContext.chunks) data.push(websiteContext);
            if (qaContext.chunks) data.push(qaContext);
            // toast.error("Your token is too much, we optimize that");
          } else {
            setLoading(false);
            toast.error("Scraped website is too many! Optimize data.");
            return;
          }
        }
      }
      chatService.create({ data });
    } else {
      toast.error("You didn't set any option");
      setLoading(false);
    }
  };

  if (!userId) {
    redirect("/");
  } else {
    return (
      <div className="lg:w-1/2 mx-auto mt-20">
        {loading && <Spinner />}
        <h1 className="text-center font-bold text-3xl">Data Source</h1>
        <div className="flex flex-wrap">
          <div className="w-full">
            <ul
              className="flex mb-0 list-none flex-wrap pt-3 pb-4 flex-row"
              role="tablist"
            >
              <li className="-mb-px mr-2 last:mr-0 flex-auto text-center">
                <button
                  className={
                    "text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal w-full " +
                    (openTab === 1
                      ? "text-white bg-gray-800"
                      : "text-blueGray-600 bg-white")
                  }
                  onClick={(e) => {
                    e.preventDefault();
                    setOpenTab(1);
                  }}
                  data-toggle="tab"
                  role="tablist"
                >
                  Files
                </button>
              </li>
              <li className="-mb-px mr-2 last:mr-0 flex-auto text-center">
                <button
                  className={
                    "text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal w-full " +
                    (openTab === 2
                      ? "text-white bg-gray-800"
                      : "text-blueGray-600 bg-white")
                  }
                  onClick={(e) => {
                    e.preventDefault();
                    setOpenTab(2);
                  }}
                  data-toggle="tab"
                  role="tablist"
                >
                  Text
                </button>
              </li>
              <li className="-mb-px mr-2 last:mr-0 flex-auto text-center">
                <button
                  className={
                    "text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal w-full " +
                    (openTab === 3
                      ? "text-white bg-gray-800"
                      : "text-blueGray-600 bg-white")
                  }
                  onClick={(e) => {
                    e.preventDefault();
                    setOpenTab(3);
                  }}
                  data-toggle="tab"
                  role="tablist"
                >
                  Website
                </button>
              </li>
              <li className="-mb-px mr-2 last:mr-0 flex-auto text-center">
                <button
                  className={
                    "text-xs font-bold uppercase px-5 py-3 shadow-lg rounded block leading-normal w-full " +
                    (openTab === 4
                      ? "text-white bg-gray-800"
                      : "text-blueGray-600 bg-white")
                  }
                  onClick={(e) => {
                    e.preventDefault();
                    setOpenTab(4);
                  }}
                  data-toggle="tab"
                  role="tablist"
                >
                  Q&A
                </button>
              </li>
            </ul>
            <div className="flex flex-col min-w-0 break-words bg-white w-full mb-6 shadow-lg rounded">
              <div className="px-4 py-5 flex-auto">
                <div className="tab-content tab-space">
                  <div
                    className={openTab === 1 ? "block" : "hidden"}
                    id="link1"
                  >
                    <DataFile />
                  </div>
                  <div
                    className={openTab === 2 ? "block" : "hidden"}
                    id="link2"
                  >
                    <Text />
                  </div>
                  <div
                    className={openTab === 3 ? "block" : "hidden"}
                    id="link3"
                  >
                    <ScrapData />
                  </div>
                  <div
                    className={openTab === 4 ? "block" : "hidden"}
                    id="link3"
                  >
                    <QAFC />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-center">
              <button
                className="w-full bg-gray-800 py-8 text-2xl text-white font-extrabold rounded-2xl hover:bg-gray-700 active:bg-gray-600"
                onClick={handleBuild}
              >
                Create Build App
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
};

export default CreateChatBot;
