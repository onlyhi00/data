import CreateChatBot from "./CreateChatBot";

const CreateChatBotPage = async () => {
  return <CreateChatBot />;
};

export default CreateChatBotPage;
export const runtime = "edge"; // 'nodejs' (default) | 'edge'
