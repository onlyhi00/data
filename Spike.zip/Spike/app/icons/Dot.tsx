import React from "react";

type Props = {
  className?: string;
};

export function Dot({ className }: Props) {
  return (
    <svg
      width="7"
      height="6"
      viewBox="0 0 7 6"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className && className}
    >
      <circle cx="3.3335" cy="3" r="3" fill="#12B76A" />
    </svg>
  );
}
