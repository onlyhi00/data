import { Clerk } from "@clerk/backend";
import { getAuth } from "@clerk/nextjs/server";
import { NextRequest } from "next/server";

const clerk = Clerk({ apiKey: process.env.CLERK_SECRET_KEY });

export const auth = {
  isAuthenticated,
  verifyToken,
};

function isAuthenticated(req: NextRequest) {
  try {
    verifyToken(req);
    return true;
  } catch {
    return false;
  }
}

function verifyToken(req: NextRequest) {
  const { sessionClaims } = getAuth(req);
  console.info(sessionClaims);
  return sessionClaims?.user_id as string;
}
