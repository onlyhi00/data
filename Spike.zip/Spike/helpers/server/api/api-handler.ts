import { NextRequest, NextResponse } from "next/server";

import { errorHandler, jwtMiddleware, validateMiddleware } from "./";

export { apiHandler };

const getCorsHeaders = (origin: string) => {
  // Default options
  const headers = {
    "Access-Control-Allow-Methods": "GET,DELETE,PATCH,POST,PUT",
    "Access-Control-Allow-Headers":
      "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version",
    "Access-Control-Allow-Origin": `${origin}`,
    "Access-Control-Allow-Credentials": "true",
  };

  // If no allowed origin is set to default server origin

  // If allowed origin is set, check if origin is in allowed origins

  // Validate server origin

  // Return result
  return headers;
};

function apiHandler(handler: any) {
  const wrappedHandler: any = {};
  const httpMethods = ["GET", "POST", "PUT", "PATCH", "DELETE"];
  // wrap handler methods to add middleware and global error handler
  httpMethods.forEach((method) => {
    if (typeof handler[method] !== "function") return;
    wrappedHandler[method] = async (req: NextRequest, ...args: any) => {
      try {
        if (method !== "PUT") {
          // monkey patch req.json() because it can only be called once
          const json = await req.json();
          req.json = () => json;
        }
      } catch {}
      try {
        // if (!db.initialized) await db.initialize();
        // global middleware

        await jwtMiddleware(req);
        await validateMiddleware(req, handler[method].schema);
        // route handler
        const responseBody = await handler[method](req, ...args);
        return NextResponse.json(responseBody || {}, {
          status: 200,
          headers: getCorsHeaders(req.headers.get("origin") || ""),
        });
      } catch (err: any) {
        // global error handler
        return errorHandler(err);
      }
    };
  });

  return wrappedHandler;
}
