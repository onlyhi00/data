import { NextRequest } from "next/server";

import { auth } from "helpers/server";
import { headers } from "next/headers";

export { jwtMiddleware };

async function jwtMiddleware(req: NextRequest) {
  if (isPublicPath(req)) return;
  // verify token in request cookie
  const id = auth.verifyToken(req);
  req.headers.set("userId", id);
}

function isPublicPath(req: NextRequest) {
  // public routes that don't require authentication
  if (req.method === "GET" && req.nextUrl.href.includes("/api/data?id=")) {
    return true;
  }

  const publicPaths = [
    "POST:/api/account/login",
    "POST:/api/account/logout",
    "POST:/api/account/register",
  ];
  return publicPaths.includes(`${req.method}:${req.nextUrl.pathname}`);
}
