import mongoose from "mongoose";

const Schema = mongoose.Schema;

const connectMongo = async () => {
  try {
    console.log("MongoDB Connection");
    if (mongoose.connections[0].readyState) {
      console.log("MongoDB Connection Exists");
    } else {
      await mongoose.connect(process.env.MONGODB_URI!);
      console.log("MongoDB Connected...");
    }
  } catch (err: any) {
    console.error(err.message);
    // Exit process with failure
    process.exit(1);
  }
};

connectMongo();
mongoose.Promise = global.Promise;

export const db = {
  Data: dataModel(),
};

// mongoose models with schema definitions

function dataModel() {
  const schema = new Schema(
    {
      user: { type: String },
      name: { type: String },
      chunks: [{ role: String, content: String }],
      prompt: {
        type: String,
        default:
          "You are ChatGPT, a language model trained to act as chatbot. Your task is to take text input of each page of data one by one from the user. Remember, you are a chatbot, and your responses should be limited to the information contained within the data. You must accurately answer any questions the user poses, regardless of how they phrase them. Answer you don't mentioned in you pdf if there is no content that user asking in pdf pages.",
      },
      mode: { type: String, default: "gpt-3.5-turbo" },
      temperature: { type: Number, default: 0 },
      interface: {
        init_msg: { type: String, default: "Hi! What can I help you with?" },
        suggest_msg: { type: String, default: "" },
        theme: { type: String, default: "light" },
        img: { type: String, default: "" },
        remove_img: { type: Boolean, default: true },
        msg_color: { type: String, default: "#3B81F6" },
        chat_icon: { type: String, default: "" },
        remove_chat_icon: { type: Boolean, default: true },
        bubble_color: { type: String, default: "#000" },
        bubble_position: { type: String, default: "right" },
        display_name: { type: String, default: "" },
        init_msg_display_delay_time: { type: Number, default: 3 },
      },
      leads: {
        title: { type: String, default: "Let us know how to contact you" },
        name: { type: String, default: null },
        email: { type: String, default: null },
        number: { type: String, default: null },
      },
      security: {
        visibility: { type: String, default: "private" },
        only_domain: { type: String, default: null },
        rate_limit: { type: String, default: "20/240" },
        limit_hit: { type: String, default: "Too many messages in a row" },
      },
      notification: {
        leads: { type: [String], default: null },
        conversation: { type: [String], default: null },
      },
    },
    { timestamps: true }
  );

  schema.set("toJSON", {
    virtuals: true,
    versionKey: false,
    transform: function (doc, ret) {
      delete ret._id;
      delete ret.hash;
    },
  });

  return mongoose.models.Data || mongoose.model("Data", schema);
}
