import { headers } from "next/headers";
import { db } from "./db";
import { error } from "console";

const Data = db.Data;

export const dataRepo = {
  getAll,
  getById,
  create,
  update,
  deleteById,
};

async function create(params: CreateProp[]) {
  const currentUserId = headers().get("userId");
  const responseData: any[] = [];
  for (let index = 0; index < params.length; index++) {
    const element = params[index];
    const data = new Data({ user: currentUserId, ...element });
    responseData.push(await data.save());
  }
  return responseData;
}

async function getAll() {
  const currentUserId = headers().get("userId");
  const data = await Data.find({ user: currentUserId });
  return data;
}

async function getById(id: string) {
  return await Data.findById(id);
}

async function update(id: string, mode: string, data: any) {
  try {
    const currentUserId = headers().get("userId");
    await Data.findOneAndUpdate({ user: currentUserId, _id: id }, { ...data });
    return data;
  } catch (err: any) {
    throw error(err.message);
  }
}

type ChunkType = {
  role: string;
  content: string;
};

type CreateProp = {
  name: string;
  chunks: Array<ChunkType>;
};

async function deleteById(id: string) {
  return await Data.findByIdAndDelete(id);
}
