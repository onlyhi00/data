const path = require("path");
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "tailwindui.com",
        port: "",
        pathname: "/img/**",
      },
      {
        protocol: "https",
        hostname: "images.unsplash.com",
        port: "",
        pathname: "/photo-1549078642-b2ba4bda0cdb/**",
      },
    ],
    domains: ["img.clerk.com"],
  },
  experimental: {
    appDir: true,
    esmExternals: "loose",
    serverComponentsExternalPackages: ["mongoose"],
  },
  env: {
    API_URL: process.env.API_URL || "",
    api_key: process.env.chatgpt_key || "",
    REPLACE_HOSTNAME: process.env.REPLACE_HOSTNAME || "",
  },
  serverRuntimeConfig: {
    secret: process.env.JWT_SECRET,
  },
  webpack: (config) => {
    config.module.rules.push({
      test: /\.node/,
      use: "raw-loader",
    });
    config.experiments = {
      topLevelAwait: true,
      layers: true,
    };
    return config;
  },
};

module.exports = nextConfig;
