const QueryData = [
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    },
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    },
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    },
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    },
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    },
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    },
    {
        title:'question1',
        description:'Please answer the question.',
        date:'2024-01-24'
    }
]

export default QueryData;

