const Unauthorized = () => {
    return(
        <div>
            Unauthorized, You can't access this page
        </div>
    )
}

export default Unauthorized;